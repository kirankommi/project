export const environment = {
  production: true,
 // baseUrl :"http://nzur470169dww.ubsprod.msad.ubs.net:802/api/",
  //baseUrl :"http://localhost:58349/api/",
  baseUrl : "http://nzur470169dww.ubsprod.msad.ubs.net:802/api/",
  testicon: true
};
