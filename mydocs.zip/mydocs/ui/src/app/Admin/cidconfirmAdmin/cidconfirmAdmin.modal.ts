export class User
    {
        Gpn : string;
        BusinessName : string;
        CidConfirmationdate : Date
    }