import {Http,Response} from '@angular/http';
import {Injectable} from '@angular/core';
import { User } from './cidconfirmAdmin.modal'
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../../environments/environment';

@Injectable()
export class CidconfirmAdminService 
{
    //hostURL : string = "http://nzur467991dww.ubsprod.msad.ubs.net/CMRAPI/api/";
   // hostURL :string ="http://localhost:58349/api/";
    hostURL :string = environment.baseUrl;
    constructor(private http: Http) {}

    GetUsers() : Observable<User[]> 
    {        
        return this.http.get(this.hostURL + 'CidConfirm/GetUsers/')
        .map((res:Response)=> res.json() as User[])
        .catch(this.handleError)
    }

    GetUserByGPN(GPN:string) : Observable<User[]> 
    {        
        return this.http.get(this.hostURL + 'CidConfirm/GetUserByGPN/'+GPN)
        .map((res:Response)=> res.json() as User[])
        .catch(this.handleError)
    }

    private handleError(error: Response) {
        return Observable.throw(error.statusText);
    }
}