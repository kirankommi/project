import { Component, OnInit} from '@angular/core';
import { CidconfirmAdminService } from './cidconfirmAdmin.service';
import { User } from './cidconfirmAdmin.modal';


@Component({
selector : 'cidconfirmAdmin',
templateUrl : './cidconfirmAdmin.component.html'
})
export class CidconfirmAdminComponent 
{
    userList : User[];
    GPN : string;

    constructor(
        private cidconfirmAdminService:CidconfirmAdminService,
        ) {}

    ngOnInit() 
    { 
        this.cidconfirmAdminService.GetUsers()
            .subscribe(users => {  
                this.userList = users;
        });
    }

    formatDate(date)
    {           
        date = date.slice(8,10) + '.' +  date.slice(5,7)  + '.' + date.slice(0,4) + ' ' + date.slice(11,13)+ ':' + date.slice(14,16)
        return date;
    }
    
    GetUserByGPN()
    {
        if(this.GPN !== null && this.GPN !== undefined && this.GPN !== '') {
                this.cidconfirmAdminService.GetUserByGPN(this.GPN)
                .subscribe(users => {  
                    this.userList = users;
            });
        }
        else
        {
            this.cidconfirmAdminService.GetUsers()
                .subscribe(users => {  
                    this.userList = users;
            });
        }        
    }
}