import {Component, OnInit} from '@angular/core';
import { CategoryService } from './category.service';
import { CategoryModal } from './Category.modal';
import { Router, ActivatedRoute } from '@angular/router';
import { NgForm, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { ConditionalExpr } from '@angular/compiler';
import { Message } from 'primeng/components/common/message';


@Component({
    selector : 'pm-category2edit',
    templateUrl : './category2edit.component.html'
    })
    
    export class Category2EditComponent {
    
        categorymodal:CategoryModal[];
        parentcategoryflag:boolean;
        categoryId: number=0;
        ifsuccessmsg:boolean;
        saveflag:boolean;
        myForm:FormGroup;
        msgs: Message[];
        validationflag:boolean;
        successmsg:string;
        editflag:boolean;
        category:CategoryModal=new CategoryModal();
        constructor(private categoryservice:CategoryService,private formBuilder: FormBuilder,private router:Router, private route: ActivatedRoute) {                     

        }
    
    ngOnInit()
    {

        this.myForm = this.formBuilder.group({
            'catnameen': new FormControl(''),
            'catdescen': new FormControl(''),
            'catnamede': new FormControl(''),
            'catdescde': new FormControl(''),
            'catnamefr': new FormControl(''),
            'catdescfr': new FormControl(''),
            'catnameit': new FormControl(''),
            'catdescit': new FormControl(''),
            'inputState':new FormControl('')
        });

        this.categoryservice.getParentCategories().subscribe(
            response=>{this.categorymodal=response;
                
                for(let categ of this.categorymodal){
                        
                    //to get default category name
                    if(categ.categoryName==null || categ.categoryName=="undefined"){
                    this.categoryservice.GetDefaultName(categ.Id).subscribe(
                        response=> {categ.categoryName=response                           
                        }
                    )  
        
                    }
                 }

            }
           
        )

        this.category.IS_ACTIVE=true

        this.route
        .queryParams
        .subscribe(params => {
          this.category.Id = +params['Id'] || 0;
        if(this.category.Id!=0){
            this.category.editflag=true
        }
          
        });

        if(this.category.editflag)
        {
           this.categoryservice.getCategory(this.category.Id).subscribe(
               response=>{this.category=response
               
            this.categoryId=this.category.Parent_Category_ID
            }
           )
        }
         this.editflag=this.category.editflag

       
    }

    onSubmit() {                  
        
      
        if((this.myForm.get('inputState').value ==0))
        {
            this.msgs = [];
            this.msgs.push({severity:'error',detail:"Please choose a Level 1 category"});
          
        }
        else if((this.myForm.get('catnamede').value != null && this.myForm.get('catnamede').value != '' )
           && (this.myForm.get('catnameen').value != null && this.myForm.get('catnameen').value != '' )
           && (this.myForm.get('catnamefr').value != null && this.myForm.get('catnamefr').value !='' )
            && (this.myForm.get('catnameit').value != null && this.myForm.get('catnameit').value !='' ))
        {
       

       this.category.editflag= this.editflag
       this.category.Parent_Category_ID=this.categoryId;

      
     console.log(this.category.IS_ACTIVE)

   
        
        if(this.category.editflag){
            this.category.LAST_UPDATED_BY=sessionStorage.getItem('GPN');
        }
        else{
            this.category.LAST_UPDATED_BY=sessionStorage.getItem('GPN');
            this.category.CREATED_BY=sessionStorage.getItem('GPN');
        }
         
       
      

        this.categoryservice.AddCategory(this.category).subscribe(
            
                  response=>{
                    this.successmsg=response
                    if(this.successmsg=="Category name already exists")
                    {
                        this.msgs = [];
                        this.msgs.push({severity:'error',detail:"Category name already exists"});
                    } 
                    else{
                        this.saveflag=true;
                        this.msgs = [];
						 this.saveflag=true;
                        this.msgs.push({severity:'success',detail:this.successmsg});
                    }
                  
                                        
            
                },
                (error)=>{ 
                    this.msgs = [];
                    this.msgs.push({severity:'error',detail:"Unable to add or edit category due to some server error"});     
                 }
            
        )
            
       
        }        
        else
        {
            this.msgs = [];
            this.msgs.push({severity:'error',detail:"Please fill out names in all languages"});
                   
        }

    
  }

  onReset()
    { 
        this.category= new CategoryModal();
        this.categoryId=0;
        this.msgs = [];
        this.saveflag=false;
    }

}