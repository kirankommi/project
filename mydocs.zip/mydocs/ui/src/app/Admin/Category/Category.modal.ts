

export class CategoryModal {
  Id :number;
  categoryName:string;
  Name_EN :string;
  Name_IT:string ;
  Name_FR :string;
  Name_DE:string;
  Description_EN :string;
  Description_FR :string;
  Description_IT:string;
  Description_DE :string;
  CREATED_DATE :Date;
  CREATED_BY  :string;
  UpdatedDate :string;
  LAST_UPDATED_BY:string;
  IS_ACTIVE:boolean;
  Is_actve:string;
  Parent_Category_ID :number;
  ParentCategory:string;
  Display_Order :number;
  editflag:boolean=false;
  No_Of_Cases:boolean=false;
  hide_on_capture:boolean=false;
  orgflag:orgnizationflag[]=[];

}

export class orgnizationflag {
  organization_name :string;
  field:boolean=false;
}