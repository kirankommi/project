export class Organization {
    Id :number;
    Organization_Name:string;
}