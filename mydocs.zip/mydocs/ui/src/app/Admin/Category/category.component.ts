import {Component, OnInit} from '@angular/core';
import { CategoryService } from './category.service';
import { CategoryModal, orgnizationflag } from './Category.modal';
import { Router, ActivatedRoute } from '@angular/router';
import { Organization } from './organization';
import { forEach } from '@angular/router/src/utils/collection';
import {NgForm} from '@angular/forms';
import { Organization_Categories } from './Organization_category_Relation';

import { Message } from 'primeng/components/common/message';

@Component({
selector : 'pm-category',
templateUrl : './category.component.html'
})

export class CategoryComponent  implements OnInit
{      

    keyword2:string;
   
    msgs: Message[];
    loading: boolean;
    i:number;
    list:string[];
    organization:Organization[]=[];
    headername:string[]=[];
    cols: any[];
    categorymodal:CategoryModal[]=[];
    keyword:string;
    changeorderflag:boolean;
    isparent:boolean=true;
    relation:any[];
    flag:boolean[]=[];
    smflag:boolean=false;
    catorganlist:number[];
    tflag:boolean[]=[];
    defaultNameList:CategoryModal[]=[];
    tempOrgan:Organization[]=[];
    myobject:boolean=false;
     test : string="";
     defaultflag:boolean=false;
     categoryOrder:CategoryModal[];
     changedlist:number[]=[];
     displaycat1:boolean=false;
     categoryOrgflag:any[]=[];
    constructor(private categoryservice:CategoryService,private router:Router) { }
    
    ngOnInit() {
        this.loading = true;
       
        // this.categoryservice.GetOrganizations().subscribe(
        //     response=>{ this.organization=response;
        //        this.tempOrgan= this.organization
          
        //      for(let organistn of this.organization){
        //    // console.log(organistn.Organization_Name);
        //         this.headername.push(organistn.Organization_Name)   

        //       }

        //     }


                
        // )
             
    

        this.categoryservice.getParentCategories().subscribe(
            response=>{this.categorymodal=response;
                for(let categ of this.categorymodal){
                   
                    if(categ.IS_ACTIVE==true)
                    {
                        categ.Is_actve="Yes"
                    }
                    else{
                        categ.Is_actve="No"
                    }
                    //categ.UpdatedDate=this.datepipe.transform(categ.UpdatedDate, 'dd.MM.yyyy');
                    
                    //to get default category name
                    if(categ.categoryName==null || categ.categoryName=="undefined"){
                      this.categoryservice.GetDefaultName(categ.Id).subscribe(
                          response=> {categ.categoryName=response 
                             this.defaultNameList.push(categ);                          
                          }
                      )
                    }
                    
                     //to get category organization mapping dictionary
                    //  this.categoryservice.getorganlistCategory(categ.Id).subscribe(
                    //    response=>{this.relation=response;
                    //    }
                    
            
                    // )


                    //    console.log("1" + this.test);
                     //  this.categoryOrgflag.push(this.relation);
                    // for(let categ of this.relation){
                    //     this.test=categ.organization_name
                    //         this.myobject=categ.field1  
                    // }
                               
                                    //     console.log("1" + this.test);
                                    //      console.log("2" +this.myobject);
                                    //    console.log(categ.Id);
                                 
                    }

                }
            
        )
        
        // this.categoryservice.getorgdictionary().subscribe(
        //     response=>{this.relation=response;}           
        // )

        

    }

    AddCategory()
    {
        this.router.navigate(['categoriesedit/'])

    }

    SearchCategory()
    {
        console.log(this.keyword+"  "+this.keyword2);

       if((this.keyword!=undefined || this.keyword!="")){
       
        this.categoryservice.searchParentCategories(this.isparent,this.keyword,this.keyword2).subscribe(
            response=>{this.categorymodal=response;
                for(let categ of this.categorymodal){

                    if(categ.IS_ACTIVE==true)
                    {
                        categ.Is_actve="Yes"
                    }
                    else{
                        categ.Is_actve="No"
                    }
                  //  categ.UpdatedDate=this.datepipe.transform(categ.UpdatedDate, 'dd.MM.yyyy');

                    //to get default category name
                    if(categ.categoryName==null || categ.categoryName=="undefined"){
                      this.categoryservice.GetDefaultName(categ.Id).subscribe(
                          response=> {categ.categoryName=response                           
                          }
                      )
                    }
             }
             for(let defaultname of this.defaultNameList){
              
                 if(this.keyword!=""){
                       if(defaultname.categoryName.toLowerCase().includes(this.keyword.toLowerCase()))
                        {
                        

                           
                                this.categorymodal.push(defaultname)
                                
                            
                        
            
                        }
                    }
             }

            }
        )
       
       

      }
    }

    editRecord(categoryModal)
    {
        
        this.router.navigate(['categoriesedit/'], { queryParams: { Id: categoryModal.Id } });
    }
    
    GetName(name,index)
    {
   //  return this.relation[index].field;
        return name.organization_name + index;
     } 

    ManageOrder()
    {
        this.displaycat1=true
        
        this.categoryservice.getParentCategories().subscribe(
            response=>{
                this.categoryOrder=response
                for(let categ of this.categoryOrder){
                   
                  
                   
                        if(categ.IS_ACTIVE==true)
                        {
                            categ.Is_actve="Yes"
                        }
                        else{
                            categ.Is_actve="No"
                        }
                      //  categ.UpdatedDate=this.datepipe.transform(categ.UpdatedDate, 'dd.MM.yyyy');

                    
                    //to get default category name
                    if(categ.categoryName==null || categ.categoryName=="undefined"){
                      this.categoryservice.GetDefaultName(categ.Id).subscribe(
                          response=> {categ.categoryName=response                           
                          }
                      )
                    }
                  
                //console.log(this.categoryOrder)
            }
        }
        )

    }

    changeOrder()
    {
     //console.log(this.category)
     for(let categ of this.categoryOrder){
      this.changedlist.push(categ.Id)
     }
     this.categoryservice.changeOrder(this.changedlist).subscribe(

     )
     this.categorymodal=this.categoryOrder;
     for(let categ of this.categorymodal){
                   
        //to get default category name
        if(categ.categoryName==null || categ.categoryName=="undefined"){
          this.categoryservice.GetDefaultName(categ.Id).subscribe(
              response=> {categ.categoryName=response                           
              }
          )
        }
      }
     this.displaycat1=false;
    
     this.msgs = [];
     this.msgs.push({severity:'success',detail:"Categories order updated successfully"});
    
    }

    goback()
    {
        this.displaycat1=false
      
            this.router.navigate(['categories/'])

        
    }
}


