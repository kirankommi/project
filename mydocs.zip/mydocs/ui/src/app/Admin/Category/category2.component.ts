import {Component, OnInit} from '@angular/core';
import { CategoryService } from './category.service';
import { CategoryModal } from './Category.modal';
import { Router, ActivatedRoute } from '@angular/router';
import { DatePipe } from '@angular/common';
import { Message } from 'primeng/components/common/message';

@Component({
selector : 'pm-category2',
templateUrl : './category2.component.html'
})

export class Category2Component  implements OnInit
{
   

 
    isparent: boolean=false;
    keyword:string; 
    msgs:Message[];
    loading: boolean;
    defaultNameList:CategoryModal[]=[];
    keyword2:string;
    changeorderflag:boolean;
    categoryOrder:CategoryModal[];
     changedlist:number[]=[];
     displaycat1:boolean=false;
    headername:string[];
    cols: any[];
    defaultflagpush:boolean;
    categorymodal:CategoryModal[];

    constructor(private categoryservice:CategoryService,public datepipe:DatePipe,private router:Router) { }

    ngOnInit() {
        this.loading = true;
       
       
       
        this.categoryservice.GetChildCategories().subscribe(
            response=>{this.categorymodal=response;
              

        for(let categ of this.categorymodal){
                        
            if(categ.IS_ACTIVE==true)
            {
                categ.Is_actve="Yes"
            }
            else{
                categ.Is_actve="No"
            }

            //categ.UpdatedDate=this.datepipe.transform(categ.UpdatedDate, 'dd.MM.yyyy');
            //to get default category name
            if(categ.categoryName==null || categ.categoryName=="undefined"){
            this.categoryservice.GetDefaultName(categ.Id).subscribe(
                response=> {categ.categoryName=response      
                    
                    this.defaultNameList.push(categ)                     
                }
            )  

            }

            //to get default parent category name
            if(categ.ParentCategory==null || categ.ParentCategory=="undefined"){
                this.categoryservice.GetDefaultName(categ.Parent_Category_ID).subscribe(
                    response=> {categ.ParentCategory=response  
                        this.defaultflagpush = false
                        //for(let dcateg of this.defaultNameList){
                     if(!this.defaultNameList.includes(categ))
                     {
                            
                        this.defaultNameList.push(categ);
                            
                     }
                       
                    //    if(this.defaultflagpush==false)
                    //    {
                    //     this.defaultNameList.push(categ)
                    //    } 
                                                  
                    }
                )  
    
                }

         }
        } 
        
        )
    }

    AddCategory()
    {
        this.router.navigate(['categories2edit/'])

    }

    editRecord(categoryModal)
    {
        
        this.router.navigate(['categories2edit/'], { queryParams: { Id: categoryModal.Id } });
    }

    SearchCategory()
    {
        if(this.keyword!=undefined || this.keyword2!=undefined){
        this.categoryservice.searchParentCategories(this.isparent,this.keyword,this.keyword2).subscribe(
            response=>{this.categorymodal=response;
                for(let categ of this.categorymodal){
                        
                    if(categ.IS_ACTIVE==true)
                    {
                        categ.Is_actve="Yes"
                    }
                    else{
                        categ.Is_actve="No"
                    }
                   // categ.UpdatedDate=this.datepipe.transform(categ.UpdatedDate, 'dd.MM.yyyy');

                    //to get default category name
                    if(categ.categoryName==null || categ.categoryName=="undefined"){
                    this.categoryservice.GetDefaultName(categ.Id).subscribe(
                        response=> {categ.categoryName=response                           
                        }
                    )   
        
                    }

                     //to get default parent category name
                    if(categ.ParentCategory==null || categ.ParentCategory=="undefined"){
                      this.categoryservice.GetDefaultName(categ.Parent_Category_ID).subscribe(
                    response=> {categ.ParentCategory=response                           
                    }
                   )  
    
                }
                 }
                
               

                 for(let defaultname of this.defaultNameList){
                    this.defaultflagpush=false
                    if(this.keyword==undefined || this.keyword==""){
                        if(defaultname.categoryName.toLowerCase().includes(this.keyword2.toLowerCase()) )
                        {
                            
                            for(let categ1 of this.categorymodal){

                                if(categ1.Id==defaultname.Id){
                                   this.defaultflagpush=true
                                }
                            }
                            if(this.defaultflagpush==false){
                                this.categorymodal.push(defaultname);
                            }   
                                  
                                       
                                
                           
                        }

                    
                    }
                    
                    else{
                        if(this.keyword2==undefined || this.keyword2==""){
                            if(defaultname.ParentCategory.toLowerCase().includes(this.keyword.toLowerCase()) )
                            {
                                for(let categ1 of this.categorymodal){

                                    if(categ1.Id==defaultname.Id){
                                       this.defaultflagpush=true
                                    }
                                }
                                if(this.defaultflagpush==false){
                                    this.categorymodal.push(defaultname);
                                } 
                                       
                              
                            }
    
                        
                        }
                        else{
                            if(defaultname.ParentCategory.toLowerCase().includes(this.keyword.toLowerCase()) && defaultname.categoryName.toLowerCase().includes(this.keyword2.toLowerCase()) )
                            {
                               
                                       
                                for(let categ1 of this.categorymodal){

                                    if(categ1.Id==defaultname.Id){
                                       this.defaultflagpush=true
                                    }
                                }
                                if(this.defaultflagpush==false){
                                    this.categorymodal.push(defaultname);
                                } 
                                       
                               
                            }
                        }

                    }
                  
                 }
            }
        )
        


      }
    }

    

    ManageOrder()
    {
        this.displaycat1=true
        
        this.categoryservice.GetChildCategories().subscribe(
            response=>{
                this.categoryOrder=response
                for(let categ of this.categoryOrder){
                   

                    if(categ.IS_ACTIVE==true)
                    {
                        categ.Is_actve="Yes"
                    }
                    else{
                        categ.Is_actve="No"
                    }
                   // categ.UpdatedDate=this.datepipe.transform(categ.UpdatedDate, 'dd.MM.yyyy');

                    //to get default category name
                    if(categ.categoryName==null || categ.categoryName=="undefined"){
                      this.categoryservice.GetDefaultName(categ.Id).subscribe(
                          response=> {categ.categoryName=response                           
                          }
                      )
                    }
                  }
                //console.log(this.categoryOrder)
            }
        )

    }

    changeOrder()
    {
     //console.log(this.category)
     for(let categ of this.categoryOrder){
      this.changedlist.push(categ.Id)
     }
     this.categoryservice.changeOrder(this.changedlist).subscribe(

     )
     this.categorymodal=this.categoryOrder;
     for(let categ of this.categorymodal){
                   
        //to get default category name
        if(categ.categoryName==null || categ.categoryName=="undefined"){
          this.categoryservice.GetDefaultName(categ.Id).subscribe(
              response=> {categ.categoryName=response                           
              }
          )
        }
        //to get default parent category name
        if(categ.ParentCategory==null || categ.ParentCategory=="undefined"){
            this.categoryservice.GetDefaultName(categ.Parent_Category_ID).subscribe(
                response=> {categ.ParentCategory=response                           
                }
            )
          }
      }
     this.displaycat1=false;
     this.msgs = [];
     this.msgs.push({severity:'success',detail:"Categories order updated successfully"});
    }

   

    goback()
    {
        this.displaycat1=false
        
            this.router.navigate(['categories2/'])

        
    }
}
