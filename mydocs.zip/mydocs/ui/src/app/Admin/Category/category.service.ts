import {HttpModule, Http,Response,RequestOptions} from '@angular/http';
import {Injectable} from '@angular/core';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../../environments/environment';



@Injectable()
export class CategoryService {
    //hostURL : string = "http://nzur467991dww.ubsprod.msad.ubs.net/CMRAPI/api/";
   // hostURL :string ="http://localhost:58349/api/";
    hostURL :string =environment.baseUrl;
    [x: string]: any;

    constructor(private http: Http) {}
    
    getParentCategories() {   
        var languageId=sessionStorage.getItem('LanguageId');
        return this.http.get(this.hostURL + 'category/GetParentCategories/'+ languageId)
        .map((res:Response)=> res.json() )
        .catch(this.handleError)
    }
    GetChildCategories(){
        var languageId=sessionStorage.getItem('LanguageId');
        return this.http.get(this.hostURL + 'category/GetChildCategories/'+ languageId)
        .map((res:Response)=> res.json() )
        .catch(this.handleError)
    }
    
    searchParentCategories(isparent:boolean,keyword1:string,keyword2:string) {   
        var languageId=sessionStorage.getItem('LanguageId');
        
        if(keyword2=="")
        {
            keyword2=undefined
        }
        if(keyword1=="")
        {
            keyword1=undefined
        }
        return this.http.get(this.hostURL + 'category/GetCategory/'+isparent+'/'+ languageId+'/'+keyword1+'/'+keyword2)
        .map((res:Response)=> res.json() )
        .catch(this.handleError)
    }

    GetOrganizations() {         
       
        return this.http.get(this.hostURL + 'Organization/GetOrganizations')
        .map((res:Response)=> res.json() )
        .catch(this.handleError)
    }

    AddCategory(category) {         
       
        return this.http.post(this.hostURL + 'category/AddCategory',category)
        .map((res:Response)=> res.json() )
        .catch(this.handleError)
    }
   

    getCategory(categoryid) {         
       
        return this.http.get(this.hostURL + 'category/GetCategory/'+categoryid)
        .map((res:Response)=> res.json() )
        .catch(this.handleError)
    }

    getorgdictionary() {         
       
        return this.http.get(this.hostURL + 'category/GetCatOrgMapping')
        .map((res:Response)=> res.json() )
        .catch(this.handleError)
    }

    
    getorganlistCategory(categoryid) {         
       
        return this.http.get(this.hostURL + 'category/Getflagarray/'+categoryid)
        .map((res:Response)=> res.json() )
        .catch(this.handleError)
    }

    changeOrder(updatelist:any){
        return this.http.post(this.hostURL + 'category/changeOrder',updatelist)
        .map((res:Response)=> res.json() )
        .catch(this.handleError)
    }

    GetDefaultName(CategoryId){
        return this.http.get(this.hostURL + 'category/GetDefaultName/'+CategoryId)
        .map((res:Response)=> res.json() )
        .catch(this.handleError)
    }

    private handleError(error: Response) {
        return Observable.throw(error.statusText);
    }

 }