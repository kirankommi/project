import {Component, OnInit} from '@angular/core';
import { CategoryService } from './category.service';
import { CategoryModal } from './Category.modal';
import { NgForm,FormGroup, FormControl,FormBuilder, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { Router,ActivatedRoute } from '@angular/router';
import { Message } from 'primeng/components/common/message';



@Component({
selector : 'pm-categoryedit',
templateUrl : './Pcategoryedit.component.html'
})

export class PCategoryEditComponent {

    category:CategoryModal=new CategoryModal();
    myForm:FormGroup;
    successmsg:string;
    editflag:boolean;
    msgs: Message[];
    saveflag:boolean;
    validationflag:boolean;
   
    constructor(private categoryservice:CategoryService, private formBuilder: FormBuilder,private router:Router, private route: ActivatedRoute) { }
    ifsuccessmsg:boolean=false
   // editflag:boolean=false

    ngOnInit()
    {
        this.myForm = this.formBuilder.group({
            'catnameen': new FormControl(''),
            'catdescen': new FormControl(''),
            'catnamede': new FormControl(''),
            'catdescde': new FormControl(''),
            'catnamefr': new FormControl(''),
            'catdescfr': new FormControl(''),
            'catnameit': new FormControl(''),
            'catdescit': new FormControl(''),
        });

    
       
       

        this.category.IS_ACTIVE=true
        this.route
        .queryParams
        .subscribe(params => {
          this.category.Id = +params['Id'] || 0;
        if(this.category.Id!=0){
            this.category.editflag=true
        }
          
        });
        
        if(this.category.editflag)
        {
          
           this.categoryservice.getCategory(this.category.Id).subscribe(
               response=>{this.category=response
              
            }
           )
        }
         this.editflag=this.category.editflag
      

    }



    onSubmit() {                  
        this.validationflag=false;
          
        
        if((this.myForm.get('catnamede').value != null && this.myForm.get('catnamede').value != '')
           && (this.myForm.get('catnameen').value != null && this.myForm.get('catnameen').value != '' )
            && (this.myForm.get('catnamefr').value != null && this.myForm.get('catnamefr').value !='' )
            && (this.myForm.get('catnameit').value != null && this.myForm.get('catnameit').value !='' ))
        {
     

        

       this.category.editflag= this.editflag    
   

   
        
        if(this.category.editflag){
            this.category.LAST_UPDATED_BY=sessionStorage.getItem('GPN');
        }
        else{
            this.category.LAST_UPDATED_BY=sessionStorage.getItem('GPN');
            this.category.CREATED_BY=sessionStorage.getItem('GPN');
        }

        

       
       
       

        this.categoryservice.AddCategory(this.category).subscribe(
            
            response=>{
                this.successmsg=response
                if(this.successmsg=="Category name already exists")
                {
                    this.msgs = [];
                    this.msgs.push({severity:'error',detail:"Category name already exists"});
                } 
                else{
                    this.msgs = [];
                    this.saveflag=true; 
           
                    this.msgs.push({severity:'success',detail:this.successmsg});
                }
              
                                    
        
            },
            (error)=>{ 
                this.msgs = [];
                this.msgs.push({severity:'error',detail:"Unable to add or edit category due to some server error"});     
             }
            
        )
      
        }
        else
        {
          //  this.validationflag=true;
            this.msgs = [];
            this.msgs.push({severity:'error',detail:"Please fill out names in all languages"});
          
        }
         
        this.ifsuccessmsg=false
       

      }
      
      onReset()
      {  
          this.category= new CategoryModal();
           this.msgs = [];
          this.saveflag=false;
      }

     
}