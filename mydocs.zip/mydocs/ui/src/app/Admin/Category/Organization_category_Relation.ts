export class Organization_Categories
{
        Id:number;
        Organization_Id :number;
        Category_Id :number;    
}        