import {HttpModule, Http,Response,RequestOptions} from '@angular/http';
import {Injectable} from '@angular/core';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Observable';
import { InfotextModal } from './infotext.modal';
import { environment } from '../../../environments/environment'

@Injectable()
export class InfoTextService {
    hostURL :string =environment.baseUrl;
    [x: string]: any;

    constructor(private http: Http) {}
    
    getInfoText() {        
        return this.http.get(this.hostURL + 'infotext/GetTextInfo')
        .map((res:Response)=> res.json() )
        .catch(this.handleError)
    }

    updateInfoText( infoobj:InfotextModal) {      
        return this.http.post(this.hostURL + 'infotext/UpdateTextInfo',infoobj)
        .map((res:Response)=> res.json() )
        .catch(this.handleError)
    }

    private handleError(error: Response) {
        return Observable.throw(error.statusText);
    }
 }