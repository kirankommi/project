import {Component} from '@angular/core';
import { InfoTextService } from './infotext.service';
import { MenuItem } from 'primeng/components/common/api';
import { Message } from 'primeng/components/common/message';
import { InfotextModal } from './infotext.modal';


@Component({
selector : 'pm-infotext',
templateUrl : './infotext.component.html'
})

export class InfoTextComponent
{
    // items: MenuItem[];
    
    // activeItem: MenuItem;
        text1: string='';       
        text2: string='' ;       
        text3: string='' ;       
        text4: string='';       
        successmsg:string;
        charactercount:number;
        charactercount1:number;
        charactercount2:number;
        charactercount3:number;
        msgs: Message[];
        ifsuccessmsg:boolean;
        infoobj:InfotextModal=new InfotextModal();
    // languageId=sessionStorage.getItem('LanguageId');

    constructor(private infotextservice:InfoTextService){

    }

    ngOnInit() {
        this.infotextservice.getInfoText().
        subscribe(response=>
        {
            this.text1=response[0]
            this.text2=response[1]
            this.text3=response[2]
            this.text4=response[3]          

        }
        );

        
        
    
    }

    save(){
        this.infoobj.EnDesc=this.text1
        this.infoobj.GeDesc=this.text2
        this.infoobj.FrDesc=this.text3
        this.infoobj.ItDesc=this.text4

       

        this.infotextservice.updateInfoText(this.infoobj).
        subscribe(response=>
            { this.successmsg=response
                if(this.successmsg=="Text Added successfully")
                { this.msgs = [];
                this.msgs.push({severity:'success',detail:this.successmsg});
                }
                else{
                    this.msgs = [];
                    this.msgs.push({severity:'error',detail:"Please Add text in all languages"});
                }
               
            },
            (error)=>{ 
                this.msgs = [];
                this.msgs.push({severity:'error',detail:"Unable to update infotext due to some server error"});     
             }

        );
     
    }

    textChanged($event) {
       
        this.charactercount=$event.textValue.length;
        this.msgs = [];
        if((this.charactercount-1)>2000)
        {this.msgs.push({severity:'error',detail:"Additional Information Box Editor English text can't exceed 2000 characters"});
    }
    
  }

  textChanged1($event) {
     
      this.charactercount1=$event.textValue.length;
      this.msgs = [];
      if((this.charactercount1-1)>2000)
        {this.msgs.push({severity:'error',detail:"Additional Information Box Editor German text can't exceed 2000 characters"});
    }
    
  }

  
  textChanged2($event) {
     
      this.charactercount2=$event.textValue.length;
      this.msgs = [];
      if((this.charactercount2-1)>2000)
      {this.msgs.push({severity:'error',detail:"Additional Information Box Editor French text can't exceed 2000 characters"});
      }
    
  }

  
  textChanged3($event) {
     
      this.charactercount3=$event.textValue.length;
      this.msgs = [];
      if((this.charactercount3-1)>2000)
      {this.msgs.push({severity:'error',detail:"Additional Information Box Editor Italian text can't exceed 2000 characters"});
       }
    
  }

   
    
    onTabChange(event) {
        this.msgs = [];
        this.msgs.push({severity:'info', summary:'Tab Expanded', detail: 'Index: ' + event.index});
    }
}



