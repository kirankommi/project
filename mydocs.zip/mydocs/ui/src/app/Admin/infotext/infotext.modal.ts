export class InfotextModal
{
    EnDesc: string;
    GeDesc:string;
    FrDesc: string;
    ItDesc: string;
}