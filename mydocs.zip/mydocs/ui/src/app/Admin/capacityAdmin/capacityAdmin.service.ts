import {HttpModule, Http,Response,RequestOptions} from '@angular/http';
import {Injectable} from '@angular/core';
import { Observable } from "rxjs/Observable";
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import {DatePipe} from "@angular/common";

import { CapacityAdmin ,Capacity } from "./capacityAdmin";
import { Options } from 'selenium-webdriver/edge';
import { environment } from '../../../environments/environment';

@Injectable()
export class CapacityAdminService {
    [x: string]: any;
  //baseUrl : string = "http://nzur467991dww.ubsprod.msad.ubs.net/CMRAPI/api/";
  //baseUrl :string ="http://localhost:58349/api/";
   baseUrl= environment.baseUrl;
    constructor(private http: Http,public datepipe:DatePipe) {}
    // getCapacity(): Observable<capacityAdmin> {
    //     return this.http.get(this.baseUrl + 'capacity/GetCapacity/')
    //     .map((res:Response)=> res.json())
    //     .catch(this.handleError)
    // }

    getCapacity(isActive): Observable<CapacityAdmin> {
        return this.http.get(this.baseUrl + 'Capacity/GetCapacity/'+isActive)
        .map((res:Response)=> res.json() as CapacityAdmin)
        .catch(this.handleError)
    }
   
    saveUserCapacity(capacity:Capacity) {           
        return this.http.post(this.baseUrl + 'Capacity/SaveCapacity', capacity)
        .map((res:Response)=> res.json())     
        .catch(this.handleError)	    
     }
     saveUserCapacityList(capacityList:Capacity[]) {           
        return this.http.post(this.baseUrl + 'Capacity/SaveCapacityList', capacityList)
        .map((res:Response)=> res.json())     
        .catch(this.handleError)	    
     }
     saveCapacityDetails(capacityDetails: Capacity[]) {           
        return this.http.post(this.baseUrl + 'Capacity/SaveCapacityDetails', capacityDetails)
        .map((res:Response)=> res.json())     
        .catch(this.handleError)	    
     }
    //  uploadFile(uploadedFiles) {           
    //     return this.http.post(this.baseUrl + 'Capacity/UploadFile', uploadedFiles)
    //     .map((res:Response)=> res.json())     
    //     .catch(this.handleError)	    
    //  }
   
     getExport():  Observable<Object[]> {
        return Observable.create(observer => {
            let xhr = new XMLHttpRequest();
         
            xhr.open('GET', this.baseUrl+'Capacity/ExportCapacity',true);
            //+'/'+searchFilters.gpn+'/'+searchFilters.ou+'/'+searchFilters.search+'/'+searchFilters.categoryId+'/'+searchFilters.dateFrom+'/'+searchFilters.dateTo+'/'+searchFilters.recurrenceId+'/'+searchFilters.savedBy+'/'+searchFilters.uploaded+'/'+searchFilters.languageId
            xhr.setRequestHeader('Content-type', 'application/json');
            xhr.responseType='blob';
    
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4) {
                    if (xhr.status === 200) {
    
                        var contentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
                        var blob = new Blob([xhr.response], { type: contentType });
                        observer.next(blob);
                        observer.complete();
                    } else {
                        observer.error(xhr.response);
                    }
                }
            }
           // let para= JSON.stringify({searchFilters})
        //  let para=searchFilters.gpn+searchFilters.ou+searchFilters.search+searchFilters.categoryId+searchFilters.dateFrom+searchFilters.dateTo+searchFilters.recurrenceId+searchFilters.savedBy+searchFilters.uploaded+searchFilters.languageId
       //  let para= "gpn="+searchFilters.gpn+'&'+"ou="+searchFilters.ou+'&'+"search="+searchFilters.search+'&'+"categoryId="+searchFilters.categoryId+'&'+"dateFrom="+searchFilters.dateFrom+'&'+"dateTo="+searchFilters.dateTo+'&'+"recurrencyId="+searchFilters.recurrenceId+'&'+"savedBy="+searchFilters.savedBy+'&'+"uploaded="+searchFilters.uploaded+'&'+"languageId="+searchFilters.languageId
         
            xhr.send();
    
        });
    }  
    // uploadFile(uploadedFiles: File) {
    //     const _formData = new FormData();
    //     _formData.append('file', uploadedFiles, uploadedFiles.name);   
    //     return this.http.post(this.baseUrl + 'Capacity/UploadFile', _formData);
    //   }

    UploadFile(uploadedFiles: File) {           
        return this.http.post(this.baseUrl + 'Capacity/UploadFile', uploadedFiles)
        .map((res:Response)=> res.json())     
        .catch(this.handleError)	    
     }

      getSortData(event,isActive): Observable<CapacityAdmin> {
        return this.http.get(this.baseUrl + 'Capacity/GetSortedList/'+'/'+event.field+'/'+event.order+'/'+isActive)
        .map((res:Response)=> res.json() as CapacityAdmin)
        .catch(this.handleError)
    }

    private handleError(error: Response) {
        return Observable.throw(error.statusText);
    }
}