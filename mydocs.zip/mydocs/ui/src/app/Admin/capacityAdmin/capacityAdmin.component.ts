import { Component, OnInit, Input, Directive, ViewChild } from '@angular/core';
import { CapacityAdmin, Capacity, CapacityDetails, ActiveDeactive } from './capacityAdmin';
import { CapacityAdminService } from './capacityAdmin.service';
import { DataTable } from 'primeng/components/datatable/datatable';
import { Message } from 'primeng/components/common/api';
import { RequestOptions } from '@angular/http';
import {HttpModule, Http,Response} from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { ConfirmationService } from 'primeng/components/common/confirmationservice';
import {Validators,FormControl,FormGroup,FormBuilder} from '@angular/forms';
import { environment } from '../../../environments/environment';
@Component({
    selector: 'pm-capacity',
    templateUrl: './capacityAdmin.component.html'
})

export class CapacityAdminComponent {
 
    IsActive: boolean;
    @ViewChild('fileInput') fileInput;
    Id: number;
    capacityList: Capacity[];
    addList: Capacity[];
    addList1: Capacity[];
    capacityDetailList: CapacityDetails[];
    selectedRows: Capacity;
    displayDialog: boolean;
    newValue: boolean;
    OU: string;
    GPN: string;
    LastName: string;
    FirstName: string;
    Pensum: number;
    entity: Capacity = new Capacity();
    msgs: Message[] = [];
    msgs1: Message[] = [];
    errorMessage: boolean;
  //  isActive: boolean = true;
    capacityDetailSelected = [];
    timestamp: Date;
    Month0: number;
    Month1: number;
    Month2: number;
    Month3: number;
    Month4: number;
    Month5: number;
    Month6: number;
    Month7: number;
    Month8: number;
    Month9: number;
    Month10: number;
    Month11: number;
    Month12: number;
    Month13: number;
    //isDisabled :boolean=true;
    headers: string[];
    CreateBy : string;
    CreateDate : Date;
    fileToUpload: File = null;
    LastUploadDate:string;
    LastEditDate:string;
    uploadedFiles: any[] = [];
    deleterowchecked : boolean = false;
    deleterow
    isActiveRecord: boolean=true;
    userform: FormGroup;
    activestate: ActiveDeactive[];
    selectedstate : ActiveDeactive;
    firstrow:number = 0;
    displayProgressbar:boolean = false;
    baseUrl= environment.baseUrl;

    

    constructor(private fb: FormBuilder,private capacityAdminService: CapacityAdminService,private http: Http,private confirmationService: ConfirmationService) {
        this.activestate = [
            {name: 'Active', code: true},
            {name: 'Inactive', code: false},
          
        ];
        this.errorMessage = true;
    }
    ngOnInit() {

        this.userform = this.fb.group({
            'LastName': new FormControl('', Validators.required),
            'FirstName': new FormControl('', Validators.required),
            'GPN': new FormControl('',  Validators.required),
            
            'OU': new FormControl('', Validators.required),
            'Pensum': new FormControl('', this.ValidatePensum.bind(this)),  
         
          });
        this.Pensum = 1;
        this.capacityAdminService.getCapacity(this.isActiveRecord)
            .subscribe(capacity => {
                this.capacityList = capacity.CapacityList;
                //console.log(this.capacityList);
                this.capacityDetailList = this.capacityList[0].CapacityDetailsList;
                this.headers = capacity.headers;
                this.LastEditDate =capacity.LastEditDate;
                this.LastUploadDate =capacity.LastUploadDate;
                for (let item of this.capacityList) {
                    item.Month0 = item.CapacityDetailsList[0] != null ? item.CapacityDetailsList[0].Value : null;
                    item.Month1 = item.CapacityDetailsList[1] != null ? item.CapacityDetailsList[1].Value : null;
                    item.Month2 = item.CapacityDetailsList[2] != null ? item.CapacityDetailsList[2].Value : null;
                    item.Month3 = item.CapacityDetailsList[3] != null ? item.CapacityDetailsList[3].Value : null;
                    item.Month4 = item.CapacityDetailsList[4] != null ? item.CapacityDetailsList[4].Value : null;
                    item.Month5 = item.CapacityDetailsList[5] != null ? item.CapacityDetailsList[5].Value : null;
                    item.Month6 = item.CapacityDetailsList[6] != null ? item.CapacityDetailsList[6].Value : null;
                    item.Month7 = item.CapacityDetailsList[7] != null ? item.CapacityDetailsList[7].Value : null;
                    item.Month8 = item.CapacityDetailsList[8] != null ? item.CapacityDetailsList[8].Value : null;
                    item.Month9 = item.CapacityDetailsList[9] != null ? item.CapacityDetailsList[9].Value : null;
                    item.Month10 = item.CapacityDetailsList[10] != null ? item.CapacityDetailsList[10].Value : null;
                    item.Month11 = item.CapacityDetailsList[11] != null ? item.CapacityDetailsList[11].Value : null;
                    item.Month12 = item.CapacityDetailsList[12] != null ? item.CapacityDetailsList[12].Value : null;
                    item.Month13 = item.CapacityDetailsList[13] != null ? item.CapacityDetailsList[13].Value : null;
                    //item.IsActive = true;
                }
                console.log(this.capacityList);
                //this.capacityList[0].CapacityDetailsList0 = capacity.CapacityList[0].CapacityDetailsList[0];
                //    this.capacityDetailList = capacity.CapacityList[0].CapacityDetailsList;

                //   console.log(this.capacityDetailList);


                //         for(let selectedSegment of this.capacityDetailList)
                //             {
                //                 this.capacityDetailSelected.push(selectedSegment)
                //             }

                // console.log( this.capacityDetailSelected);
                //    for(let a of this.capacityList)
                //    {   
                //        a.CapacityDetailsList.forEach(obj=>this.capacityDetailSelected.push(obj));
                //    }
                //    console.log( this.capacityDetailSelected);
            });
            
    }
    GetName(name,index)
    {
        return name+index;
    }
    onOUSort(event)
    {
        console.log(event);
        this.capacityAdminService.getSortData(event,this.isActiveRecord)
        .subscribe(capacity => {
            this.capacityList = capacity.CapacityList;
            //console.log(this.capacityList);
            this.capacityDetailList = this.capacityList[0].CapacityDetailsList;
            this.headers = capacity.headers;
            this.LastEditDate =capacity.LastEditDate;
            this.LastUploadDate =capacity.LastUploadDate;
            for (let item of this.capacityList) {
                item.Month0 = item.CapacityDetailsList[0] != null ? item.CapacityDetailsList[0].Value : null;
                item.Month1 = item.CapacityDetailsList[1] != null ? item.CapacityDetailsList[1].Value : null;
                item.Month2 = item.CapacityDetailsList[2] != null ? item.CapacityDetailsList[2].Value : null;
                item.Month3 = item.CapacityDetailsList[3] != null ? item.CapacityDetailsList[3].Value : null;
                item.Month4 = item.CapacityDetailsList[4] != null ? item.CapacityDetailsList[4].Value : null;
                item.Month5 = item.CapacityDetailsList[5] != null ? item.CapacityDetailsList[5].Value : null;
                item.Month6 = item.CapacityDetailsList[6] != null ? item.CapacityDetailsList[6].Value : null;
                item.Month7 = item.CapacityDetailsList[7] != null ? item.CapacityDetailsList[7].Value : null;
                item.Month8 = item.CapacityDetailsList[8] != null ? item.CapacityDetailsList[8].Value : null;
                item.Month9 = item.CapacityDetailsList[9] != null ? item.CapacityDetailsList[9].Value : null;
                item.Month10 = item.CapacityDetailsList[10] != null ? item.CapacityDetailsList[10].Value : null;
                item.Month11 = item.CapacityDetailsList[11] != null ? item.CapacityDetailsList[11].Value : null;
                item.Month12 = item.CapacityDetailsList[12] != null ? item.CapacityDetailsList[12].Value : null;
                item.Month13 = item.CapacityDetailsList[13] != null ? item.CapacityDetailsList[13].Value : null;
                //item.IsActive = true;
            }
          
        });
    }
    showDialogToAdd() {
        this.msgs1 = [];
        this.userform.markAsPristine();
        this.userform.markAsUntouched();
        this.userform.updateValueAndValidity(); 
        this.addList = this.capacityList.filter(x => x.isSelected != undefined && x.isSelected)
        var count = this.addList.length;

        if( count == 1 && this.addList[0] != null && this.addList[0] != undefined)
        {
          this.Id = this.addList[0].Id;
          this.FirstName= this.addList[0].FirstName;
          this.LastName= this.addList[0].LastName;
          this.GPN = this.addList[0].GPN;
          this.Pensum = this.addList[0].Pensum;
          this.OU = this.addList[0].OU;
          this.CreateBy = this.addList[0].CreateBy;
          this.CreateDate = this.addList[0].CreateDate;
          this.IsActive = this.addList[0].IsActive;
          this.displayDialog = true;
          
        }
        else if(count>1)
        {
            this.msgs = [];
         this.msgs.push({severity:'error', detail:'Please select only one Capacity to edit.'});
        }
        else
        {
            this.FirstName= "";
            this.LastName= "";
            this.GPN = "";
            this.Pensum = 1;
            this.OU = "";
          
        this.displayDialog = true;
        }
        
    }
    ValidatePensum(control: FormControl) { 
        if(control.value === null || control.value === '' || control.value === undefined){
            return {ValidatePensum: true};
        }
        else{      
            return (control.value <= 1) ? null : {
                ValidatePensum: true}
        }
        
    }
      
    // BeforeUpload(event)
    // {
    //     if(event.files[0].name.indexOf(".xlsx") != -1)
    //     {
    //    this.onBasicUpload(event);
    //     }
    //     else{
    //         this.msgs = [];
    // this.msgs.push({ severity: 'error', detail: 'Please select .xlsx file format' });
    //     }
    // }
    BeforeUpload(event)
    {
         if(event.files[0].name.indexOf(".xlsx") == -1)
    {
        this.msgs = [];
        this.msgs.push({ severity: 'error', detail: 'Please select .xlsx file format' });
    }
   
        }

        Error(event)
        {
            this.msgs = [];
        this.msgs.push({ severity: 'error', detail: 'Files could not be uploaded' });
        }

    onBasicUpload(event) {
    for(let file of event.files) {
        this.uploadedFiles.push(file);
    }


    // this.capacityAdminService.UploadFile(event)
    // .subscribe(response => {
    //     this.msgs = [];
    //     this.msgs.push({ severity: 'success', detail: 'Deleted successfully' });
       
    // },
    //     err => {
    //         this.errorMessage = true;
    //         this.msgs = [];
    //         this.msgs.push({ severity: 'error', detail: 'Entry Cannot be deleted' });
    //         console.log(err);
    //     }
    // );

    this.msgs = [];
    this.msgs.push({ severity: 'success', detail: 'File Uploaded successfully.' });
}
    GetHeder(month) {
        if (this.capacityDetailList == null || this.capacityDetailList == undefined) return '';
        return this.headers[month];//.filter(x => x.DynamicColumnName == month).map(l => l.Month);

    }
    savePopuUp() {
       if(this.userform.valid)
       {
        this.entity.FirstName = this.FirstName;
        this.entity.LastName = this.LastName;
        this.entity.GPN = this.GPN;
        this.entity.OU = this.OU;
        this.entity.Pensum = this.Pensum;
        this.entity.Id = this.Id;
        this.entity.IsActive = this.IsActive;
        this.entity.CreateBy = this.CreateBy;
        this.entity.CreateDate = this.CreateDate;
        this.capacityAdminService.saveUserCapacity(this.entity).subscribe(
            response => {
                this.msgs = [];
                this.msgs.push({ severity: 'success', detail: 'Capacity saved successfully.' });
                this.capacityAdminService.getCapacity(this.isActiveRecord)
                    .subscribe(capacity => {
                        this.capacityList = capacity.CapacityList;
                        this.capacityDetailList = this.capacityList[0].CapacityDetailsList;
                        this.headers = capacity.headers;
                        for (let item of this.capacityList) {
                            item.Month0 = item.CapacityDetailsList[0] != null ? item.CapacityDetailsList[0].Value : null;
                            item.Month1 = item.CapacityDetailsList[1] != null ? item.CapacityDetailsList[1].Value : null;
                            item.Month2 = item.CapacityDetailsList[2] != null ? item.CapacityDetailsList[2].Value : null;
                            item.Month3 = item.CapacityDetailsList[3] != null ? item.CapacityDetailsList[3].Value : null;
                            item.Month4 = item.CapacityDetailsList[4] != null ? item.CapacityDetailsList[4].Value : null;
                            item.Month5 = item.CapacityDetailsList[5] != null ? item.CapacityDetailsList[5].Value : null;
                            item.Month6 = item.CapacityDetailsList[6] != null ? item.CapacityDetailsList[6].Value : null;
                            item.Month7 = item.CapacityDetailsList[7] != null ? item.CapacityDetailsList[7].Value : null;
                            item.Month8 = item.CapacityDetailsList[8] != null ? item.CapacityDetailsList[8].Value : null;
                            item.Month9 = item.CapacityDetailsList[9] != null ? item.CapacityDetailsList[9].Value : null;
                            item.Month10 = item.CapacityDetailsList[10] != null ? item.CapacityDetailsList[10].Value : null;
                            item.Month11 = item.CapacityDetailsList[11] != null ? item.CapacityDetailsList[11].Value : null;
                            item.Month12 = item.CapacityDetailsList[12] != null ? item.CapacityDetailsList[12].Value : null;
                            item.Month13 = item.CapacityDetailsList[13] != null ? item.CapacityDetailsList[13].Value : null;
                        }

                    });
                              this.Id=0;
                            this.userform.markAsPristine();
                        this.userform.markAsUntouched();
                        this.userform.updateValueAndValidity(); 
                        this.msgs1=[];
            },
            err => {
                this.errorMessage = true;
                this.msgs = [];
                this.msgs.push({ severity: 'error', detail: 'Capacity could not be saved' });
                console.log(err);
            }
        );
        this.displayDialog = false;
    }
    else
{
    this.msgs1 = [];
    this.msgs1.push({ severity: 'error', detail: 'Please fill/correct mandatory fields' });
}

}

    saveList() {


        for (let element of this.capacityList) {
            var detailCount = element.CapacityDetailsList.length;
            for (var i = 0, j = element.CapacityDetailsList.length; i < 14 - element.CapacityDetailsList.length, j < this.headers.length; i++ , j++) {
                var detailItem = new CapacityDetails();
                detailItem.Month = this.headers[j];
                detailItem.CapacityId = element.Id;
                element.CapacityDetailsList.push(detailItem);
            }
        }
       

        var top = (this.capacityList[0].Month0 != null ||  this.capacityList[0].Month1 != null || this.capacityList[0].Month2 != null || this.capacityList[0].Month3 != null || this.capacityList[0].Month4 != null
            || this.capacityList[0].Month5 != null || this.capacityList[0].Month6 != null || this.capacityList[0].Month7 != null || this.capacityList[0].Month8 != null || this.capacityList[0].Month9 != null || this.capacityList[0].Month10 != null || this.capacityList[0].Month11 != null
            || this.capacityList[0].Month12 != null || this.capacityList[0].Month13 != null) ? true : false;
        if (top) {
            this.confirmationService.confirm({
                message: 'Do you want to apply it to whole column?',
                header: 'Confirmation',
                icon: 'fa fa-question-circle',
                accept: () => {
                    this.OnOKClick();
                   // this.msgs = [{severity:'info', summary:'Confirmed', detail:'You have accepted'}];
                   for (let element of this.capacityList) {
                    element.CapacityDetailsList[0].Value = element.Month0;
                    element.CapacityDetailsList[1].Value = element.Month1;
                    element.CapacityDetailsList[2].Value = element.Month2;
                    element.CapacityDetailsList[3].Value = element.Month3;
                    element.CapacityDetailsList[4].Value = element.Month4;
                    element.CapacityDetailsList[5].Value = element.Month5;
                    element.CapacityDetailsList[6].Value = element.Month6;
                    element.CapacityDetailsList[7].Value = element.Month7;
                    element.CapacityDetailsList[8].Value = element.Month8;
                    element.CapacityDetailsList[9].Value = element.Month9;
                    element.CapacityDetailsList[10].Value = element.Month10;
                    element.CapacityDetailsList[11].Value = element.Month11;
                    element.CapacityDetailsList[12].Value = element.Month12;
                    element.CapacityDetailsList[13].Value = element.Month13;
                }
                this.displayProgressbar = true;
                   this.capacityAdminService.saveCapacityDetails(this.capacityList).subscribe(
                    response => {
                        this.displayProgressbar = false;
                        this.msgs = [];
                        this.msgs.push({ severity: 'success', detail: 'Capacity saved successfully.' });
                        // this.capacityAdminService.getCapacity(this.isActiveRecord)
                        //     .subscribe(capacity => {
                        //         this.capacityList = capacity.CapacityList;
                        //         this.capacityDetailList = this.capacityList[0].CapacityDetailsList;
                        //         this.headers = capacity.headers;
                        //         for (let item of this.capacityList) {
                        //             item.Month0 = item.CapacityDetailsList[0] != null ? item.CapacityDetailsList[0].Value : null;
                        //             item.Month1 = item.CapacityDetailsList[1] != null ? item.CapacityDetailsList[1].Value : null;
                        //             item.Month2 = item.CapacityDetailsList[2] != null ? item.CapacityDetailsList[2].Value : null;
                        //             item.Month3 = item.CapacityDetailsList[3] != null ? item.CapacityDetailsList[3].Value : null;
                        //             item.Month4 = item.CapacityDetailsList[4] != null ? item.CapacityDetailsList[4].Value : null;
                        //             item.Month5 = item.CapacityDetailsList[5] != null ? item.CapacityDetailsList[5].Value : null;
                        //             item.Month6 = item.CapacityDetailsList[6] != null ? item.CapacityDetailsList[6].Value : null;
                        //             item.Month7 = item.CapacityDetailsList[7] != null ? item.CapacityDetailsList[7].Value : null;
                        //             item.Month8 = item.CapacityDetailsList[8] != null ? item.CapacityDetailsList[8].Value : null;
                        //             item.Month9 = item.CapacityDetailsList[9] != null ? item.CapacityDetailsList[9].Value : null;
                        //             item.Month10 = item.CapacityDetailsList[10] != null ? item.CapacityDetailsList[10].Value : null;
                        //             item.Month11 = item.CapacityDetailsList[11] != null ? item.CapacityDetailsList[11].Value : null;
                        //             item.Month12 = item.CapacityDetailsList[12] != null ? item.CapacityDetailsList[12].Value : null;
                        //             item.Month13 = item.CapacityDetailsList[13] != null ? item.CapacityDetailsList[13].Value : null;
                        //         }
        
                        //     });
                        this.getRecordsCapacity();
        
                    },
                    err => {
                        this.displayProgressbar = false;
                        this.errorMessage = true;
                        this.msgs = [];
                        this.msgs.push({ severity: 'error', detail: 'Capacity could not be saved.' });
                        this.getRecordsCapacity();
                        console.log(err);
                    }
                );
                   
                },
              
            });



           // alert("apply to all values")
           
        }


        else{
        for (let element of this.capacityList) {
            element.CapacityDetailsList[0].Value = element.Month0;
            element.CapacityDetailsList[1].Value = element.Month1;
            element.CapacityDetailsList[2].Value = element.Month2;
            element.CapacityDetailsList[3].Value = element.Month3;
            element.CapacityDetailsList[4].Value = element.Month4;
            element.CapacityDetailsList[5].Value = element.Month5;
            element.CapacityDetailsList[6].Value = element.Month6;
            element.CapacityDetailsList[7].Value = element.Month7;
            element.CapacityDetailsList[8].Value = element.Month8;
            element.CapacityDetailsList[9].Value = element.Month9;
            element.CapacityDetailsList[10].Value = element.Month10;
            element.CapacityDetailsList[11].Value = element.Month11;
            element.CapacityDetailsList[12].Value = element.Month12;
            element.CapacityDetailsList[13].Value = element.Month13;
        }
        this.displayProgressbar = true;

        this.capacityAdminService.saveCapacityDetails(this.capacityList).subscribe(
            response => {
                this.displayProgressbar = false;
                this.msgs = [];
                this.msgs.push({ severity: 'success', detail: 'Capacity saved successfully.' });
                // this.capacityAdminService.getCapacity(this.isActiveRecord)
                //     .subscribe(capacity => {
                //         this.capacityList = capacity.CapacityList;
                //         this.capacityDetailList = this.capacityList[0].CapacityDetailsList;
                //         this.headers = capacity.headers;
                //         for (let item of this.capacityList) {
                //             item.Month0 = item.CapacityDetailsList[0] != null ? item.CapacityDetailsList[0].Value : null;
                //             item.Month1 = item.CapacityDetailsList[1] != null ? item.CapacityDetailsList[1].Value : null;
                //             item.Month2 = item.CapacityDetailsList[2] != null ? item.CapacityDetailsList[2].Value : null;
                //             item.Month3 = item.CapacityDetailsList[3] != null ? item.CapacityDetailsList[3].Value : null;
                //             item.Month4 = item.CapacityDetailsList[4] != null ? item.CapacityDetailsList[4].Value : null;
                //             item.Month5 = item.CapacityDetailsList[5] != null ? item.CapacityDetailsList[5].Value : null;
                //             item.Month6 = item.CapacityDetailsList[6] != null ? item.CapacityDetailsList[6].Value : null;
                //             item.Month7 = item.CapacityDetailsList[7] != null ? item.CapacityDetailsList[7].Value : null;
                //             item.Month8 = item.CapacityDetailsList[8] != null ? item.CapacityDetailsList[8].Value : null;
                //             item.Month9 = item.CapacityDetailsList[9] != null ? item.CapacityDetailsList[9].Value : null;
                //             item.Month10 = item.CapacityDetailsList[10] != null ? item.CapacityDetailsList[10].Value : null;
                //             item.Month11 = item.CapacityDetailsList[11] != null ? item.CapacityDetailsList[11].Value : null;
                //             item.Month12 = item.CapacityDetailsList[12] != null ? item.CapacityDetailsList[12].Value : null;
                //             item.Month13 = item.CapacityDetailsList[13] != null ? item.CapacityDetailsList[13].Value : null;
                //         }

                //     });
                this.getRecordsCapacity();

            },
            err => {
                this.displayProgressbar = false;
                this.errorMessage = true;
                this.msgs = [];
                this.msgs.push({ severity: 'error', detail: 'Capacity could not be saved.' });
                this.getRecordsCapacity();
                console.log(err);
            }
        );


    }
}
    checkbox(deleterow) {
        deleterow.isSelected = !deleterow.isSelected;
        deleterow.Id;
      
    }

    deactivateRecord() {
        console.log(this.capacityList);
        this.addList1 = this.capacityList.filter(x => x.isSelected != undefined && x.isSelected)
        var count = this.addList1.length;
        //deleterow.isEnable=false;
        if( count == 1)
        {
        
       var deactivatedRecords = this.capacityList.filter(x => x.isSelected != undefined && x.isSelected);
       deactivatedRecords.forEach(x => {
        x.IsActive = false;
    });
        
console.log(deactivatedRecords);
        this.capacityAdminService.saveUserCapacityList(deactivatedRecords).subscribe(
            response => {
                this.msgs = [];
                this.msgs.push({ severity: 'success', detail: 'Capacity deactivated successfully.' });
                this.capacityAdminService.getCapacity(this.isActiveRecord)
                    .subscribe(capacity => {
                        this.capacityList = capacity.CapacityList;
                        this.capacityDetailList = this.capacityList[0].CapacityDetailsList;
                        this.headers = capacity.headers;
                        for (let item of this.capacityList) {
                            item.Month0 = item.CapacityDetailsList[0] != null ? item.CapacityDetailsList[0].Value : null;
                            item.Month1 = item.CapacityDetailsList[1] != null ? item.CapacityDetailsList[1].Value : null;
                            item.Month2 = item.CapacityDetailsList[2] != null ? item.CapacityDetailsList[2].Value : null;
                            item.Month3 = item.CapacityDetailsList[3] != null ? item.CapacityDetailsList[3].Value : null;
                            item.Month4 = item.CapacityDetailsList[4] != null ? item.CapacityDetailsList[4].Value : null;
                            item.Month5 = item.CapacityDetailsList[5] != null ? item.CapacityDetailsList[5].Value : null;
                            item.Month6 = item.CapacityDetailsList[6] != null ? item.CapacityDetailsList[6].Value : null;
                            item.Month7 = item.CapacityDetailsList[7] != null ? item.CapacityDetailsList[7].Value : null;
                            item.Month8 = item.CapacityDetailsList[8] != null ? item.CapacityDetailsList[8].Value : null;
                            item.Month9 = item.CapacityDetailsList[9] != null ? item.CapacityDetailsList[9].Value : null;
                            item.Month10 = item.CapacityDetailsList[10] != null ? item.CapacityDetailsList[10].Value : null;
                            item.Month11 = item.CapacityDetailsList[11] != null ? item.CapacityDetailsList[11].Value : null;
                            item.Month12 = item.CapacityDetailsList[12] != null ? item.CapacityDetailsList[12].Value : null;
                            item.Month13 = item.CapacityDetailsList[13] != null ? item.CapacityDetailsList[13].Value : null;
                        }

                    });
            },
            err => {
                this.errorMessage = true;
                this.msgs = [];
                this.msgs.push({ severity: 'error', detail: 'Capacity could not be deactivated.' });
                console.log(err);
            }
        );

        this.deleterowchecked = false;

        console.log(this.capacityList);

    }
    else if (count==0)
    {
        this.msgs = [];
     this.msgs.push({severity:'error', detail:'Please select any Capacity to deactivate.'});
    }
    else{
        this.msgs = [];
        this.msgs.push({severity:'error', detail:'Please select only one Capacity to deactivate.'});
    }
}

getRecordsCapacity()
{ 
    this.capacityAdminService.getCapacity(this.isActiveRecord)
    .subscribe(capacity => {
        this.capacityList = capacity.CapacityList;
       
        this.capacityDetailList = this.capacityList[0].CapacityDetailsList;
        this.headers = capacity.headers;
        for (let item of this.capacityList) {
            item.Month0 = item.CapacityDetailsList[0] != null ? item.CapacityDetailsList[0].Value : null;
            item.Month1 = item.CapacityDetailsList[1] != null ? item.CapacityDetailsList[1].Value : null;
            item.Month2 = item.CapacityDetailsList[2] != null ? item.CapacityDetailsList[2].Value : null;
            item.Month3 = item.CapacityDetailsList[3] != null ? item.CapacityDetailsList[3].Value : null;
            item.Month4 = item.CapacityDetailsList[4] != null ? item.CapacityDetailsList[4].Value : null;
            item.Month5 = item.CapacityDetailsList[5] != null ? item.CapacityDetailsList[5].Value : null;
            item.Month6 = item.CapacityDetailsList[6] != null ? item.CapacityDetailsList[6].Value : null;
            item.Month7 = item.CapacityDetailsList[7] != null ? item.CapacityDetailsList[7].Value : null;
            item.Month8 = item.CapacityDetailsList[8] != null ? item.CapacityDetailsList[8].Value : null;
            item.Month9 = item.CapacityDetailsList[9] != null ? item.CapacityDetailsList[9].Value : null;
            item.Month10 = item.CapacityDetailsList[10] != null ? item.CapacityDetailsList[10].Value : null;
            item.Month11 = item.CapacityDetailsList[11] != null ? item.CapacityDetailsList[11].Value : null;
            item.Month12 = item.CapacityDetailsList[12] != null ? item.CapacityDetailsList[12].Value : null;
            item.Month13 = item.CapacityDetailsList[13] != null ? item.CapacityDetailsList[13].Value : null;
        }
    

    });
}

    activateRecord()
        {
            this.addList1 = this.capacityList.filter(x => x.isSelected != undefined && x.isSelected)
            var count = this.addList1.length;
            //deleterow.isEnable=false;
            if( count == 1)
            {
            var activatedList = this.capacityList.filter(x => x.isSelected != undefined && x.isSelected);
            activatedList.forEach(x => {
                x.IsActive = true;
            });
            this.capacityAdminService.saveUserCapacityList(activatedList).subscribe(
                response => {
                    this.msgs = [];
                    this.msgs.push({ severity: 'success', detail: 'Capacity activated successfully.' });
                    this.capacityAdminService.getCapacity(this.isActiveRecord)
                        .subscribe(capacity => {
                            this.capacityList = capacity.CapacityList;
                            this.capacityDetailList = this.capacityList[0].CapacityDetailsList;
                            this.headers = capacity.headers;
                            for (let item of this.capacityList) {
                                item.Month0 = item.CapacityDetailsList[0] != null ? item.CapacityDetailsList[0].Value : null;
                                item.Month1 = item.CapacityDetailsList[1] != null ? item.CapacityDetailsList[1].Value : null;
                                item.Month2 = item.CapacityDetailsList[2] != null ? item.CapacityDetailsList[2].Value : null;
                                item.Month3 = item.CapacityDetailsList[3] != null ? item.CapacityDetailsList[3].Value : null;
                                item.Month4 = item.CapacityDetailsList[4] != null ? item.CapacityDetailsList[4].Value : null;
                                item.Month5 = item.CapacityDetailsList[5] != null ? item.CapacityDetailsList[5].Value : null;
                                item.Month6 = item.CapacityDetailsList[6] != null ? item.CapacityDetailsList[6].Value : null;
                                item.Month7 = item.CapacityDetailsList[7] != null ? item.CapacityDetailsList[7].Value : null;
                                item.Month8 = item.CapacityDetailsList[8] != null ? item.CapacityDetailsList[8].Value : null;
                                item.Month9 = item.CapacityDetailsList[9] != null ? item.CapacityDetailsList[9].Value : null;
                                item.Month10 = item.CapacityDetailsList[10] != null ? item.CapacityDetailsList[10].Value : null;
                                item.Month11 = item.CapacityDetailsList[11] != null ? item.CapacityDetailsList[11].Value : null;
                                item.Month12 = item.CapacityDetailsList[12] != null ? item.CapacityDetailsList[12].Value : null;
                                item.Month13 = item.CapacityDetailsList[13] != null ? item.CapacityDetailsList[13].Value : null;
                            }
    
                        });
                },
                err => {
                    this.errorMessage = true;
                    this.msgs = [];
                    this.msgs.push({ severity: 'error', detail: 'Capacity could not be activated.' });
                    console.log(err);
                }
            );
    
           
        }
        else if (count==0)
        {
            this.msgs = [];
         this.msgs.push({severity:'error', detail:'Please select any Capacity to activate.'});
        }
        else{
            this.msgs = [];
            this.msgs.push({severity:'error', detail:'Please select only one Capacity to activate.'});
        }
    }
    
        onChangeValue()
        {
          //  this.isActiveRecord=value;
          this.isActiveRecord = this.selectedstate.code;
            this.capacityAdminService.getCapacity(this.isActiveRecord)
            .subscribe(capacity => {
                this.capacityList = capacity.CapacityList;
                this.capacityDetailList = this.capacityList[0].CapacityDetailsList;
                this.headers = capacity.headers;
                for (let item of this.capacityList) {
                    item.Month0 = item.CapacityDetailsList[0] != null ? item.CapacityDetailsList[0].Value : null;
                    item.Month1 = item.CapacityDetailsList[1] != null ? item.CapacityDetailsList[1].Value : null;
                    item.Month2 = item.CapacityDetailsList[2] != null ? item.CapacityDetailsList[2].Value : null;
                    item.Month3 = item.CapacityDetailsList[3] != null ? item.CapacityDetailsList[3].Value : null;
                    item.Month4 = item.CapacityDetailsList[4] != null ? item.CapacityDetailsList[4].Value : null;
                    item.Month5 = item.CapacityDetailsList[5] != null ? item.CapacityDetailsList[5].Value : null;
                    item.Month6 = item.CapacityDetailsList[6] != null ? item.CapacityDetailsList[6].Value : null;
                    item.Month7 = item.CapacityDetailsList[7] != null ? item.CapacityDetailsList[7].Value : null;
                    item.Month8 = item.CapacityDetailsList[8] != null ? item.CapacityDetailsList[8].Value : null;
                    item.Month9 = item.CapacityDetailsList[9] != null ? item.CapacityDetailsList[9].Value : null;
                    item.Month10 = item.CapacityDetailsList[10] != null ? item.CapacityDetailsList[10].Value : null;
                    item.Month11 = item.CapacityDetailsList[11] != null ? item.CapacityDetailsList[11].Value : null;
                    item.Month12 = item.CapacityDetailsList[12] != null ? item.CapacityDetailsList[12].Value : null;
                    item.Month13 = item.CapacityDetailsList[13] != null ? item.CapacityDetailsList[13].Value : null;
                }

            });

   
        }
        
    // oneditpage(event)
    // {
    //     if(event.data.isEnable)event.column.editable ="isEnable";
    //     else event.column.editable ="";
    // }

    exportRecord() {
        var link = document.createElement('a');
        this.capacityAdminService.getExport()
            .subscribe(blob => {
                link.href = window.URL.createObjectURL(blob);
                //var fileBlob = new Blob([returnedJSON.data], {type: 'application/pdf'});
                if (navigator.appVersion.toString().indexOf('.NET') > 0) { // for IE browser
                    // window.navigator.msSaveBlob(blob, "CMR_Export_OverviewPage.xlsx");
                    window.navigator.msSaveOrOpenBlob(blob, "CMR_Export_CapacityAdminPage.xlsx");
                } else { // for other browsers
                    link.href = window.URL.createObjectURL(blob);
                    this.timestamp = new Date(Date.now())
                    link.download = "CMR_Export_CapacityAdminPage " + this.timestamp.toString() + ".xlsx";
                    link.click();
                }
            })
    }
    OnOKClick() {
        this.capacityList[0].Pensum = 1;
        this.capacityList.forEach(x => {
                x.Month0 = this.capacityList[0].Month0 != null ? this.capacityList[0].Month0 * x.Pensum : x.Month0,
                x.Month1 = this.capacityList[0].Month1 != null ? this.capacityList[0].Month1 * x.Pensum : x.Month1,
                x.Month2 = this.capacityList[0].Month2 != null ? this.capacityList[0].Month2 * x.Pensum : x.Month2,
                x.Month3 = this.capacityList[0].Month3 != null ? this.capacityList[0].Month3 * x.Pensum : x.Month3,
                x.Month4 = this.capacityList[0].Month4 != null ? this.capacityList[0].Month4 * x.Pensum : x.Month4,
                x.Month5 = this.capacityList[0].Month5 != null ? this.capacityList[0].Month5 * x.Pensum : x.Month5,
                x.Month6 = this.capacityList[0].Month6 != null ? this.capacityList[0].Month6 * x.Pensum : x.Month6,
                x.Month7 = this.capacityList[0].Month7 != null ? this.capacityList[0].Month7 * x.Pensum : x.Month7,
                x.Month8 = this.capacityList[0].Month8 != null ? this.capacityList[0].Month8 * x.Pensum : x.Month8,
                x.Month9 = this.capacityList[0].Month9 != null ? this.capacityList[0].Month9 * x.Pensum : x.Month9,
                x.Month10 = this.capacityList[0].Month10 != null ? this.capacityList[0].Month10 * x.Pensum : x.Month10,
                x.Month11 = this.capacityList[0].Month11 != null ? this.capacityList[0].Month11 * x.Pensum : x.Month11,
                x.Month12 = this.capacityList[0].Month12 != null ? this.capacityList[0].Month12 * x.Pensum : x.Month12,
                x.Month13 = this.capacityList[0].Month13 != null ? this.capacityList[0].Month13 * x.Pensum : x.Month13
        }
        );
        //console.log(this.capacityList);
        this.capacityList[0].Pensum = null;
    }

}