import {Http,Response} from '@angular/http';
import {Injectable} from '@angular/core';
import { Orgnaization, OuMapping } from './ou-mapping.modal'
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../../environments/environment';

@Injectable()
export class OuMappingService 
{
    //hostURL : string = "http://nzur467991dww.ubsprod.msad.ubs.net/CMRAPI/api/";
    //hostURL :string ="http://localhost:58349/api/";
    hostURL :string =environment.baseUrl;

    constructor(private http: Http) {}
    
    GetOrganizations() : Observable<Orgnaization[]> {        
        return this.http.get(this.hostURL + 'Organization/GetOrganizations/')
        .map((res:Response)=> res.json() as Orgnaization[])
        .catch(this.handleError)
    }

    GetOuMappings() : Observable<OuMapping[]> {        
        return this.http.get(this.hostURL + 'Organization/GetOuMappings/')
        .map((res:Response)=> res.json() as OuMapping[])
        .catch(this.handleError)
    }

    SearchOuMapping(org:number,ou:string) : Observable<OuMapping[]> {
        return this.http.get(this.hostURL + 'Organization/SearchOuMapping/'+org+'/'+ou)
        .map((res:Response)=> res.json() as OuMapping[])
        .catch(this.handleError)
    } 
    
    AddOuMapping(ouMapping:OuMapping) {           
        return this.http.post(this.hostURL + 'Organization/AddOuMapping', ouMapping)
        .map(res => res.json() as OuMapping[])
        .catch(this.handleError);     	    
    }

    IsOuExists(ou:string) {           
        return this.http.get(this.hostURL + 'Organization/IsOuExists/'+ou)
        .map(res =>  res.json())
        .catch(this.handleError);    	    
    }

    DeleteOuMapping(ouMapId:number) {           
        return this.http.get(this.hostURL + 'Organization/DeleteOuMapping/'+ouMapId)
        .map((res:Response)=> res.json() as OuMapping[])
        .catch(this.handleError)    	    
    }

    private handleError(error: Response) {
        return Observable.throw(error.statusText);
    }
 }