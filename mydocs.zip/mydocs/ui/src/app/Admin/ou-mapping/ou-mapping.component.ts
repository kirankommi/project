import { Component, OnInit} from '@angular/core';
import { Orgnaization, OuMapping } from './ou-mapping.modal';
import { OuMappingService } from './ou-mapping.service';
import { Message } from 'primeng/primeng';

@Component({
    selector : 'ou-mapping',
    templateUrl : './ou-mapping.component.html'
})
export class OuMappingComponent 
{ 
    organizationList : Orgnaization[];
    ouMappingList: OuMapping[];
    ouMap: OuMapping = new OuMapping();
    organizationId : number = 0;
    SelectedOuMapId : number = 0;
    ouCode : string = null;
    msgs: Message[] = [];
    validOu : string;

    constructor(private ouMappingService:OuMappingService) {}

    ngOnInit() 
    { 
        this.ouMappingService.GetOrganizations()
            .subscribe(organization => {  
                this.organizationList = organization;
        });

        this.ouMappingService.GetOuMappings()
            .subscribe(Oumapping => {  
                this.ouMappingList = Oumapping;
        });
    }

    SearchOuMapping()
    {
        this.ouCode = this.ouCode == '' ? null : this.ouCode
        this.ouMappingService.SearchOuMapping(this.organizationId,this.ouCode)
        .subscribe(Oumapping => {  
            this.ouMappingList = Oumapping;
                });        
    }    

    AddOuMapping()
    {
        if(this.organizationId !== null && this.organizationId !== 0 && this.ouCode !== null && this.ouCode !== '') 
        {
            this.ouMap.Id = 0;
            this.ouMap.Organization_Id = this.organizationId;
            this.ouMap.OU_CODE = this.ouCode;
            this.ouMap.CREATED_BY = sessionStorage.getItem('GPN');
            this.ouMap.CREATED_DATE = new Date();
            this.ouMap.LAST_UPDATED_BY = sessionStorage.getItem('GPN');
            this.ouMap.LAST_UPDATED_DATE = new Date().toString();

            this.ouMappingService.IsOuExists(this.ouCode)
            .subscribe(ou => { this.validOu = ou;
                if(this.validOu === 'OU is already mapped to organization')
                {   
                    this.msgs = [];
                    this.msgs.push({severity:'error',detail:'OU is already mapped to organization'});
                }
                else if(this.validOu === 'Please enter valid OU')
                {   
                    this.msgs = [];
                    this.msgs.push({severity:'error',detail:'Please enter valid OU'});
                }
                else if(this.validOu === 'Valid OU')
                {
                    this.ouMappingService.AddOuMapping(this.ouMap)
                    .subscribe(Oumapping => { this.ouMappingList = Oumapping 
                        this.msgs = [];                  
                        this.msgs.push({severity:'success',detail:'OU-Mapping updated successfully'});
                    });
                }
            });
        }
        else
        {
            this.msgs = [];                  
            this.msgs.push({severity:'error',detail:'Please select organization and OU'});
        }
    }

    DeleteOuMapping()
    {
        if(this.SelectedOuMapId !== 0)
        {
            this.ouMappingService.DeleteOuMapping(this.SelectedOuMapId)
            .subscribe(Oumapping => { this.ouMappingList = Oumapping   
                this.msgs = [];                
                this.msgs.push({severity:'success',detail:'OU-Mapping deleted successfully'});
            });
            this.SelectedOuMapId = 0;
        }
        else
        {
            this.msgs = [];                  
            this.msgs.push({severity:'error',detail:'Please select organization'})
        }
    }

    GetSelectedOuMapDetails(Id)
    {
        this.SelectedOuMapId = Id;
    }
}