import { Component, OnInit} from '@angular/core';
import { OrganizationService } from './organization.service';
import { Orgnaization } from './organization.modal';
import {Validators,FormControl,FormGroup,FormBuilder} from '@angular/forms';
import {Message} from 'primeng/primeng';

@Component({
    selector : 'organization',
    templateUrl : './organization.component.html'
    })
    export class OrganizationComponent 
    { 
        orgform: FormGroup;
        organizationList : Orgnaization[];
        organization: Orgnaization = new Orgnaization();
        orgName : string;
        msgs: Message[] = [];
        orgExists : boolean;
        SelectedOrgId : number = 0;

        constructor(private fb: FormBuilder,
            private organizationService:OrganizationService) {}

        ngOnInit() 
        { 
            this.orgform = this.fb.group({
                'organization': new FormControl('', Validators.compose([Validators.required,Validators.maxLength(50)]))                  
              });

            this.organizationService.GetOrganizations()
                .subscribe(organization => {  
                    this.organizationList = organization;
            });
        }
        
        AddOrganization()
        {
            if(this.orgName === '' || this.orgName === undefined) 
            {
                //validate organization
                this.orgform.controls['organization'].markAsDirty();
            }
            else
            {
                this.organization.Id = 0;
                this.organization.Is_Active = true;
                this.organization.CREATED_BY = sessionStorage.getItem('GPN');
                this.organization.LAST_UPDATED_BY = sessionStorage.getItem('GPN');
                this.organization.Organization_Name = this.orgName;

                this.organizationService.IsOrgExists(this.organization)
                .subscribe(orgExists => { this.orgExists = orgExists;
                    if(this.orgExists)
                    {   
                        this.msgs = [];
                        this.msgs.push({severity:'error',detail:'Organization already exists'});
                        this.orgform.markAsPristine();
                        this.orgform.markAsUntouched();
                        this.orgform.updateValueAndValidity();
                    }
                    else 
                    {
                        this.organizationService.AddOrganization(this.organization)
                        .subscribe(organization => { this.organizationList = organization  
                            if(this.organizationList.length !== null || this.organizationList.length !== 0)
                            {   
                                this.msgs = [];
                                this.msgs.push({severity:'success',detail:'Organization saved successfully'});
                                this.orgform.markAsPristine();
                                this.orgform.markAsUntouched();
                                this.orgform.updateValueAndValidity();
                            }
                        });
                    }
                });                
            }
        }

        ActOrDeActOrganization(status)
        {
            if(this.SelectedOrgId !== 0)
            {
                this.organization.Is_Active = status;
                this.organization.LAST_UPDATED_BY = sessionStorage.getItem('GPN');

                this.organizationService.UpdateOrganization(this.organization)
                .subscribe(organization => { this.organizationList = organization
                    if(this.organizationList.length !== null || this.organizationList.length !== 0)
                    {   
                        this.msgs = [];
                        if(status === "true")
                            this.msgs.push({severity:'success',detail:'Organization Activated successfully'});
                        else if(status === "false")
                            this.msgs.push({severity:'success',detail:'Organization Deactivated successfully'});

                        this.orgform.markAsPristine();
                        this.orgform.markAsUntouched();
                        this.orgform.updateValueAndValidity();
                    } 
                });
                this.SelectedOrgId = 0;
            }
            else
            {
                this.msgs = [];
                this.msgs.push({severity:'error',detail:'Please select organization'});
            }
        }

        UpdateOrganization()
        {
            if(this.orgName === '' || this.orgName === undefined) 
            {
                //validate organization
                this.orgform.controls['organization'].markAsDirty();
            }
            else if(this.SelectedOrgId !== 0)
            {
                this.organization.Organization_Name = this.orgName;
                this.organization.LAST_UPDATED_BY = sessionStorage.getItem('GPN');

                this.organizationService.IsOrgExists(this.organization)
                .subscribe(orgExists => { this.orgExists = orgExists;
                    if(this.orgExists)
                    {   
                        this.msgs = [];
                        this.msgs.push({severity:'error',detail:'Organization already exists'});
                        this.orgform.markAsPristine();
                        this.orgform.markAsUntouched();
                        this.orgform.updateValueAndValidity();
                    }
                    else 
                    {
                        this.organizationService.UpdateOrganization(this.organization)
                        .subscribe(organization => { this.organizationList = organization
                            if(this.organizationList.length !== null || this.organizationList.length !== 0)
                            {   
                                this.msgs = [];
                                this.msgs.push({severity:'success',detail:'Organization updated successfully'});
                                this.orgform.markAsPristine();
                                this.orgform.markAsUntouched();
                                this.orgform.updateValueAndValidity();
                            } 
                        });
                        this.SelectedOrgId = 0;
                    }
                }); 
            }
            else
            {
                this.msgs = [];
                this.msgs.push({severity:'error',detail:'Please select organization'});
            }
        }

        GetSelectedOrgDetails(Id,Organization_Name)
        {
            this.SelectedOrgId = Id;
            this.organization.Id = Id;
            this.organization.Organization_Name = Organization_Name;
        }

        
        formatDate(date)
        {           
            date = date.slice(8,10) + '.' +  date.slice(5,7)  + '.' + date.slice(0,4) + ' ' + date.slice(11,13)+ ':' + date.slice(14,16)
            return date;
        }
    }