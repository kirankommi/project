import {Http,Response} from '@angular/http';
import {Injectable} from '@angular/core';
import { Orgnaization } from './organization.modal'
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../../environments/environment';

@Injectable()
export class OrganizationService 
{
    //hostURL : string = "http://nzur467991dww.ubsprod.msad.ubs.net/CMRAPI/api/";
   // hostURL :string ="http://localhost:58349/api/";
   hostURL :string =environment.baseUrl;
    constructor(private http: Http) {}
    
    GetOrganizations() : Observable<Orgnaization[]> {        
        return this.http.get(this.hostURL + 'Organization/GetOrganizations/')
        .map((res:Response)=> res.json() as Orgnaization[])
        .catch(this.handleError)
    }

    AddOrganization(organization:Orgnaization) {           
        return this.http.post(this.hostURL + 'Organization/AddOrganization', organization)
        .map(res =>  res.json() as Orgnaization[])
        .catch(this.handleError);     	    
    }

    UpdateOrganization(organization:Orgnaization) {           
        return this.http.post(this.hostURL + 'Organization/UpdateOrganization', organization)
        .map(res =>  res.json() as Orgnaization[])
        .catch(this.handleError);     	    
    }

    IsOrgExists(organization:Orgnaization) {           
        return this.http.post(this.hostURL + 'Organization/IsOrgExists', organization)
        .map(res =>  res.json())
        .catch(this.handleError);     	    
    }

    private handleError(error: Response) {
        return Observable.throw(error.statusText);
    }
 }