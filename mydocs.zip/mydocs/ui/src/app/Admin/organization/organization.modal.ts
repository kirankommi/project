export class Orgnaization {
    Id : number;
    Is_Active : boolean;
    CREATED_DATE : Date;
    CREATED_BY : string;
    LAST_UPDATED_DATE : Date;
    LAST_UPDATED_BY : string;
    Organization_Name : string;
}