import{Component} from '@angular/core'
@Component({
selector : 'pm-dashboard',
templateUrl : './dashboard.component.html'
})
export class DashboardComponent
{
}