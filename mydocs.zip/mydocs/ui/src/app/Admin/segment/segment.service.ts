import {HttpModule, Http,Response,RequestOptions} from '@angular/http';
import {Injectable} from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Observable';
import { SegmentList,SelSegmentList, segment } from './segment.modal'
import { Options } from 'selenium-webdriver';
import { environment } from '../../../environments/environment';
@Injectable()
export class SegmentService {
    hostURL :string =environment.baseUrl;
    [x: string]: any;

    constructor(private http: Http) {}
    
    getSegments() : Observable<segment> {        
        return this.http.get(this.hostURL + 'Segment/GetSegment' )
        .map((res:Response)=> res.json())
        .catch(this.handleError)
    }

    saveSegment(segmentlist:SegmentList) {  
        return this.http.post(this.hostURL + 'Segment/Add/' +segmentlist.SEGMENT_CODE +'/',Option)
        .map(res =>  res.json());  
           	    
     }
     activateSegment(SelSegmentList: SelSegmentList)
     {        
        return this.http.post(this.hostURL + 'Segment/Activate/',SelSegmentList)
        .map((res:Response)=> res.json())
        .catch(this.handleError)
     }
     deactivateSegment(SelSegmentList: SelSegmentList)
     {        
        return this.http.post(this.hostURL + 'Segment/DeActivate/',SelSegmentList)
        .map((res:Response)=> res.json())
        .catch(this.handleError)
     }
     SaveOrder(SelSegmentList: SelSegmentList)
     {        
        return this.http.post(this.hostURL + 'Segment/SegmentOrder/' ,SelSegmentList)
        .map((res:Response)=> res.json())
        .catch(this.handleError)
     }
     UpdateSegment(segment :SegmentList[])
     {
         console.log(segment);
        return this.http.post(this.hostURL + 'Segment/UpdateSegment/' ,segment)
        .map((res:Response)=> res.json())
        .catch(this.handleError)
     }
    private handleError(error: Response) {
        return Observable.throw(error.statusText);
    }
 }