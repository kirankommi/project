import { Component, OnInit, Input, Directive, ViewChild } from '@angular/core'
import { SegmentService } from './segment.service';
import { segment, SegmentList, SelSegmentList } from './segment.modal'
import { ConfirmationService, Message } from 'primeng/components/common/api';
import { forEach } from '@angular/router/src/utils/collection';
import { Validators, FormControl, FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'pm-segment',
  templateUrl: './segment.component.html',
  providers: [ConfirmationService]
})
export class SegmentComponent {
  languageId: number;
  segments: SegmentList[];
  displayManageOrder: boolean;
  SegmentList: SegmentList = new SegmentList();
  SelSegmentList: SelSegmentList = new SelSegmentList();
  newSegmentCode: string;
  SelSegments: Array<string> = [];
  msgs: Message[] = [];
  selectedsegments: SegmentList;
  userform: FormGroup;
  possibleStatus = [];
  nativeWindow: any
  constructor(private fb: FormBuilder, private segmentService: SegmentService, private confirmationService: ConfirmationService) {
    this.possibleStatus = [
      { label: 'Active', value: "Active" },
      { label: 'InActive', value: "InActive" },
    ];
  }

  ngOnInit() {

    this.segmentService.getSegments()
      .subscribe(segment => {
        this.segments = segment.SegmentList;
      });

  }

  save() {
    var flag = true;
    for (var i = 0; i < this.segments.length; i++) {
      if (this.segments[i].SegmentCode.toLowerCase() == this.SegmentList.SEGMENT_CODE.toLowerCase()) {
        flag = false;
      }
    }
    if (this.SegmentList.SEGMENT_CODE == undefined || this.SegmentList.SEGMENT_CODE == "") {
      this.msgs = [];
      this.msgs.push({ severity: 'error', detail: 'Please enter segment name.' });
    }
    else if (this.SegmentList.SEGMENT_CODE.length > 30) {
      this.msgs = [];
      this.msgs.push({ severity: 'error', detail: 'Segment name should not be more than 30 characters.' });
    }
    else if (!flag) {
      this.msgs = [];
      this.msgs.push({ severity: 'error', detail: 'Segment already exists. Please try with a different Segment name.' });
    }
    else {
      this.segmentService.saveSegment(this.SegmentList).subscribe(
        seg => {
          this.segmentService.getSegments()
            .subscribe(segment => {

              this.segments = segment.SegmentList;
              this.SegmentList.SEGMENT_CODE = null;
              this.msgs = [];
              this.msgs.push({ severity: 'success', detail: 'Segment added succesfully.' });

            });
        });
    }
  }

  SaveOrder() {
    this.SelSegmentList.SEGMENT_CODE = [];
    for (var i = 0; i < this.segments.length; i++) {
      this.SelSegmentList.SEGMENT_CODE.push(this.segments[i].SegmentCode);
    }
    this.segmentService.SaveOrder(this.SelSegmentList)
      .subscribe(response => {
        this.SelSegments = [];
        this.segmentService.getSegments()
          .subscribe(segment => {

            this.segments = segment.SegmentList;
            this.displayManageOrder = false;
          });
        this.msgs = [];
        this.msgs.push({ severity: 'success', detail: 'Segments Ordered succesfully' });

      })
  }
  ConvertToInt(val) {
    return parseInt(val);
  }

  UpdateSegment() {
    var distribution: number = 0;
    for (var i = 0; i < this.segments.length; i++) {
      if (this.segments[i].IsActive == "Active") {
        distribution = this.ConvertToInt(distribution) + this.ConvertToInt(this.segments[i].Distribution);
      }
    }
    if (this.ConvertToInt(distribution) == 100) {
      this.segmentService.UpdateSegment(this.segments)
        .subscribe(response => {
          this.SelSegments = [];
          this.segmentService.getSegments()
            .subscribe(segment => {
              this.segments = segment.SegmentList;
            });
          this.msgs = [];
          this.msgs.push({ severity: 'success', detail: 'Segments updated succesfully' });
        })
    }
    else {
      this.msgs = [];
      this.msgs.push({ severity: 'error', detail: 'The Distribution is ' + distribution + '. Distribution percentage of active Segments should be equal to 100.' });
    }
  }
}