import { TimeUnit } from "ngx-bootstrap/chronos/types";

export class segment
{
 SegmentList : SegmentList[];
}

export class SegmentList
{
    Id:number;
    SEGMENT_CODE:string;
    DESCRIPTION:string;
    checked:boolean = false;
    IsActive:string;
    SegmentCode:string;
    Distribution: number;
}
export class SelSegmentList
{
    SEGMENT_CODE:string[];
}