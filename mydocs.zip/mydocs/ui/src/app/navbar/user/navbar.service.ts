import { Injectable } from "@angular/core";
import { Http, Response, RequestOptions } from '@angular/http';
import { Observable } from "rxjs/Observable";
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/toPromise';
import { user, navbar, testUserList } from "./user";
import { environment } from "../../../environments/environment";

@Injectable()
export class NavbarService {
    baseUrl = environment.baseUrl;
    [x: string]: any;
    constructor(private http: Http) {}
    getUser() : Observable<user>{
        let headers = new Headers(
            {'Content-Type': 'application/json'}
        );
        let options = new RequestOptions(
            {headers: this.headers}
        );
        return this.http.get(this.baseUrl +'home/Get/', options)
        .map((res:Response)=> res.json() )
        .catch(this.handleError)
    }
    UserDetails(gpn: string) {
        return this.http.get(this.baseUrl +'Home/testUser/'+ gpn)
            .map((res: Response) => res.json())
            .catch(this.handleError)
    }
}