﻿// core/navbar.component.ts
import { Component } from '@angular/core'
import { Session } from 'selenium-webdriver';
import { NavbarService } from './navbar.service';
import { user,navbar,testUserList, List } from './user';
import { Routes, RouterModule, Router, RouterLinkActive  } from '@angular/router';
import { ConfirmationService, Message,MenuItem } from 'primeng/components/common/api';
import { environment } from '../../../environments/environment'
import { CidconfirmService } from '../../cidconfirm/cidconfirm.service'
import { UserList } from '../../cidconfirm/cidconfirm.modal'
@Component({
    selector: 'ct-navbar',
    templateUrl: './navbar.component.html',
    providers: [ConfirmationService]
})
export class NavbarComponent { 
    user: user = new user();
    role: string;
    LanguageId : string;
    msgs: Message[] = [];
    var1 :string;
    var2 : string;
    var3 : string;
    navbar : navbar;
    displayUser: boolean;
    testUserList: testUserList = new testUserList();
    List:List[];
    items: MenuItem[];
    Adminparam : boolean= false;
    AdminSpecialistparam  : boolean= false;
    displaytesticon: boolean;
    selList: List[]
    additionalOuDesc : string[];
    userList: UserList;
    constructor(private navbarService: NavbarService, private router: Router, private confirmationService: ConfirmationService,private CidconfirmService: CidconfirmService ){
        // if(sessionStorage.getItem('Adminparam')=="true")
        // {
        //     this.Adminparam = true;
        // }
        this.displaytesticon = environment.testicon;
    }

   
    ngOnInit() {
        if(sessionStorage.getItem('Adminparam')=="T")
        {
            this.Adminparam=true;
        }
        else if(sessionStorage.getItem('Adminparam')=="F")
        { this.Adminparam= false;}
        
        // this.navbarService.getUser()
        // .subscribe(user => {
        //         this.user = this.user;                  
        //     });
        //     this.user.Role = "Admin";
        // this.displaytesticon = environment.testicon;
        // this.user.UserName = "Sabrina Kaiser";
        // this.user.Location = "CH";
        // this.user.Role = "Admin";
        // this.user.GPN = "43275130";
        // this.user.ouCode = "LYN6";
        // this.user.ouDesc = "SOLUTIONS";
         this.LanguageId= "2";
        // this.user.oudataspace="OZF1", "LYN6", "HXCG","HQSP";
        // sessionStorage.setItem('UserName',this.user.UserName);
        // sessionStorage.setItem('Role',this.user.Role);
        // sessionStorage.setItem('Location',this.user.Location);
        // sessionStorage.setItem('GPN',this.user.GPN);
        // sessionStorage.setItem('ouCode',this.user.ouCode);
        // sessionStorage.setItem('ouDesc',this.user.ouDesc);
        // sessionStorage.setItem('oudataspace',this.user.oudataspace);

        if(sessionStorage.getItem('LanguageId') === null || sessionStorage.getItem('LanguageId') === undefined){
            sessionStorage.setItem('LanguageId', this.LanguageId)
        }
        
        this.var1=sessionStorage.getItem('UserName');
        this.var2=sessionStorage.getItem('Location');
        this.var3=sessionStorage.getItem('GPN');
        if(sessionStorage.getItem('Role')=="ADMIN")
        {
            this.Adminparam=true;
        }
        else
        {
            this.Adminparam=false;   
        }
        if(sessionStorage.getItem('Role')=="ADMIN" || sessionStorage.getItem('Role')=="SPECIALIST")
        {
            this.AdminSpecialistparam=true;
        }
        else
        {
            this.AdminSpecialistparam=false;
        }
}

isActive(language) { 
   var lng = sessionStorage.getItem('LanguageId');
    return language === lng;
};
selectLanguage(lan :string)
{
    
    this.confirmationService.confirm({
        message: 'Are you sure that you want to change the language?',
        header: 'Confirmation',
        icon: 'fa fa-question-circle',
        accept: () => {
            sessionStorage.setItem('LanguageId', lan)
           location.replace('/');
        },
        
    });
  
    //sessionStorage.setItem('LanguageId', lan)
}
UserDetails() {
    this.displayUser=true;
    this.testUserList.gpn=sessionStorage.getItem('GPN');
    this.navbarService.UserDetails(this.testUserList.gpn)
        .subscribe(navbar => { this.List = navbar 
        this.selList = this.List.filter(o => o.description == 'BASE' ||o.description == 'ADMIN' ||o.description == 'SPECIALIST')
        });
    }   

    userData(row){
        this.displayUser = false;
        this.var1 =row.firstName +" "+row.lastName;
        sessionStorage.setItem('UserName',row.firstName +" "+row.lastName);
        sessionStorage.setItem('Role',row.description);
        sessionStorage.setItem('ImpersonateGPN',row.gpn); 
        sessionStorage.setItem('GPN',row.gpn);
        
        
        this.additionalOuDesc= this.List.filter(item => item.gpn == row.gpn).map(({ description }) => description);  
        if(sessionStorage.getItem('Role')=="ADMIN")
            {
                this.Adminparam=true;
            }
            else
            {
                this.Adminparam=false;   
            }
            this.router.navigate(['/']);
    }
    
AdminScreen(){
    this.router.navigateByUrl("/dashboard"); 
    //this.router.navigate(['organization/']); 
    
}
ClearImpersonation(){
    this.CidconfirmService.getUserDetails()
    .subscribe(userList => {
      this.userList = userList;
      var Role= this.userList.Role.filter(item => item == 'BASE' || item == 'ADMIN' || item == 'SPECIALIST' );
      //var additionalOuDesc =this.userList.Role.filter(item => item != 'BASE' && item != 'ADMIN' && item != 'SPECIALIST' );
      sessionStorage.setItem('UserName',userList.FirstName +" "+userList.LastName);
      sessionStorage.setItem('Role',Role[0]);
      sessionStorage.setItem('Location',this.userList.LanguageId);
      sessionStorage.setItem('GPN',this.userList.GPN);
      sessionStorage.setItem('ouCode',this.userList.OUCode);
      sessionStorage.setItem('ImpersonateGPN',''); 
       this.router.navigate(['/']);    
    });  
}


}