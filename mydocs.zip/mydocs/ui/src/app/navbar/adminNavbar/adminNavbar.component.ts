﻿// core/navbar.component.ts
import { Component } from '@angular/core'
import { Session } from 'selenium-webdriver';
import { AdminNavbarService } from './adminNavbar.service';
import { user,navbar,testUserList, List } from './adminNavbar';
import { Routes, RouterModule, Router, RouterLinkActive  } from '@angular/router';
import { ConfirmationService, Message,MenuItem } from 'primeng/components/common/api';

@Component({
    selector: 'ct-adminNavbar',
    templateUrl: './adminNavbar.component.html',
    styleUrls: ['./adminNavbar.component.css'],
    providers: [ConfirmationService]
})
export class AdminNavbarComponent { 
    user: user = new user();
    role: string;
    LanguageId : string;
    msgs: Message[] = [];
    var1 :string;
    var2 : string;
    var3 : string;
    navbar : navbar;
    displayUser: boolean;
    testUserList: testUserList = new testUserList();
    List:List[];
    items: MenuItem[];
    Adminparam : boolean= false;
    selList:List[];
    selOuDesc : string[];
    constructor(private navbarService: AdminNavbarService, private router: Router, private confirmationService: ConfirmationService){

    }

   
    ngOnInit() {
        // this.user.UserName = "Sabrina Kaiser";
        // this.user.Location = "CH";
        // this.user.Role = "Admin";
        // this.user.GPN = "43275130";
        // this.user.ouCode = "LYN6";
        // this.user.ouDesc = "SOLUTIONS";
        // this.LanguageId= "2";
        // sessionStorage.setItem('UserName',this.user.UserName);
        // sessionStorage.setItem('Role',this.user.Role);
        // sessionStorage.setItem('Location',this.user.Location);
        // sessionStorage.setItem('GPN',this.user.GPN);
        // sessionStorage.setItem('ouCode',this.user.ouCode);
        // sessionStorage.setItem('ouDesc',this.user.ouDesc);

        if(sessionStorage.getItem('LanguageId') === null || sessionStorage.getItem('LanguageId') === undefined){
            sessionStorage.setItem('LanguageId', this.LanguageId)
        }
        
        this.var1=sessionStorage.getItem('UserName');
        this.var2=sessionStorage.getItem('Location');
        this.var3=sessionStorage.getItem('GPN');
        if(sessionStorage.getItem('Role')=="AKV-ADMIN")
        {
            this.Adminparam=true;
        }
        else
        {
            this.Adminparam=false;   
        }

}

isActive(language) { 
   var lng = sessionStorage.getItem('LanguageId');
    return language === lng;
};
selectLanguage(lan :string)
{
    
    this.confirmationService.confirm({
        message: 'Are you sure that you want to change the language?',
        header: 'Confirmation',
        icon: 'fa fa-question-circle',
        accept: () => {
            sessionStorage.setItem('LanguageId', lan)
            //this.router.navigate(['capture']);
            //if(location.pathname == '/capture')            
            location.replace('/');
                // this.msgs = [];
                // this.msgs.push({severity:'success', summary:'Success Message', detail:'Language changed succesfully'});
        },
        // reject: () => {
        //     this.msgs = [];
        //     this.msgs.push({severity:'error', summary:'Error Message', detail:'You have rejected'});
        // }
    });
  
    //sessionStorage.setItem('LanguageId', lan)
}
UserDetails() {
    this.displayUser=true;
    this.testUserList.gpn=sessionStorage.getItem('GPN');
    this.navbarService.UserDetails(this.testUserList.gpn)
        .subscribe(navbar => { this.List = navbar 
        this.selList = this.List.filter(o => o.description == 'AKV-BASE' ||o.description == 'AKV-ADMIN' ||o.description == 'AKV-SPECIALIST')
        });
    }   

userData(row){
    this.displayUser = false;
    this.var1 =row.firstName +" "+row.lastName;
    sessionStorage.setItem('UserName',row.firstName +" "+row.lastName);
    sessionStorage.setItem('Role',row.description);
    sessionStorage.setItem('ImpersonateGPN',row.gpn);  
    this.selOuDesc = this.List.filter(o => o.gpn =row.gpn).map(({description}) => description);
    if(sessionStorage.getItem('Role')=="AKV-ADMIN")
        {
            this.Adminparam=true;
        }
        else
        {
            this.Adminparam=false;   
        }
}
AdminScreen(){
    // if(this.Adminparam==true)
    // {
    //     this.Adminparam=false;
    //     sessionStorage.setItem('Adminparam','F');
    //     this.router.navigateByUrl('/');
    // }
    // else if(this.Adminparam==false)
    // {
    // this.Adminparam= true;
    // sessionStorage.setItem('Adminparam','T');
    // this.router.navigateByUrl('/segment');
    // }
    
     
    
    //window.open("/", "", "width=600,height=400"); 
    var win = window.open('/segment', '_blank');
}

}