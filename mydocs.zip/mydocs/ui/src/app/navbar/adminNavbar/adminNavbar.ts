import { TimeUnit } from "ngx-bootstrap/chronos/types";

export class navbar {
  testUserList:testUserList[]; 
  
}
export class user {

    UserName : string;
    Location :string;
    GPN :string;
    Role : string;
    //Language :string;
    Email :string;
    ouCode :string;
    ouDesc :string;
  }
  export class List {

    gpn : string;
    firstName : string;
    lastName : string;
    description : string;
  }

  export class testUserList{
    gpn : string;
  }