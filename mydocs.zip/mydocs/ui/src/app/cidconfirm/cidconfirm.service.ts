import {Http,Response} from '@angular/http';
import {Injectable} from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../environments/environment';

@Injectable()
export class CidconfirmService 
{
    hostURL :string = environment.baseUrl;

    constructor(private http: Http) {}
    
    IsCidValid(GPN:string) {           
        return this.http.get(this.hostURL + 'CidConfirm/IsCidValid/'+GPN)
        .map(res =>  res.json())
        .catch(this.handleError);    	    
    }

    SetCIDDate(GPN:string,TId:string,FirstName:string,LastName:string) {           
        return this.http.get(this.hostURL + 'CidConfirm/SetCIDDate/'+GPN)
        .map(res =>  res.json())
        .catch(this.handleError);    	    
    }
    getUserDetails() {           
        return this.http.get(this.hostURL +'Home/get/')
                    .map((res ) => res.json())
                    .catch(this.handleError)
        }

    private handleError(error: Response) {
        return Observable.throw(error.statusText);
    }
}