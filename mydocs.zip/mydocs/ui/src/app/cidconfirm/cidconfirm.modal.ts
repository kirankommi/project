export class user {

    UserName : string;
    Location :string;
    GPN :string;
    Role : string;
    //Language :string;
    Email :string;
    ouCode :string;
    ouDesc :string;
}
export class UserList
{
    GPN: string;
    TId: string;
    FirstName: string;
    LastName: string;
    Role: string[];
    Location: string;
    LanguageId: string;
    Description: string;
    additionalOU: string;
    OUCode: string;
    OUDescription: string;
    Roles:string[];
}