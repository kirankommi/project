import { Component, OnInit} from '@angular/core';
import { Router } from '@angular/router';
import { CidconfirmService } from './cidconfirm.service';
import { user,UserList } from './cidconfirm.modal';
import {Message} from 'primeng/primeng';
import { ConfirmationService, MenuItem } from 'primeng/components/common/api';

@Component({
selector : 'cidconfirm',
templateUrl : './cidconfirm.component.html',
providers: [ConfirmationService]
})
export class CidConfirmComponent 
{
    GPN : string;
    validCid : boolean = false;
    msgs: Message[] = [];
    user: user = new user();
    userList: UserList;
    pageDisplay: boolean = false;
    cidConfirmMessage : string = 'Ich bestätige hiermit, dass ich während der Bearbeitung von Artikeln in der Anwendung keine Kundendaten (CID) in einem beliebigen Feld eingeben werde.';

    constructor(private router: Router, 
                private cidconfirmService: CidconfirmService,
                private confirmationService: ConfirmationService) {}

    ngOnInit() 
    {  
        var ImpersonatedGPN = sessionStorage.getItem('ImpersonateGPN')
        if(ImpersonatedGPN == null || ImpersonatedGPN == undefined ||ImpersonatedGPN == '' )
        {  
             this.getUserDetails();
        }
        else{
            this.cidconfirm();
        }
        
    }

    confirmCid()
    {
        this.cidconfirmService.SetCIDDate(this.GPN,this.userList.TId,this.userList.FirstName,this.userList.LastName)
        .subscribe (cidConfirm => {
                if(cidConfirm) {
                    this.msgs = [];
                    this.msgs.push({severity:'success',detail:'CID Confirm saved successfully'});
                    this.router.navigate(['capture/']);
                }
                else(!cidConfirm)
                {
                    this.msgs = [];
                    this.msgs.push({severity:'error',detail:'CID Confirm save failed'});
                }
            },
            err => {
                this.msgs = [];
                this.msgs.push({severity:'error',detail:'CID Confirm save failed'}); 
                console.log(err);
            }
        );
    }

    CidNotAuthorized()
    {
        this.msgs = [];
        this.msgs.push({severity:'error',detail:'You are not authorized to access the requested page'});
    }

    isActive(language) { 
        var lng = sessionStorage.getItem('LanguageId');        
        return language === lng;
     };
     selectLanguage(lan :string)
     {         
        this.confirmationService.confirm({
            message: 'Are you sure that you want to change the language?',
            header: 'Confirmation',
            icon: 'fa fa-question-circle',
            accept: () => {
            sessionStorage.setItem('LanguageId', lan)
            if(lan === '1')
                this.cidConfirmMessage = 'I hereby confirm, that while processing items in the application, I will not input Client Identifying Data (CID) in any remark field.';
            if(lan === '2')
                this.cidConfirmMessage = 'Ich bestätige hiermit, dass ich während der Bearbeitung von Artikeln in der Anwendung keine Kundendaten (CID) in einem beliebigen Feld eingeben werde.';
            if(lan === '3')
                this.cidConfirmMessage = "Je confirme par la présente que tout en traitant des éléments dans l'application, je ne saisis pas de données d'identification de client (CID) dans un champ de remarque.";
            if(lan === '4')
                this.cidConfirmMessage = "Con la presente confermo che durante l'elaborazione degli elementi nell'applicazione, non inserirò i Dati di identificazione del cliente (CID) in nessun campo di osservazione.";
            //location.replace('/');
            },
            
        });
     }
     getUserDetails(){
        this.cidconfirmService.getUserDetails()
        .subscribe(userList => {
          this.userList = userList;
          var Role= this.userList.Role.filter(item => item == 'BASE' || item == 'ADMIN' || item == 'SPECIALIST' );
          sessionStorage.setItem('UserName',userList.FirstName +" "+userList.LastName);
          sessionStorage.setItem('Role',userList.Role[0]);
         // sessionStorage.setItem('Role','ADMIN');
          sessionStorage.setItem('Location',this.userList.Location);
          sessionStorage.setItem('GPN',this.userList.GPN);
          sessionStorage.setItem('ouCode',this.userList.OUCode);
          sessionStorage.setItem('ouDesc',this.userList.OUDescription);
          sessionStorage.setItem('additionalOU',this.userList.additionalOU);
          
        
        this.GPN = sessionStorage.getItem('GPN');
          this.cidconfirmService.IsCidValid(this.GPN)
                .subscribe(validCid => { this.validCid = validCid;

                if(this.validCid)    
                {
                    this.router.navigate(['capture/']);            
                }
                else
                {
                    this.pageDisplay = true;
                }
            }); 
        });
    }

          cidconfirm(){
            this.GPN = sessionStorage.getItem('GPN');
            this.cidconfirmService.IsCidValid(this.GPN)
                  .subscribe(validCid => { this.validCid = validCid;
  
                  if(this.validCid)    
                  {
                      this.router.navigate(['capture/']);            
                  }
                  else
                  {
                      this.pageDisplay = true;
                  }
              });
        }
          
    
}