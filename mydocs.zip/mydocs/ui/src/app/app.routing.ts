import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


import { OverviewComponent } from './overview/overview.component';
import { CaptureComponent } from "./capture/capture.component";
import { ReportComponent } from "./reports/reports.component";
import { CapacityPlanningComponent } from './capacity/capacity.component';
import { CapacityAdminComponent } from './Admin/capacityAdmin/capacityAdmin.component';
import { InfoTextComponent } from './Admin/infotext/infotext.component';
import { SegmentComponent } from './Admin/segment/segment.component';
import { NavbarComponent } from './navbar/user/navbar.component';
import { AdminNavbarComponent } from './navbar/adminNavbar/adminNavbar.component';
import {CategoryComponent} from './Admin/Category/category.component';
import {Category2Component} from './Admin/Category/category2.component';
import {Category2EditComponent} from './Admin/Category/category2edit.component';
import {PCategoryEditComponent} from './Admin/Category/Pcategoryedit.component';
import { OrganizationComponent } from'./Admin/organization/organization.component'
import { OuMappingComponent } from './Admin/ou-mapping/ou-mapping.component'
import { CidConfirmComponent } from './cidconfirm/cidconfirm.component'
import { InfoboxComponent } from './capture/infobox.component';
import { CidconfirmAdminComponent } from './Admin/cidconfirmAdmin/cidconfirmAdmin.component'
import { DashboardComponent } from './Admin/dashboard/dashboard.component';

const appRoutes: Routes = [
    
    //no layout routes
    { path: '',component: CidConfirmComponent},
    // otherwise redirect to home
    

    //Site routes goes here 
    { 
        path: '', 
        component: NavbarComponent,
        children: [
          { path: 'capture',component: CaptureComponent},
          { path: 'reports',component: ReportComponent},
          { path: 'planning',component: CapacityPlanningComponent},
          { path: 'overview',component: OverviewComponent}
          
          //{ path: '**',  component: CidConfirmComponent }
        ]
    },
    
    // App routes goes here here
    { 
        path: '',
        component: AdminNavbarComponent, 
        children: [
          { path: 'capacityAdmin',component: CapacityAdminComponent},
          { path: 'Infotext',component: InfoTextComponent},
          { path: 'segment', component: SegmentComponent },
          { path: 'categories2', component: Category2Component },
          { path: 'categories2edit', component: Category2EditComponent },
          { path: 'categoriesedit', component: PCategoryEditComponent },
          { path: 'categories', component: CategoryComponent },         
		  { path: 'organization', component: OrganizationComponent },
          { path: 'ou-mapping', component: OuMappingComponent },
          { path: 'cidConfirmAdmin', component: CidconfirmAdminComponent }, 
          { path: 'dashboard', component: DashboardComponent }	
        ]
    },
    { path: 'infobox', component: InfoboxComponent},
    
    
];

export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes);