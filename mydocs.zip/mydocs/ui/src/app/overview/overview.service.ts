import { Injectable } from "@angular/core";
import { Http, Response, RequestOptions } from '@angular/http';
import { Observable } from "rxjs/Observable";
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/toPromise';
import { overview, TimesheetOverview, SearchFilters, GPNOverview, OuOverview } from "./overview";
import {DatePipe} from "@angular/common";
import { environment } from "../../environments/environment";

@Injectable()
export class OverviewService {
    [x: string]: any;
    baseUrl :string =environment.baseUrl;
    constructor(private http: Http,public datepipe:DatePipe) {}
    getOverview(gpn: string, languageId:number) : Observable<overview>{
        return this.http.get(this.baseUrl + 'overview/Timesheets/'+gpn+'/'+languageId)
        .map((res:Response)=> res.json() as overview)
        .catch(this.handleError)
    }
 
    getExport(searchFilters: SearchFilters):  Observable<Object[]> {
        return Observable.create(observer => {
            let xhr = new XMLHttpRequest();
            let gp;
           if(searchFilters.gpn==""){
                  this.gp=undefined;
           }
           else{
               this.gp=searchFilters.gpn;
           }
           let from_date =this.datepipe.transform(searchFilters.dateFrom, 'yyyy-MM-dd');
           let to_date =this.datepipe.transform(searchFilters.dateTo, 'yyyy-MM-dd');
           let exportedby=sessionStorage.getItem('UserName')+", "+sessionStorage.getItem('GPN');
            xhr.open('GET', this.baseUrl+'overview/Export'+'/'+this.gp+'/'+searchFilters.ou+'/'+searchFilters.search+'/'+searchFilters.categoryId+'/'+from_date+'/'+to_date+'/'+searchFilters.recurrenceId+'/'+searchFilters.savedBy+'/'+searchFilters.uploaded+'/'+searchFilters.languageId+'/'+exportedby+'/'+searchFilters.role+'/'+searchFilters.oudataspace, true);
            //+'/'+searchFilters.gpn+'/'+searchFilters.ou+'/'+searchFilters.search+'/'+searchFilters.categoryId+'/'+searchFilters.dateFrom+'/'+searchFilters.dateTo+'/'+searchFilters.recurrenceId+'/'+searchFilters.savedBy+'/'+searchFilters.uploaded+'/'+searchFilters.languageId
            xhr.setRequestHeader('Content-type', 'application/json');
            xhr.responseType='blob';
    
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4) {
                    if (xhr.status === 200) {
    
                        var contentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
                        var blob = new Blob([xhr.response], { type: contentType });
                        observer.next(blob);
                        observer.complete();
                    } else {
                        observer.error(xhr.response);
                    }
                }
            }
           // let para= JSON.stringify({searchFilters})
        //  let para=searchFilters.gpn+searchFilters.ou+searchFilters.search+searchFilters.categoryId+searchFilters.dateFrom+searchFilters.dateTo+searchFilters.recurrenceId+searchFilters.savedBy+searchFilters.uploaded+searchFilters.languageId
       //  let para= "gpn="+searchFilters.gpn+'&'+"ou="+searchFilters.ou+'&'+"search="+searchFilters.search+'&'+"categoryId="+searchFilters.categoryId+'&'+"dateFrom="+searchFilters.dateFrom+'&'+"dateTo="+searchFilters.dateTo+'&'+"recurrencyId="+searchFilters.recurrenceId+'&'+"savedBy="+searchFilters.savedBy+'&'+"uploaded="+searchFilters.uploaded+'&'+"languageId="+searchFilters.languageId
         
            xhr.send();
    
        });
    }  

    getFilteredData(searchFilters: SearchFilters) : Observable<TimesheetOverview[]>{
        return this.http.post(this.baseUrl + 'overview/Search',searchFilters)
        .map((res:Response)=> res.json())
        .catch(this.handleError)
    }

    deleteRecord(id)
    {        
    //     let headers = new Headers(
    //     {'Content-Type': 'application/json'}
    // );
    // let options = new RequestOptions(
    //     {headers: this.headers}
    // );
        return this.http.delete(this.baseUrl + 'overview/delete/'+id)
        .map((res:Response)=> res.json())
        .catch(this.handleError)
    }

getSearchGPNData(GPNOverview: GPNOverview){
    // let headers = new Headers(
    //     {'Content-Type': 'application/json'}
    // );
    // let options = new RequestOptions(
    //     {headers: this.headers}
    // );
    return this.http.post(this.baseUrl + 'overview/gpnsearch',GPNOverview)
    .map((res:Response)=> res.json())
    .catch(this.handleError)
}

getSearchOuData(OuOverview:OuOverview){
    // let headers = new Headers(
    //     {'Content-Type': 'application/json'}
    // );
    // let options = new RequestOptions(
    //     {headers: this.headers}
    // );
    return this.http.post(this.baseUrl + 'overview/ousearch',OuOverview)
    .map((res:Response)=> res.json())
    .catch(this.handleError)
}

deleteRecurrenceRecord(id)
{        
//     let headers = new Headers(
//     {'Content-Type': 'application/json'}
// );
// let options = new RequestOptions(
//     {headers: this.headers}
// );
    return this.http.delete(this.baseUrl + 'overview/DeleteRecurrence/'+id)
    .map((res:Response)=> res.json())
    .catch(this.handleError)
}

private handleError (error: Response)
{
    console.error(error);
    return Observable.throw(error.json().error || 'Server Error');
}
}