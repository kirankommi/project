import { Component, ViewChild, SkipSelf } from '@angular/core'
import { overview, Category, Recurence, Upload, TimesheetOverview, SearchFilters, OuOverview, GPNOverview, SelectedCategory } from './overview';
import { OverviewService } from './overview.service';
import { Row } from 'primeng/primeng';
import { ConfirmationService, Message } from 'primeng/components/common/api';
import { DatePipe } from '@angular/common';
import { user } from '../navbar/user/user';
import { NavbarService } from '../navbar/user/navbar.service';
import { Router, ActivatedRoute } from '@angular/router';
import { DataTable } from 'primeng/components/datatable/datatable';
import { Validators, FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { CategoryList } from '../capture/capture.modal';
import { forEach } from '@angular/router/src/utils/collection';

@Component({
    selector: 'overview',
    templateUrl: './overview.component.html',
    providers: [ConfirmationService]
})
export class OverviewComponent {
    editRecurrence: boolean = false;
    categoryListBackUp: Category[];
    overViewForm: FormGroup;
    selectedCategory: SelectedCategory = new SelectedCategory();
    isCancelClicked: string;
    timestamp: Date;
    pageTitle: string = 'Overview';
    overview: overview;
    categoryId: number;
    recurrenceId: number;
    uploadedId: number;
    ou: string;
    search: string;
    dateFrom: Date;
    dateTo: Date;
    savedBy: string;
    //oudataspace: string;
    msgs: Message[] = [];
    flag: boolean = true;
    flag1: boolean = true;
    var1 = sessionStorage.getItem('Role');
    var2 = sessionStorage.getItem('GPN');
    gpn: string = this.var2;
    languageId = parseInt(sessionStorage.getItem('LanguageId'));
    dayDifference: number;
    searchFilters: SearchFilters = new SearchFilters();
    display: boolean = false;
    displayOu: boolean = false;
    GPNValue: string = null;
    OuOverview: OuOverview = new OuOverview();
    GPNOverview: GPNOverview = new GPNOverview();
    SelectedOuValue: string;
    SelectedGPNValue: string;
    GPNParam: string;
    currentPage: number = 0;
    isDataSaved: string;
    errorMessage: boolean;
    numberOfRows: number = 50;
    AdminSpecialistparam: boolean=false;
    oudataspace =sessionStorage.getItem('additionalOU')  + "," + sessionStorage.getItem('ouCode');
    userRole = sessionStorage.getItem('Role');
    @ViewChild('dataTable') public dataTable: DataTable;
    constructor(private fb: FormBuilder, private navbarService: NavbarService, private router: Router, private route: ActivatedRoute, private overviewService: OverviewService, private confirmationService: ConfirmationService) {
        this.errorMessage = true;
    }
    ngOnInit() {
        this.overViewForm = this.fb.group({
            'category': new FormControl(''),
            'dateFrom': new FormControl('', Validators.required),
            'dateTo': new FormControl('', Validators.required),
        });
        //Display Current Month Dates on page Load
        var date = new Date(), y = date.getFullYear(), m = date.getMonth();
        this.dateFrom = new Date(y, m, 1);
        this.dateTo = new Date(y, m + 1, 0);
        this.gpn = this.var2;
        this.languageId = this.languageId;
        this.route
            .queryParams
            .subscribe(params => {
                this.isDataSaved = params['saveFlag'];
                this.isCancelClicked = params['cancelFlag'];
            });
        //Display Controls based on role    
        if(sessionStorage.getItem('Role')=="ADMIN" || sessionStorage.getItem('Role')=="SPECIALIST")
        {
        this.AdminSpecialistparam=true;
        }
        if(sessionStorage.getItem('Role')=="BASE")
        {
        this.AdminSpecialistparam=false;
        } 
        //To maintain Filters After returning from capture page
        if (sessionStorage.getItem('searchFilters') != "null" && sessionStorage.getItem('searchFilters') != null && this.isCancelClicked == "true") {
            this.searchFilters = JSON.parse(sessionStorage.getItem('searchFilters'));
            this.search = this.searchFilters.search;
            this.dateFrom = new Date(this.searchFilters.dateFrom);
            this.dateTo = new Date(this.searchFilters.dateTo);
            this.savedBy = this.searchFilters.savedBy;
            this.gpn = this.searchFilters.gpn;
            this.ou = this.searchFilters.ou;
            this.overview = this.searchFilters.overview;
            this.selectedCategory.Id = this.searchFilters.categoryId;
            this.recurrenceId = this.searchFilters.recurrenceId;
            this.uploadedId = this.searchFilters.uploaded;
        //Returning from capture page after saving data by clicking cancel button
            if (this.isDataSaved == "true") {
                this.geteditRecord();
            }
        //Returning from capture page without saving data by clicking cancel button   
            else {
                this.overview = new overview();
                this.overview.CategoryList = JSON.parse(sessionStorage.getItem('searchFilters')).overview.CategoryList,
                    this.overview.Recurency = JSON.parse(sessionStorage.getItem('searchFilters')).overview.Recurency,
                    this.overview.Uploaded = JSON.parse(sessionStorage.getItem('searchFilters')).overview.Uploaded,
                    this.overview.Timesheets = JSON.parse(sessionStorage.getItem('searchFilters')).overview.Timesheets;
                sessionStorage.removeItem('searchFilters');
            }
            this.categoryListBackUp = this.overview.CategoryList;
        //Set Category
            for (let category of this.overview.CategoryList) {
                if (category.Id === this.searchFilters.categoryId) {
                    this.selectedCategory.Name = category.Name;
                    this.selectedCategory.Description = category.Description;
                }
            }
        //To set Current page in pagination after returning from capture page
            this.overViewForm.patchValue({ category: this.selectedCategory });
            var page = Number.parseInt(sessionStorage.getItem('currentPage'));
            this.currentPage = (Number.parseInt(sessionStorage.getItem('currentPage')) - 1) * this.numberOfRows;
            this.dataTable.first = (page - 1) * this.numberOfRows;
        }
        //To load data on page load with current month and GPN filter
        else {
            this.overview = new overview();
            this.overviewService.getOverview(this.gpn, this.languageId)
                .subscribe(overview => {
                    this.overview = overview,
                        this.overview.CategoryList = overview.CategoryList,
                        this.overview.Recurency = overview.Recurency,
                        this.overview.Uploaded = overview.Uploaded,
                        this.categoryListBackUp = overview.CategoryList;
                });
            this.selectedCategory.Id = 0;
            this.recurrenceId = 0;
            this.uploadedId = 0;
        }
    }
    //Taxonomy search in category control
    searchCategory(event) {
        this.overview.CategoryList = this.categoryListBackUp.filter(v => v.Name.toLowerCase().indexOf(event.query.toLowerCase()) > -1)
    }
    //Search filter results
    searchFilter() {
        this.msgs = [];
        if (this.dateFrom == null || this.dateTo == null) {
            this.msgs = [];
            this.msgs.push({ severity: 'error', summary: 'Error Message', detail: 'Please fill date fields' });
        }
        
        else {
            this.searchFilters.search = this.search;
            this.searchFilters.dateFrom = this.dateFrom;
            this.searchFilters.dateTo = this.dateTo;
            this.searchFilters.categoryId = this.selectedCategory.Id;
            this.searchFilters.recurrenceId = this.recurrenceId;
            this.searchFilters.uploaded = this.uploadedId;
            this.searchFilters.savedBy = this.savedBy;
            this.searchFilters.gpn = this.gpn;
            this.searchFilters.ou = this.ou;
            this.searchFilters.oudataspace=this.oudataspace;
            this.searchFilters.role = this.userRole;
            this.searchFilters.languageId = this.languageId;
            var date2 = new Date(this.searchFilters.dateTo);
            var date1 = new Date(this.searchFilters.dateFrom);
            var timeDiff = Math.abs(date2.getTime() - date1.getTime());
            this.dayDifference = Math.ceil(timeDiff / (1000 * 3600 * 24));
    //Cannot view Data of more than 6 months         
            if (this.searchFilters.dateFrom != null && this.searchFilters.dateTo !== null) {
                if (this.dayDifference < 180) {
                    this.overviewService.getFilteredData(this.searchFilters)
                        .subscribe(overview => { this.overview.Timesheets = overview }
                        );
                    console.log(this.overview);
                }
                else {
                    this.msgs = [];
                    this.msgs.push({ severity: 'error', summary: 'Error Message', detail: 'You cannot view data for more than 180 days.' });
                }
            }
            else {
                this.overviewService.getFilteredData(this.searchFilters)
                    .subscribe(overview => { this.overview.Timesheets = overview }
                    );
            }
        }
        
    }
    
    //deleting records
    deleteRecord(Timesheet) {
        if(Timesheet.TimeSheetParameterId != null && Timesheet.TimeSheetParameterId > 0)
        {
            this.confirmationService.confirm({
                message: 'Do you want to delete the whole recurrence?',
                header: 'Delete Confirmation',
                icon: 'fa fa-trash',
                accept: () => {
                    this.overviewService.deleteRecurrenceRecord(Timesheet.TimeSheetParameterId)
                        .subscribe(response => {
                            this.msgs = [];
                            this.msgs.push({ severity: 'success', detail: 'Deleted successfully' });
                           if(this.searchFilters != null)
                           {
                            this.overviewService.getFilteredData(this.searchFilters)
                            .subscribe(overview => { this.overview.Timesheets = overview }
                            );
                           }
                           else
                           {
                            this.overviewService.getOverview(this.gpn, this.languageId)
                            .subscribe(overview => {
                                this.overview = overview,
                                    this.overview.CategoryList = overview.CategoryList,
                                    this.overview.Recurency = overview.Recurency,
                                    this.overview.Uploaded = overview.Uploaded,
                                    this.categoryListBackUp = overview.CategoryList;
                            });
                           }
                            
                        },
                            err => {
                                this.errorMessage = true;
                                this.msgs = [];
                                this.msgs.push({ severity: 'error', detail: 'Entry cannot be deleted' });
                                console.log(err);
                            }
                        );
                },
                reject: () => {
                    this.overviewService.deleteRecord(Timesheet.Id)
                        .subscribe(response => {
                            this.msgs = [];
                            this.msgs.push({ severity: 'success', detail: 'Deleted successfully' });
                            if(this.searchFilters != null)
                            {
                             this.overviewService.getFilteredData(this.searchFilters)
                             .subscribe(overview => { this.overview.Timesheets = overview }
                             );
                            }
                            else
                            {
                             this.overviewService.getOverview(this.gpn, this.languageId)
                             .subscribe(overview => {
                                 this.overview = overview,
                                     this.overview.CategoryList = overview.CategoryList,
                                     this.overview.Recurency = overview.Recurency,
                                     this.overview.Uploaded = overview.Uploaded,
                                     this.categoryListBackUp = overview.CategoryList;
                             });
                            }
                        },
                            err => {
                                this.errorMessage = true;
                                this.msgs = [];
                                this.msgs.push({ severity: 'error', detail: 'Entry cannot be deleted' });
                                console.log(err);
                            }
                        );
                }
            });
        }
        else{
        this.confirmationService.confirm({
            message: 'Are you sure you want to delete this entry?',
            header: 'Delete Confirmation',
            icon: 'fa fa-trash',
            accept: () => {
                this.overviewService.deleteRecord(Timesheet.Id)
                    .subscribe(response => {
                        this.msgs = [];
                        this.msgs.push({ severity: 'success', detail: 'Deleted successfully' });
                        var y = this.overview.Timesheets.indexOf(Timesheet);
                        this.overview.Timesheets = this.overview.Timesheets.filter((val, i) => i != y);
                    },
                        err => {
                            this.errorMessage = true;
                            this.msgs = [];
                            this.msgs.push({ severity: 'error', detail: 'Entry cannot be deleted' });
                            console.log(err);
                        }
                    );
            },
        });
    }
        console.log(this.overview.Timesheets);
    }

    // checkbox(deleterow) {
    //     deleterow.isSelectedForDelete = !deleterow.isSelectedForDelete;

    // }

    // deleteRecord() {
    //     this.i = this.overview.Timesheets.filter(x => x.isSelectedForDelete).map(l => l.Id);
    //     var count = this.i.length;
    //     if (count > 1) {
    //         if (this.var1 === "Admin" || this.var1 === "Specialist") {
    //             this.confirmationService.confirm({
    //                 message: 'Do you want to delete this record?',
    //                 header: 'Delete Confirmation',
    //                 icon: 'fa fa-trash',
    //                 accept: () => {
    //                     this.overviewService.deleteRecord(this.i.join(","))
    //                         .subscribe(response => {
    //                             this.msgs = [];
    //             this.msgs.push({severity:'success', summary:'Success Message', detail:'Records deleted succesfully'});
    //                             this.overview.Timesheets = this.overview.Timesheets.filter(x => !x.isSelectedForDelete);
    //                         })
    //                 },
    //                 reject: () => {
    //                     this.msgs = [];
    //                     this.msgs.push({severity:'error', detail:'You have rejected'});
    //                 }

    //             });
    //         }
    //         else {
    //             this.msgs = [];
    //             this.msgs.push({severity:'error', summary:'Error Message', detail:'Please select only one entry to delete.'});
    //     }
    //     }
    //     else if (count == 1) {
    //         this.confirmationService.confirm({
    //             message: 'Do you want to delete this record?',
    //             header: 'Delete Confirmation',
    //             icon: 'fa fa-trash',
    //             accept: () => {
    //                 this.overviewService.deleteRecord(this.i.join(","))
    //                     .subscribe(response => {
    //                         this.msgs = [];
    //                         this.msgs.push({severity:'success', summary:'Success Message', detail:'Record deleted succesfully'});
    //                         this.overview.Timesheets = this.overview.Timesheets.filter(x => !x.isSelectedForDelete);
    //                     })
    //             },
    //             reject: () => {
    //                 this.msgs = [];
    //                 this.msgs.push({severity:'error', detail:'You have rejected'});
    //             }

    //         });
    //     }

    // }
    reset() {
        this.msgs = [];
        this.gpn = this.var2;
        var date = new Date(), y = date.getFullYear(), m = date.getMonth();
        this.dateFrom = new Date(y, m, 1);
        this.dateTo = new Date(y, m + 1, 0);
        this.savedBy = "";
        this.search = "";
        this.selectedCategory.Id = 0;
        this.selectedCategory.Name = null;
        this.overViewForm.patchValue({ category: this.selectedCategory });
        this.recurrenceId = 0;
        this.uploadedId = 0;
        this.ou = "";
        this.currentPage = 0;
        this.overviewService.getOverview(this.gpn, this.languageId)
            .subscribe(overview => {
                this.overview = overview,
                    this.categoryListBackUp = this.overview.CategoryList;
            });
    }

    //todays date filter
    todaysDate() {
        this.msgs = [];
        this.flag = true;
        this.dateFrom = new Date();
        this.dateTo = new Date();
        this.searchFilters = new SearchFilters();
        this.searchFilters.search = this.search;
        this.searchFilters.dateFrom = this.dateFrom;
        this.searchFilters.dateTo = this.dateTo;
        this.searchFilters.categoryId = this.selectedCategory.Id;
        this.searchFilters.recurrenceId = this.recurrenceId;
        this.searchFilters.uploaded = this.uploadedId;
        this.searchFilters.savedBy = this.savedBy;
        this.searchFilters.gpn = this.gpn;
        this.searchFilters.ou = this.ou;
        this.searchFilters.languageId = this.languageId;
        this.searchFilters.oudataspace=this.oudataspace;
        this.searchFilters.role = this.userRole;
        this.overviewService.getFilteredData(this.searchFilters)
            .subscribe(overview => { this.overview.Timesheets = overview }
            );
    }

    //current month filter
    currentMonth() {
        this.msgs = [];
        this.flag = true;
        var date = new Date(), y = date.getFullYear(), m = date.getMonth();
        this.dateFrom = new Date(y, m, 1);
        this.dateTo = new Date(y, m + 1, 0);
        this.searchFilters = new SearchFilters();
        this.searchFilters.search = this.search;
        this.searchFilters.dateFrom = this.dateFrom;
        this.searchFilters.dateTo = this.dateTo;
        this.searchFilters.categoryId = this.selectedCategory.Id;
        this.searchFilters.recurrenceId = this.recurrenceId;
        this.searchFilters.uploaded = this.uploadedId;
        this.searchFilters.savedBy = this.savedBy;
        this.searchFilters.gpn = this.gpn;
        this.searchFilters.ou = this.ou;
        this.searchFilters.languageId = this.languageId;
        this.searchFilters.oudataspace=this.oudataspace;
        this.searchFilters.role = this.userRole;
        this.overviewService.getFilteredData(this.searchFilters)
            .subscribe(overview => { this.overview.Timesheets = overview }
            );
    }

    //previous month filter
    previousMonth() {
        this.msgs = [];
        var date = new Date(), y = date.getFullYear(), m = date.getMonth() - 1;
        this.dateFrom = new Date(y, m, 1);
        this.dateTo = new Date(y, m + 1, 0);
        this.searchFilters = new SearchFilters();
        this.searchFilters.search = this.search;
        this.searchFilters.dateFrom = this.dateFrom;
        this.searchFilters.dateTo = this.dateTo;
        this.searchFilters.categoryId = this.selectedCategory.Id;
        this.searchFilters.recurrenceId = this.recurrenceId;
        this.searchFilters.uploaded = this.uploadedId;
        this.searchFilters.savedBy = this.savedBy;
        this.searchFilters.gpn = this.gpn;
        this.searchFilters.ou = this.ou;
        this.searchFilters.languageId = this.languageId;
        this.searchFilters.oudataspace=this.oudataspace;
        this.searchFilters.role = this.userRole;
        this.overviewService.getFilteredData(this.searchFilters)
            .subscribe(overview => { this.overview.Timesheets = overview }
            );
    }

    //export record
    exportRecord() {
        this.msgs = [];
        this.searchFilters = new SearchFilters();
        this.searchFilters.search = this.search;
        this.searchFilters.dateFrom = this.dateFrom;
        this.searchFilters.dateTo = this.dateTo;
        this.searchFilters.categoryId = this.selectedCategory.Id;
        this.searchFilters.recurrenceId = this.recurrenceId;
        this.searchFilters.uploaded = this.uploadedId;
        this.searchFilters.savedBy = this.savedBy;
        this.searchFilters.gpn = this.gpn;
        this.searchFilters.ou = this.ou;
        this.searchFilters.languageId = this.languageId;
        this.searchFilters.oudataspace=this.oudataspace;
        this.searchFilters.role = this.userRole;
        this.searchFilters.overview = this.overview;
        var link = document.createElement('a');
        this.overviewService.getExport(this.searchFilters)
            .subscribe(blob => {
                link.href = window.URL.createObjectURL(blob);
                //var fileBlob = new Blob([returnedJSON.data], {type: 'application/pdf'});
                if (navigator.appVersion.toString().indexOf('.NET') > 0) { // for IE browser
                   // window.navigator.msSaveBlob(blob, "CMR_Export_OverviewPage.xlsx");
                    window.navigator.msSaveOrOpenBlob(blob, "CMR_Export_OverviewPage.xlsx"); 
                } else { // for other browsers
                    link.href = window.URL.createObjectURL(blob);
                    this.timestamp = new Date(Date.now())
                    link.download = "CMR_Export_OverviewPage " + this.timestamp.toString() + ".xlsx";
                    link.click();
                }
            })
    }

    //saving filters on click of edit
    editRecord(Timesheet) {       
        this.searchFilters = new SearchFilters();
        this.searchFilters.search = this.search;
        this.searchFilters.dateFrom = this.dateFrom;
        this.searchFilters.dateTo = this.dateTo;
        this.searchFilters.categoryId = this.selectedCategory.Id;
        this.searchFilters.recurrenceId = this.recurrenceId;
        this.searchFilters.uploaded = this.uploadedId;
        this.searchFilters.savedBy = this.savedBy;
        this.searchFilters.gpn = this.gpn;
        this.searchFilters.ou = this.ou;
        this.searchFilters.languageId = this.languageId;
        this.searchFilters.overview = this.overview;
        this.searchFilters.oudataspace=this.oudataspace;
        this.searchFilters.role = this.userRole;
        this.searchFilters.overview.CategoryList = this.categoryListBackUp;
        this.currentPage = this.currentPage / this.numberOfRows + 1;
        sessionStorage.setItem('currentPage', this.currentPage.toString());
        sessionStorage.setItem('searchFilters', JSON.stringify(this.searchFilters));
        if(Timesheet.TimeSheetParameterId != null && Timesheet.TimeSheetParameterId > 0)
        {
            this.confirmationService.confirm({
                message: 'Do you want to edit the whole recurrence?',
                header: 'Edit Confirmation',
                icon: 'fa fa-trash',
                accept: () => {
                  this.editRecurrence = true;
                  this.router.navigate(['/capture'], { queryParams: { Id: Timesheet.Id, EnableRecurrence: this.editRecurrence } });
                },
                reject:()=>{
                  this.editRecurrence = false;
                  this.router.navigate(['/capture'], { queryParams: { Id: Timesheet.Id, EnableRecurrence: this.editRecurrence } });
                }
            });
        }
        else
        {
            this.router.navigate(['/capture'], { queryParams: { Id: Timesheet.Id, EnableRecurrence: this.editRecurrence } });
        }
        
    }
  
    searchGPN() {
        this.overviewService.getSearchGPNData(this.GPNOverview)
            .subscribe(overview => { this.overview.GPNSearchList = overview }
            );
        //console.log(this.overview);

    }
    searchOu() {
        this.overviewService.getSearchOuData(this.OuOverview)
            .subscribe(overview => { this.overview.OuSearchList = overview }
            );
        //console.log(this.overview);
    }
    searchGPNReset() {
        this.GPNOverview.SearchLastName = null;
        this.GPNOverview.SearchFirstName = null;
        this.GPNOverview.SearchGPN = null;
        this.GPNOverview.SearchOUCode = null;
        this.GPNOverview.SearchUserID = null;
        this.GPNOverview.SearchTNumber = null;
        this.overview.GPNSearchList = null;
    }

    searchGpnOk() {
        if (this.GPNParam == "GPN") {
            this.gpn = this.SelectedGPNValue;
        }
        else if (this.GPNParam == "SavedBy") {
            this.savedBy = this.SelectedGPNValue;
        }
        this.display = false;
    }

    showDialog(param: string) {
        if (param == "GPN" && this.SelectedGPNValue != this.gpn) {
            this.searchGPNReset();
        }
        else if (param == "SavedBy" && this.SelectedGPNValue != this.savedBy) {
            this.searchGPNReset();
        }
        this.GPNParam = param;
        this.display = true;
    }

    showOuDialog() {
        if (this.SelectedOuValue != this.ou) {
            this.searchOuReset();
        }
        this.displayOu = true;
    }

    searchOuReset() {
        this.overview.OuSearchList = null;
        this.OuOverview.SearchOuCode = null;
        this.OuOverview.SearchOuDesc = null;

    }

    searchOuOk() {
        this.ou = this.SelectedOuValue;
        this.displayOu = false;
    }

    getOuValue(OuCode) {
        this.SelectedOuValue = OuCode;
    }

    getGPNValue(GPN) {
        this.SelectedGPNValue = GPN;
    }

    //Reteiving filters after returning from capture page
    geteditRecord() {
        this.search = this.searchFilters.search;
        this.dateFrom = new Date(this.searchFilters.dateFrom);
        this.dateTo = new Date(this.searchFilters.dateTo);
        this.savedBy = this.searchFilters.savedBy;
        this.gpn = this.searchFilters.gpn;
        this.ou = this.searchFilters.ou;
        this.overview = this.searchFilters.overview;
        this.selectedCategory.Id = this.searchFilters.categoryId;
        this.recurrenceId = this.searchFilters.recurrenceId;
        this.uploadedId = this.searchFilters.uploaded;
        this.oudataspace = this.searchFilters.oudataspace;
        this.userRole = this.searchFilters.role;
        sessionStorage.removeItem('searchFilters');
        this.overviewService.getFilteredData(this.searchFilters)
            .subscribe(timesheetData => {
                this.overview.Timesheets = timesheetData
            }
            );
    }
}