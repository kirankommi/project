export class overview {
    CategoryList : Category[] ;
    Recurency: Recurence[];
    Uploaded: Upload[];
    Timesheets: TimesheetOverview[]; 
    GPNSearchList:GPNOverview[]; 
    OuSearchList: OuOverview[];  
  
 }

 export class Category{
    Id : number;
    Name: string;
    Description: string;
 }
 export class SelectedCategory{
    Id : number;
    Name: string;
    Description: string;
 }
 export class TimesheetOverview{
    Id : number;
    CategoryName: string;
    CategoryId : number;
    Title : string;
    GPN: string;
    SavedBy: string;
    Duration : number;
    TimesheetDate : Date;
    EditButtonFlag: boolean;
    isSelectedForDelete : boolean= false;
    TimeSheetParameterId : number;
    
 }
 export class Recurence{
    Id : number;
    CategoryId : number;
    Title : string;
    GPN: string;
    SavedBy: string;
    Duration : number;
    TimesheetDate : Date;
 }
 export class Upload{
    Id : number;
    CategoryId : number;
 }
 export class SearchFilters{
    gpn: string;
    ou :string;
    search: string;
    categoryId:number;
    dateFrom : Date;
    dateTo :Date;
    recurrenceId :number;
    savedBy :string;
    uploaded :number; 
    oudataspace: string;
    languageId: number;
    overview : overview;
    role:string;
 }
 export class GPNOverview{
    SearchGPN:string;
    SearchLastName: string;
    SearchFirstName:string;
    SearchOUCode:string;
    SearchUserID:string;
    SearchTNumber: string;
 }
 export class OuOverview{
    SearchOuCode:string;
    SearchOuDesc: string;
 }
 