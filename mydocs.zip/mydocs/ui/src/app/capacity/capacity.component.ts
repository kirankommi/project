import { Component, OnInit, Input, Directive} from '@angular/core';
import { Category, Recurence, Upload, TimesheetOverview, SearchFilters, OuOverview,SelectedCategory } from '../overview/overview';
import { Row } from 'primeng/primeng';
import { ConfirmationService, Message } from 'primeng/components/common/api';
import { DatePipe } from '@angular/common';
import { NavbarService } from '../navbar/user/navbar.service';
import { Router, ActivatedRoute } from '@angular/router';
import { DataTable } from 'primeng/components/datatable/datatable';
import { Validators, FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { OverviewService } from '../overview/overview.service';
import { overview, GPNOverview } from '../overview/overview';

import { CapacityAdminPlanningService } from './capacityPlanning.service';
import { CapacityPlanning, CapacityDetailsPlanning } from './capacityAdminPlanning';
import { Capacity } from './../Admin/capacityAdmin/capacityAdmin';



@Component({
selector : 'pm-capacityplanning',
templateUrl : './capacity.component.html'
})

export class CapacityPlanningComponent
{    
    display: boolean = false;
    displayOu: boolean = false;
    GPNValue: string = null;
    OuOverview: OuOverview = new OuOverview();
    GPNOverview: GPNOverview = new GPNOverview();
    SelectedOuValue: string;
    SelectedGPNValue: string;
    GPNParam: string;
    Id: number;
    capacityListPlanning: CapacityPlanning[];
    addList: CapacityPlanning[];
    capacityDetailListPlanning: CapacityDetailsPlanning[];
    selectedRows: CapacityPlanning;
    displayDialog: boolean;
    newValue: boolean;
    OU: string;
    GPN: string;
    LastName: string;
    FirstName: string;
    Pensum: number;
    entity: CapacityPlanning = new CapacityPlanning();
    msgs: Message[] = [];
    errorMessage: boolean;
    isActive: boolean = true;
    uploadedFiles: any[] = [];
    capacityDetailSelected = [];
    timestamp: Date;
    Month0: number;
    Month1: number;
    Month2: number;
    Month3: number;
    Month4: number;
    Month5: number;
    Month6: number;
    Month7: number;
    Month8: number;
    Month9: number;
    Month10: number;
    Month11: number;
    Month12: number;
    Month13: number;
    //isDisabled :boolean=true;
    headers: string[];
    totalRows:number;
    arrayStart:number;
    arrayEnd:number;
   // var2 = sessionStorage.getItem('GPN');
    gpn: string;
    savedBy: string;
    ou: string;
    overview: overview = new overview();
    newElement:CapacityPlanning;
    numberOfRows : number= 50;
    constructor(private overviewService: OverviewService, private capacityPlanningService: CapacityAdminPlanningService)
    {
        
    }
    
    ngOnInit() {
       
        this.capacityPlanningService.getCapacityPlanning(null,null)
            .subscribe(capacityplanning => {
                this.capacityListPlanning = capacityplanning.CapacityList;      
                //this.newCapacityListPlanning = capacityplanning.CapacityList;
                this.headers = capacityplanning.headers;
                this.capacityDetailListPlanning = this.capacityListPlanning[0].CapacityDetailsList;
                
                for (let item of this.capacityListPlanning) {
                    item.Month0 = item.CapacityDetailsList[0] != null ? item.CapacityDetailsList[0].Value : null;
                    item.Month1 = item.CapacityDetailsList[1] != null ? item.CapacityDetailsList[1].Value : null;
                    item.Month2 = item.CapacityDetailsList[2] != null ? item.CapacityDetailsList[2].Value : null;
                    item.Month3 = item.CapacityDetailsList[3] != null ? item.CapacityDetailsList[3].Value : null;
                    item.Month4 = item.CapacityDetailsList[4] != null ? item.CapacityDetailsList[4].Value : null;
                    item.Month5 = item.CapacityDetailsList[5] != null ? item.CapacityDetailsList[5].Value : null;
                    item.Month6 = item.CapacityDetailsList[6] != null ? item.CapacityDetailsList[6].Value : null;
                    item.Month7 = item.CapacityDetailsList[7] != null ? item.CapacityDetailsList[7].Value : null;
                    item.Month8 = item.CapacityDetailsList[8] != null ? item.CapacityDetailsList[8].Value : null;
                    item.Month9 = item.CapacityDetailsList[9] != null ? item.CapacityDetailsList[9].Value : null;
                    item.Month10 = item.CapacityDetailsList[10] != null ? item.CapacityDetailsList[10].Value : null;
                    item.Month11 = item.CapacityDetailsList[11] != null ? item.CapacityDetailsList[11].Value : null;
                    item.Month12 = item.CapacityDetailsList[12] != null ? item.CapacityDetailsList[12].Value : null;
                    item.Month13 = item.CapacityDetailsList[13] != null ? item.CapacityDetailsList[13].Value : null;
                }
                this.totalRows=Math.floor(this.capacityListPlanning.length/this.numberOfRows );
                var count = 0;
                for(var i=0; i<this.totalRows; i++)
                {
                    this.arrayStart = i*this.numberOfRows;  
                    this.newElement = this.CreateNewElement();
                    this.capacityListPlanning.splice(this.arrayStart, 0, this.newElement);
                    var newElementPerDay = new CapacityPlanning();
                    newElementPerDay.Month0 = Math.round(this.newElement.Month0/8.5);
                    newElementPerDay.Month1 = Math.round(this.newElement.Month1/8.5);
                    newElementPerDay.Month2 = Math.round(this.newElement.Month2/8.5);
                    newElementPerDay.Month3 = Math.round(this.newElement.Month3/8.5);
                    newElementPerDay.Month4 = Math.round(this.newElement.Month4/8.5);
                    newElementPerDay.Month5 = Math.round(this.newElement.Month5/8.5);
                    newElementPerDay.Month6 = Math.round(this.newElement.Month6/8.5);
                    newElementPerDay.Month7 = Math.round(this.newElement.Month7/8.5);
                    newElementPerDay.Month8 = Math.round(this.newElement.Month8/8.5);
                    newElementPerDay.Month9 = Math.round(this.newElement.Month9/8.5);
                    newElementPerDay.Month10 = Math.round(this.newElement.Month10/8.5);
                    newElementPerDay.Month11 = Math.round(this.newElement.Month11/8.5);
                    newElementPerDay.Month12 = Math.round(this.newElement.Month12/8.5);
                    newElementPerDay.Month13= Math.round(this.newElement.Month13/8.5);
                    this.capacityListPlanning.splice(this.arrayStart, 0, newElementPerDay);
                    count++;                 
                }
                this.arrayStart = count == 0? 0: count *this.numberOfRows + 1;
                if(this.capacityListPlanning.length - this.totalRows % this.numberOfRows != 0)
                {
                    //this.newElement = new CapacityPlanning();
                    this.newElement = this.CreateNewElement() ;
                    this.capacityListPlanning.splice(this.arrayStart, 0, this.newElement);
                    var newElementPerDay = new CapacityPlanning();
                    newElementPerDay.Month0 = Math.round(this.newElement.Month0/8.5);
                    newElementPerDay.Month1 = Math.round(this.newElement.Month1/8.5);
                    newElementPerDay.Month2 = Math.round(this.newElement.Month2/8.5);
                    newElementPerDay.Month3 = Math.round(this.newElement.Month3/8.5);
                    newElementPerDay.Month4 = Math.round(this.newElement.Month4/8.5);
                    newElementPerDay.Month5 = Math.round(this.newElement.Month5/8.5);
                    newElementPerDay.Month6 = Math.round(this.newElement.Month6/8.5);
                    newElementPerDay.Month7 = Math.round(this.newElement.Month7/8.5);
                    newElementPerDay.Month8 = Math.round(this.newElement.Month8/8.5);
                    newElementPerDay.Month9 = Math.round(this.newElement.Month9/8.5);
                    newElementPerDay.Month10 = Math.round(this.newElement.Month10/8.5);
                    newElementPerDay.Month11 = Math.round(this.newElement.Month11/8.5);
                    newElementPerDay.Month12 = Math.round(this.newElement.Month12/8.5);
                    newElementPerDay.Month13= Math.round(this.newElement.Month13/8.5);
                    this.capacityListPlanning.splice(this.arrayStart, 0, newElementPerDay);
                    
                }
            
            });
    }
    CreateNewElement()
    {        
        this.newElement = new CapacityPlanning();
        this.newElement.Month0 = this.capacityListPlanning.slice(this.arrayStart, this.arrayStart + this.numberOfRows).map(x=>x.Month0).reduce(function(accumulator, currentValue, currentIndex, array) 
        {
            return Math.round(accumulator + currentValue);
        });
        this.newElement.Month1 = this.capacityListPlanning.slice(this.arrayStart, this.arrayStart + this.numberOfRows).map(x=>x.Month1).reduce(function(accumulator, currentValue, currentIndex, array) 
        {
            return   Math.round(accumulator + currentValue);
        });
        this.newElement.Month2 = this.capacityListPlanning.slice(this.arrayStart, this.arrayStart + this.numberOfRows).map(x=>x.Month2).reduce(function(accumulator, currentValue, currentIndex, array) 
        {
            return  Math.round(accumulator + currentValue);
        });
        this.newElement.Month3 = this.capacityListPlanning.slice(this.arrayStart, this.arrayStart + this.numberOfRows).map(x=>x.Month3).reduce(function(accumulator, currentValue, currentIndex, array) 
        {
            return  Math.round(accumulator + currentValue);
        });
        this.newElement.Month4 = this.capacityListPlanning.slice(this.arrayStart, this.arrayStart + this.numberOfRows).map(x=>x.Month4).reduce(function(accumulator, currentValue, currentIndex, array) 
        {
            return  Math.round(accumulator + currentValue);
        });
        this.newElement.Month5 = this.capacityListPlanning.slice(this.arrayStart, this.arrayStart + this.numberOfRows).map(x=>x.Month5).reduce(function(accumulator, currentValue, currentIndex, array) 
        {
            return  Math.round(accumulator + currentValue);
        });
        this.newElement.Month6 = this.capacityListPlanning.slice(this.arrayStart, this.arrayStart + this.numberOfRows).map(x=>x.Month6).reduce(function(accumulator, currentValue, currentIndex, array) 
        {
            return  Math.round(accumulator + currentValue);
        });
        this.newElement.Month7 = this.capacityListPlanning.slice(this.arrayStart, this.arrayStart + this.numberOfRows).map(x=>x.Month7).reduce(function(accumulator, currentValue, currentIndex, array) 
        {
            return  Math.round(accumulator + currentValue);
        });
        this.newElement.Month8 = this.capacityListPlanning.slice(this.arrayStart, this.arrayStart + this.numberOfRows).map(x=>x.Month8).reduce(function(accumulator, currentValue, currentIndex, array) 
        {
            return  Math.round(accumulator + currentValue);
        });
        this.newElement.Month9 = this.capacityListPlanning.slice(this.arrayStart, this.arrayStart + this.numberOfRows).map(x=>x.Month9).reduce(function(accumulator, currentValue, currentIndex, array) 
        {
            return  Math.round(accumulator + currentValue);
        });
        this.newElement.Month10 = this.capacityListPlanning.slice(this.arrayStart, this.arrayStart + this.numberOfRows).map(x=>x.Month10).reduce(function(accumulator, currentValue, currentIndex, array) 
        {
            return  Math.round(accumulator + currentValue);
        });
        this.newElement.Month11 = this.capacityListPlanning.slice(this.arrayStart, this.arrayStart + this.numberOfRows).map(x=>x.Month11).reduce(function(accumulator, currentValue, currentIndex, array) 
        {
            return  Math.round(accumulator + currentValue);
        });
        this.newElement.Month12 = this.capacityListPlanning.slice(this.arrayStart, this.arrayStart + this.numberOfRows).map(x=>x.Month12).reduce(function(accumulator, currentValue, currentIndex, array) 
        {
            return  Math.round(accumulator + currentValue);
        });
        this.newElement.Month13 = this.capacityListPlanning.slice(this.arrayStart, this.arrayStart + this.numberOfRows).map(x=>x.Month13).reduce(function(accumulator, currentValue, currentIndex, array) 
        {
            return  Math.round(accumulator + currentValue);
        });
        return this.newElement;
    }
    GetHeder(month) {
        if (this.capacityDetailListPlanning == null || this.capacityDetailListPlanning == undefined) return '';
        return this.headers[month];//.filter(x => x.DynamicColumnName == month).map(l => l.Month);

    }
    searchGPN() {
        this.overviewService.getSearchGPNData(this.GPNOverview)
            .subscribe(overview => { this.overview.GPNSearchList = overview }
            );
        //console.log(this.overview);

    }
    searchOu() {
        this.overviewService.getSearchOuData(this.OuOverview)
            .subscribe(overview => { this.overview.OuSearchList = overview }
            );
        //console.log(this.overview);
    }
    searchGPNReset() {
        this.GPNOverview.SearchLastName = null;
        this.GPNOverview.SearchFirstName = null;
        this.GPNOverview.SearchGPN = null;
        this.GPNOverview.SearchOUCode = null;
        this.GPNOverview.SearchUserID = null;
        this.GPNOverview.SearchTNumber = null;
        this.overview.GPNSearchList = null;
    }

    searchGpnOk() {
        if (this.GPNParam == "GPN") {
            this.gpn = this.SelectedGPNValue;
        }
        else if (this.GPNParam == "SavedBy") {
            this.savedBy = this.SelectedGPNValue;
        }
        this.display = false;
    }

    showDialog(param: string) {
        if (param == "GPN" && this.SelectedGPNValue != this.gpn) {
            this.searchGPNReset();
        }
        else if (param == "SavedBy" && this.SelectedGPNValue != this.savedBy) {
            this.searchGPNReset();
        }
        this.GPNParam = param;
        this.display = true;
    }

    showOuDialog() {
        if (this.SelectedOuValue != this.ou) {
            this.searchOuReset();
        }
        this.displayOu = true;
    }

    searchOuReset() {
        this.overview.OuSearchList = null;
        this.OuOverview.SearchOuCode = null;
        this.OuOverview.SearchOuDesc = null;

    }

    searchOuOk() {
        this.ou = this.SelectedOuValue;
        this.displayOu = false;
    }

    getOuValue(OuCode) {
        this.SelectedOuValue = OuCode;
    }

    getGPNValue(GPN) {
        this.SelectedGPNValue = GPN;
    }

 getCapacityFilter()
 {
    if (this.gpn=="" || this.gpn==undefined)
    {
        this.gpn= null;
    }
    if (this.ou=="" || this.ou==undefined)
    {
    this.ou= null;
    }
    this.capacityListPlanning.length = 0;
     this.capacityPlanningService.getCapacityPlanning(this.gpn,this.ou)
     .subscribe(capacityplanning => {
        this.capacityListPlanning = capacityplanning.CapacityList;
        console.log(this.capacityListPlanning);
        this.headers = capacityplanning.headers;
        if(this.capacityListPlanning.length!=0)
        {
        this.capacityDetailListPlanning = this.capacityListPlanning[0].CapacityDetailsList;
        
        for (let item of this.capacityListPlanning) {
            item.Month0 = item.CapacityDetailsList[0] != null ? item.CapacityDetailsList[0].Value : null;
            item.Month1 = item.CapacityDetailsList[1] != null ? item.CapacityDetailsList[1].Value : null;
            item.Month2 = item.CapacityDetailsList[2] != null ? item.CapacityDetailsList[2].Value : null;
            item.Month3 = item.CapacityDetailsList[3] != null ? item.CapacityDetailsList[3].Value : null;
            item.Month4 = item.CapacityDetailsList[4] != null ? item.CapacityDetailsList[4].Value : null;
            item.Month5 = item.CapacityDetailsList[5] != null ? item.CapacityDetailsList[5].Value : null;
            item.Month6 = item.CapacityDetailsList[6] != null ? item.CapacityDetailsList[6].Value : null;
            item.Month7 = item.CapacityDetailsList[7] != null ? item.CapacityDetailsList[7].Value : null;
            item.Month8 = item.CapacityDetailsList[8] != null ? item.CapacityDetailsList[8].Value : null;
            item.Month9 = item.CapacityDetailsList[9] != null ? item.CapacityDetailsList[9].Value : null;
            item.Month10 = item.CapacityDetailsList[10] != null ? item.CapacityDetailsList[10].Value : null;
            item.Month11 = item.CapacityDetailsList[11] != null ? item.CapacityDetailsList[11].Value : null;
            item.Month12 = item.CapacityDetailsList[12] != null ? item.CapacityDetailsList[12].Value : null;
            item.Month13 = item.CapacityDetailsList[13] != null ? item.CapacityDetailsList[13].Value : null;
        }
        this.totalRows=Math.floor(this.capacityListPlanning.length/this.numberOfRows );
        var count = 0;
        for(var i=0; i<this.totalRows; i++)
        {
            this.arrayStart = i*this.numberOfRows;  
            this.newElement = this.CreateNewElement();
            this.capacityListPlanning.splice(this.arrayStart, 0, this.newElement);
            var newElementPerDay = new CapacityPlanning();
            newElementPerDay.Month0 = Math.round(this.newElement.Month0/8.5);
            newElementPerDay.Month1 = Math.round(this.newElement.Month1/8.5);
            newElementPerDay.Month2 = Math.round(this.newElement.Month2/8.5);
            newElementPerDay.Month3 = Math.round(this.newElement.Month3/8.5);
            newElementPerDay.Month4 = Math.round(this.newElement.Month4/8.5);
            newElementPerDay.Month5 = Math.round(this.newElement.Month5/8.5);
            newElementPerDay.Month6 = Math.round(this.newElement.Month6/8.5);
            newElementPerDay.Month7 = Math.round(this.newElement.Month7/8.5);
            newElementPerDay.Month8 = Math.round(this.newElement.Month8/8.5);
            newElementPerDay.Month9 = Math.round(this.newElement.Month9/8.5);
            newElementPerDay.Month10 = Math.round(this.newElement.Month10/8.5);
            newElementPerDay.Month11 = Math.round(this.newElement.Month11/8.5);
            newElementPerDay.Month12 = Math.round(this.newElement.Month12/8.5);
            newElementPerDay.Month13= Math.round(this.newElement.Month13/8.5);
            this.capacityListPlanning.splice(this.arrayStart, 0, newElementPerDay);
            count++;                 
        }
        this.arrayStart = count == 0? 0: count *this.numberOfRows + 1;
        if(this.capacityListPlanning.length - this.totalRows % this.numberOfRows != 0)
        {
            //this.newElement = new CapacityPlanning();
            this.newElement = this.CreateNewElement() ;
            this.capacityListPlanning.splice(this.arrayStart, 0, this.newElement);
            var newElementPerDay = new CapacityPlanning();
            newElementPerDay.Month0 = Math.round(this.newElement.Month0/8.5);
            newElementPerDay.Month1 = Math.round(this.newElement.Month1/8.5);
            newElementPerDay.Month2 = Math.round(this.newElement.Month2/8.5);
            newElementPerDay.Month3 = Math.round(this.newElement.Month3/8.5);
            newElementPerDay.Month4 = Math.round(this.newElement.Month4/8.5);
            newElementPerDay.Month5 = Math.round(this.newElement.Month5/8.5);
            newElementPerDay.Month6 = Math.round(this.newElement.Month6/8.5);
            newElementPerDay.Month7 = Math.round(this.newElement.Month7/8.5);
            newElementPerDay.Month8 = Math.round(this.newElement.Month8/8.5);
            newElementPerDay.Month9 = Math.round(this.newElement.Month9/8.5);
            newElementPerDay.Month10 = Math.round(this.newElement.Month10/8.5);
            newElementPerDay.Month11 = Math.round(this.newElement.Month11/8.5);
            newElementPerDay.Month12 = Math.round(this.newElement.Month12/8.5);
            newElementPerDay.Month13= Math.round(this.newElement.Month13/8.5);
            this.capacityListPlanning.splice(this.arrayStart, 0, newElementPerDay);
            
        }
    
    }
    });
   
}

onOUSort(event)
{
    if (this.gpn=="" || this.gpn==undefined)
    {
        this.gpn= null;
    }
    if (this.ou=="" || this.ou==undefined)
    {
    this.ou= null;
    }
    this.capacityPlanningService.getSortPlanning(event,this.gpn,this.ou)
    .subscribe(capacityplanning => {
        this.capacityListPlanning = capacityplanning.CapacityList;      
        //this.newCapacityListPlanning = capacityplanning.CapacityList;
        this.headers = capacityplanning.headers;
        this.capacityDetailListPlanning = this.capacityListPlanning[0].CapacityDetailsList;
        
        for (let item of this.capacityListPlanning) {
            item.Month0 = item.CapacityDetailsList[0] != null ? item.CapacityDetailsList[0].Value : null;
            item.Month1 = item.CapacityDetailsList[1] != null ? item.CapacityDetailsList[1].Value : null;
            item.Month2 = item.CapacityDetailsList[2] != null ? item.CapacityDetailsList[2].Value : null;
            item.Month3 = item.CapacityDetailsList[3] != null ? item.CapacityDetailsList[3].Value : null;
            item.Month4 = item.CapacityDetailsList[4] != null ? item.CapacityDetailsList[4].Value : null;
            item.Month5 = item.CapacityDetailsList[5] != null ? item.CapacityDetailsList[5].Value : null;
            item.Month6 = item.CapacityDetailsList[6] != null ? item.CapacityDetailsList[6].Value : null;
            item.Month7 = item.CapacityDetailsList[7] != null ? item.CapacityDetailsList[7].Value : null;
            item.Month8 = item.CapacityDetailsList[8] != null ? item.CapacityDetailsList[8].Value : null;
            item.Month9 = item.CapacityDetailsList[9] != null ? item.CapacityDetailsList[9].Value : null;
            item.Month10 = item.CapacityDetailsList[10] != null ? item.CapacityDetailsList[10].Value : null;
            item.Month11 = item.CapacityDetailsList[11] != null ? item.CapacityDetailsList[11].Value : null;
            item.Month12 = item.CapacityDetailsList[12] != null ? item.CapacityDetailsList[12].Value : null;
            item.Month13 = item.CapacityDetailsList[13] != null ? item.CapacityDetailsList[13].Value : null;
        }
        this.totalRows=Math.floor(this.capacityListPlanning.length/this.numberOfRows );
        var count = 0;
        for(var i=0; i<this.totalRows; i++)
        {
            this.arrayStart = i*this.numberOfRows;  
            this.newElement = this.CreateNewElement();
            this.capacityListPlanning.splice(this.arrayStart, 0, this.newElement);
            var newElementPerDay = new CapacityPlanning();
            newElementPerDay.Month0 = Math.round(this.newElement.Month0/8.5);
            newElementPerDay.Month1 = Math.round(this.newElement.Month1/8.5);
            newElementPerDay.Month2 = Math.round(this.newElement.Month2/8.5);
            newElementPerDay.Month3 = Math.round(this.newElement.Month3/8.5);
            newElementPerDay.Month4 = Math.round(this.newElement.Month4/8.5);
            newElementPerDay.Month5 = Math.round(this.newElement.Month5/8.5);
            newElementPerDay.Month6 = Math.round(this.newElement.Month6/8.5);
            newElementPerDay.Month7 = Math.round(this.newElement.Month7/8.5);
            newElementPerDay.Month8 = Math.round(this.newElement.Month8/8.5);
            newElementPerDay.Month9 = Math.round(this.newElement.Month9/8.5);
            newElementPerDay.Month10 = Math.round(this.newElement.Month10/8.5);
            newElementPerDay.Month11 = Math.round(this.newElement.Month11/8.5);
            newElementPerDay.Month12 = Math.round(this.newElement.Month12/8.5);
            newElementPerDay.Month13= Math.round(this.newElement.Month13/8.5);
            this.capacityListPlanning.splice(this.arrayStart, 0, newElementPerDay);
            count++;                 
        }
        this.arrayStart = count == 0? 0: count *this.numberOfRows + 1;
        if(this.capacityListPlanning.length - this.totalRows % this.numberOfRows != 0)
        {
            //this.newElement = new CapacityPlanning();
            this.newElement = this.CreateNewElement() ;
            this.capacityListPlanning.splice(this.arrayStart, 0, this.newElement);
            var newElementPerDay = new CapacityPlanning();
            newElementPerDay.Month0 = Math.round(this.newElement.Month0/8.5);
            newElementPerDay.Month1 = Math.round(this.newElement.Month1/8.5);
            newElementPerDay.Month2 = Math.round(this.newElement.Month2/8.5);
            newElementPerDay.Month3 = Math.round(this.newElement.Month3/8.5);
            newElementPerDay.Month4 = Math.round(this.newElement.Month4/8.5);
            newElementPerDay.Month5 = Math.round(this.newElement.Month5/8.5);
            newElementPerDay.Month6 = Math.round(this.newElement.Month6/8.5);
            newElementPerDay.Month7 = Math.round(this.newElement.Month7/8.5);
            newElementPerDay.Month8 = Math.round(this.newElement.Month8/8.5);
            newElementPerDay.Month9 = Math.round(this.newElement.Month9/8.5);
            newElementPerDay.Month10 = Math.round(this.newElement.Month10/8.5);
            newElementPerDay.Month11 = Math.round(this.newElement.Month11/8.5);
            newElementPerDay.Month12 = Math.round(this.newElement.Month12/8.5);
            newElementPerDay.Month13= Math.round(this.newElement.Month13/8.5);
            this.capacityListPlanning.splice(this.arrayStart, 0, newElementPerDay);
            
        }
    
    });
}
    exportRecord() {
        if(this.capacityListPlanning.length ==0)
        {
            this.msgs = [];
            this.msgs.push({severity:'error', detail:'No records to export.'});
        }
      else{
        var link = document.createElement('a');
        this.capacityPlanningService.getExport(this.gpn,this.ou)
            .subscribe(blob => {
                link.href = window.URL.createObjectURL(blob);
                //var fileBlob = new Blob([returnedJSON.data], {type: 'application/pdf'});
                if (navigator.appVersion.toString().indexOf('.NET') > 0) { // for IE browser
                   // window.navigator.msSaveBlob(blob, "CMR_Export_OverviewPage.xlsx");
                    window.navigator.msSaveOrOpenBlob(blob, "CMR_Export_CapacityPlanningPage.xlsx"); 
                } else { // for other browsers
                    link.href = window.URL.createObjectURL(blob);
                    this.timestamp = new Date(Date.now())
                    link.download = "CMR_Export_CapacityPlanningPage" + this.timestamp.toString() + ".xlsx";
                    link.click();
                }
            })
    }
    }
 }





