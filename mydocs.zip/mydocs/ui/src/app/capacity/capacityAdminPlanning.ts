import { TimeUnit } from "ngx-bootstrap/chronos/types";

export class CapacityAdminPlanning
{
    CapacityList: CapacityPlanning[];
    headers: string[];
   
}
export class CapacityPlanning
{   Id:number;
    LastName: string;
    FirstName:string;
    GPN:string;
    OU:string;
    Pensum :number;
    IsActive:boolean;
    Name: string;
    CapacityDetailsList : CapacityDetailsPlanning[];
    Month0 : number;
    Month1 : number;
    Month2 : number;
    Month3 : number;
    Month4 : number;
    Month5 : number;
    Month6 : number;
    Month7 : number;
    Month8 : number;
    Month9 : number;
    Month10 : number;
    Month11 : number;
    Month12 : number;
    Month13: number;   
    isEnable : boolean = true; 
    isSelected : boolean = false;
    CreateBy : string;
    CreateDate : Date;
    // dict1: any[];
    // dict2:any[];
    // dict3:any[];
    // dict4:any[];
 }
 export class CapacityDetailsPlanning
 {
     Id:number;
     CapacityId: number;
     Month: string;
     Value: number;
     Sequence: number;    
     DynamicColumnName : string; 
 }
