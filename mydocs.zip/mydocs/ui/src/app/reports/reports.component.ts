import{Component} from '@angular/core'
@Component({
selector : 'pm-reports',
templateUrl : './reports.component.html'
})
export class ReportComponent
{
}