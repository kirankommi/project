import { TimeUnit } from "ngx-bootstrap/chronos/types";

export class capturing
{
    CategoryList : CategoryList[];
    SegmentList : SegmentList[];
    EntityList: EntityList[];
}

export class EntityList{

}

export class CategoryList
{
    Id:number;
    Name:string;
    Description: string;
    CREATED_DATE: Date;
    CREATED_BY: string;
    LAST_UPDATED_DATE: Date;
    LAST_UPDATED_BY: string;
    IS_ACTIVE: boolean;
    Parent_Category_ID: string;
    Display_Order: string;
    No_Of_Cases:boolean;
}

export class Timesheets
{
    Id: number;
    CategoryId:number;
    Title: string;
    GPN: string;
    OU: string;
    NoOfCases: number;    
    TimesheetDate: Date;
    TimeFrom: string;
    TimeTo: string;
    TimeSheetParameterId: number;
    Duration: number;
    Segments: number[] = [];
    CreatedDate : Date;
    SavedBy :string;
    LastUpdatedDate : Date;
    LastModifiedBy :string;
    gpnDetails: GpnDetails;
    TimesheetRecurrence: TimesheetRecurrence;
    IsRecurrenceDisabled:boolean = false;
}

export class GpnDetails {
    EmployeePk  :string;
    BusinessName  :string;
    EmailAddress  :string;
    OuCode  :string;
    OuDesc  :string;
 }

export class SelectedSegemtns{
    Id:number;
}

export class SegmentList
{
    Id:number;
    SEGMENT_CODE:string;
    DESCRIPTION:string;
    checked:boolean = false;
}

export class SelectedCategory
{
    Id:number;
    Name:string;
    Description: string;
    No_Of_Cases:boolean;

}

export class TimesheetRecurrence
{
    Id:number = null;
    StartTime: string = '';
    EndTime: string;
    Duration: number;
    StartDate: Date;
    EndBy: Date = null;
    NoEndDate : boolean = false;
    NumOccurences: number = null;
    RecurrenceType:number;
    Int1:number;
    Int2:number;
    Int3:number;
    IntYears:number;
    String1:string;
 
}