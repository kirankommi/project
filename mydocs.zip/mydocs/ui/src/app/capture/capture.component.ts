import { Component, OnInit, Input, Directive, ViewChild} from '@angular/core';
import { CapturingService } from './capture.service';
import { capturing, CategoryList,Timesheets,SegmentList,SelectedCategory,SelectedSegemtns,GpnDetails,TimesheetRecurrence } from './capture.modal'
import { ActivatedRoute, Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { AutoComplete } from "primeng/components/autocomplete/autocomplete";
import {Validators,FormControl,FormGroup,FormBuilder} from '@angular/forms';
import {Message} from 'primeng/primeng';
import { overview, GPNOverview } from '../overview/overview';
import { OverviewService } from '../overview/overview.service';
import { AbstractControl } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
const MAX_LENGTH = 10;

@Component({
selector : 'pm-capture',
templateUrl : './capture.component.html'
})
export class CaptureComponent 
{ 
  Recurrence: TimesheetRecurrence = new TimesheetRecurrence();
  displayRecurrence: boolean = false;
  languageId:number;
  userform: FormGroup;
  recform: FormGroup;
  charactercount:number;
  disabled:boolean = false;
  recurrenceDisabled:boolean = false;
  categorydisableflag:boolean=false;
  isNo_of_Cases:boolean=false;
  capturing: capturing = new capturing();    
  timesheets: Timesheets = new Timesheets();  
  categories : CategoryList[]=[];
  tempcategories : CategoryList[]=[];
  segments : SegmentList[];
  timesheet : Timesheets[];
  statictext:string = "";
  selectedCategory: SelectedCategory = new SelectedCategory();
  selectedSegments: number[] = [];
  timesheetId:number;  
  GPNValue :string;
  SelectedGPNValue: string;
  displayGPN: boolean = false;
  overview: overview = new overview();
  GPNOverview: GPNOverview = new GPNOverview();
  gpnDetails: GpnDetails[];
  timeFromHr:string;
  timeFromMn:string;
  timeToHr:string;
  timeToMn:string;
  cancelDisplay:boolean=false;
  saveDisplay:boolean=true;
  copyNewDisplay:boolean=false;
  uploadDisplay:boolean = false;
  displayInfo:boolean= false;
  SelectedGPNName: string;
  SelectedGPNOuDesc : string;
  timeChecked: boolean = true;
  durationChecked:boolean= false;
  infotext:string='';
  infoDisplay:boolean =  false;
  isDataSaved:boolean=false;
  msgs: Message[] = [];
  showDaily: boolean = true;
  showWeekly: boolean = false;
  showMonthly: boolean = false;
  radioFrom: string = 'radioFrom';
  displayProgressbar:boolean = true;
  daily1: number;
  weekly1: number;
  day: string;
  monthly1: number;
  monthly2: number;
  monthly3: number;
  monthly4: number;
  monthly5: number;
  timeFromrecHr: string;
  timeFromrecMn: string;
  timeTorecHr: string;
  timeTorecMn: string;
  recvalue : number = 365;
  endAfterChecked:boolean = false;
  endByChecked:boolean = false;
  recMsgs: Message[] = [];
  isDailyChecked : boolean = true;
  isWeeklyChecked: boolean = false;
  isMonthlyChecked: boolean = false;
  SelGPNName: string;
  SelGPNOU: string;
  SelGPNOuDesc: string;
  constructor(private fb: FormBuilder,
              private route: ActivatedRoute,
              private router: Router,
              private capturingService:CapturingService,
              private overviewService: OverviewService,
              public datepipe:DatePipe) {}

  ngOnInit() {
    this.displayProgressbar = true;
    this.uploadDisplay = sessionStorage.getItem('Role') === "ADMIN" ? true : false;
    this.languageId = parseInt(sessionStorage.getItem('LanguageId')); 
    this.timesheets.GPN = sessionStorage.getItem('GPN');
    this.SelectedGPNName = sessionStorage.getItem('UserName');
    this.timesheets.OU = sessionStorage.getItem('ouCode');
    this.SelectedGPNOuDesc = sessionStorage.getItem('ouDesc');
    this.selectedCategory.Id = 0;
    this.timesheets.TimesheetDate = new Date();
    this.timesheets.NoOfCases = 1;   
    
    if(this.selectedCategory.No_Of_Cases==false){
      this.isNo_of_Cases=true;
    }

   

    this.userform = this.fb.group({
      'category': new FormControl('', Validators.required),
      'title': new FormControl('', Validators.maxLength(100)),
      'radioFrom': new FormControl(''),
      'radioDuration': new FormControl(''),
      'timeFrom': new FormControl(''),
      'timeTo': new FormControl(''),
      'gpn': new FormControl('', Validators.required),  
      'date': new FormControl('', Validators.required), 
      'segment': new FormControl(''),
      'duration': new FormControl('', Validators.compose([this.ValidateDuration,Validators.required])),
      'cases': new FormControl('', this.ValidateCases.bind(this)), 
      'allSegments': new FormControl(''),
      'noSegment': new FormControl(''),   
    });
    this.recform = this.fb.group({
      'recStartTime': new FormControl('', Validators.pattern('([01]?[0-9]|2[0-3]):[0-5][0-9]')),
      'recEndTime': new FormControl('', Validators.pattern('([01]?[0-9]|2[0-3]):[0-5][0-9]')),
      'recDuration':new FormControl('', Validators.compose([this.ValidateDuration,Validators.required])),
      'NumOccurences':new FormControl('', Validators.compose([this.ValidateOccurences.bind(this),Validators.min(1)])),
      'recStartDate':new FormControl('', Validators.required),
      'Int1': new FormControl('', Validators.min(1)),
      'Int11': new FormControl('', Validators.min(1)),
      'Int13': new FormControl('', Validators.min(1)),
      'Int21': new FormControl('', Validators.min(1)),
      'Int22': new FormControl('', Validators.min(1)),
      'EndBy': new FormControl('', this.ValidateEndBy.bind(this)),
    });


    this.route
      .queryParams
      .subscribe(params => {
        this.timesheetId = +params['Id'] || 0;
        this.recurrenceDisabled = params['EnableRecurrence'] == "false"? true:false;
      });

    if(this.timesheetId === 0) {
      this.timesheets.GPN = sessionStorage.getItem('GPN');
      this.SelectedGPNName = sessionStorage.getItem('UserName');
      this.timesheets.OU = sessionStorage.getItem('ouCode');
      this.SelectedGPNOuDesc = sessionStorage.getItem('ouDesc');
      this.selectedCategory.Id = 0;
      this.timesheets.TimesheetDate =   new Date();
      this.timesheets.NoOfCases = 1;
 
      //recurrence
      this.daily1 = 1;
      this.weekly1 = 1;
      this.monthly1 = 12;
      this.monthly2 = 1;
      this.monthly3 = 2;
      this.monthly4 = 6;
      this.monthly5 = 1;
      this.Recurrence.RecurrenceType = 10;
      this.endAfterChecked = true;
    }

    this.capturingService.getAdditionaltext().subscribe(		
      response=>{this.statictext=response.substring(0,500)		
      if(response.length>500)
      {
        this.infoDisplay=true
      }}
    );

    //get categories and segments
     this.capturingService.getCapturing(this.languageId)
     .subscribe(capturing => {     

              if(this.timesheetId == 0){
                for (let category of capturing.CategoryList) {
                  if(category.IS_ACTIVE==true)
                  { 
                      this.categories.push(category)
                  }
              }
              }


             this.segments = capturing.SegmentList;

             //get timesheet by id for edit
             if(this.timesheetId !== 0) {
              this.capturingService.getTimesheet(this.timesheetId)
              .subscribe(timesheet => {
                    this.displayProgressbar = false;
                    this.cancelDisplay=true;
					          //this.userform.controls['segment'].disable();
                    //this.userform.controls['allSegments'].disable();
                    //this.userform.controls['noSegment'].disable();
                    this.timesheets.Id = timesheet.Id;
                    this.timesheets.CategoryId = timesheet.CategoryId;
                    this.timesheets.Title = timesheet.Title; 
                    this.timesheets.TimesheetDate = new Date(timesheet.TimesheetDate);
                    this.timesheets.TimeFrom = timesheet.TimeFrom === '00:00' ? null : timesheet.TimeFrom;
                    this.timesheets.TimeTo = timesheet.TimeTo === '00:00' ? null : timesheet.TimeTo;
                    this.timesheets.Duration = timesheet.Duration === 0 ? null : timesheet.Duration;
                    this.timesheets.GPN = timesheet.GPN;
                    this.timesheets.OU = timesheet.OU;
                    this.timesheets.NoOfCases = timesheet.NoOfCases;
                    this.timesheets.TimeSheetParameterId = timesheet.TimeSheetParameterId;
                    this.selectedCategory.Id = timesheet.CategoryId;
                    this.selectedSegments = timesheet.Segments;
                    this.timesheets.SavedBy = timesheet.SavedBy;
                    this.timesheets.CreatedDate = timesheet.CreatedDate;
                    this.timesheets.LastModifiedBy = timesheet.LastModifiedBy;
                    this.timesheets.LastUpdatedDate = timesheet.LastUpdatedDate; 
                    this.timesheets.OU = timesheet.gpnDetails.OuCode;
                    this.SelectedGPNName = timesheet.gpnDetails.BusinessName;
                    this.SelectedGPNOuDesc = timesheet.gpnDetails.OuDesc;

                    if(timesheet.TimesheetRecurrence !== null){
                      this.Recurrence = timesheet.TimesheetRecurrence;
                      this.timesheets.TimesheetRecurrence = timesheet.TimesheetRecurrence;
                    }
                    
                    for (let category of capturing.CategoryList) {
                      if(category.IS_ACTIVE==true)
                      { 
                          console.log(category.Id)
                          this.categories.push(category)
                      }
                      if(category.IS_ACTIVE==false && (category.Id == timesheet.CategoryId))
                      {
                        console.log(category.Id)
                          this.categories.push(category)
                      }
                   }

                    //selected segments of timesheet
                    if(timesheet.Segments != undefined && this.segments != undefined) {
                      for (let segment of this.segments) {
                        for(let selectedSegment of timesheet.Segments){
                          {
                            if(selectedSegment ===  segment.Id)
                              segment.checked = true;
                          }
                        }
                      }
                    }
  
                    //Set Category
                    if(timesheet.CategoryId != undefined) {
                      for (let category of this.categories) {
                        if(category.Id == timesheet.CategoryId) {
                         
                            if(category.LAST_UPDATED_DATE < timesheet.TimesheetDate && !category.IS_ACTIVE  )
                            {
                              this.selectedCategory.Id=0;
                            }
                            else if(category.LAST_UPDATED_DATE > timesheet.TimesheetDate && !category.IS_ACTIVE){
                              
                               this.selectedCategory.Id=timesheet.CategoryId;
                               this.selectedCategory.Name = category.Name;
                              this.selectedCategory.Description = category.Description;
                              this.categorydisableflag=true;
                            }
                            else{
                              this.selectedCategory.Name = category.Name;
                              this.selectedCategory.Description = category.Description;
                            }
                        }
                      }
                    }

                    if (this.Recurrence != undefined) {
                      if (this.Recurrence.RecurrenceType == 10) {
                        this.daily1 = this.Recurrence.Int1;
                      }
                      else if (this.Recurrence.RecurrenceType == 20) {
                        this.weekly1 =this.Recurrence.Int1;
                        this.day = this.Recurrence.String1;
                      }
                      else if (this.Recurrence.RecurrenceType == 30) {
                        this.monthly1 = this.Recurrence.Int1;
                        this.monthly2 = this.Recurrence.Int2;
                      }
                      else if (this.Recurrence.RecurrenceType == 31) {
                        this.monthly3 = this.Recurrence.Int1;
                        this.monthly4 = this.Recurrence.Int2;
                        this.monthly5 = this.Recurrence.Int3 ;
                      }
                    }

                    this.userform.patchValue({category:this.selectedCategory});
              });             
             }
             else{
              this.displayProgressbar = false; 
             }  
     });
      
  }

  checkTime(controlTime) : boolean
  {
    var str = controlTime; 
    var res = str.match(/^([0-1][0-9]|[2][0-3]):([0-5][0-9])+$/);
    if(res !== null)
      return true
    else
      return false
  }

  textChanged($event) {       
    this.charactercount=$event.textValue.length;
    if(this.charactercount>500)
    {
      this.infoDisplay=true
    }  
  }  

  ValidateCases(control: FormControl) {
    if(control.value === null || control.value === '' || control.value === undefined){
      return null;
    }
    else{
      return (parseInt(control.value) < 10000 && parseInt(control.value) > 0) ? null : {
        ValidateCases: true}
    }
  }

  ValidateCategory(control: FormControl) {
      return (control.value !== 0) ? null : {
        ValidateCategory: true
      }
  }

  ValidateDuration(control: FormControl) { 
    if(control.value !== null && control.value !== '' && control.value !== undefined)
    {
      return (parseInt(control.value) <= 720 && parseInt(control.value) > 1) ? null : 
      {
        ValidateDuration: true
      }
    }
  }

  calcDuration() {
    if(this.timesheets.TimeFrom !== '' && this.timesheets.TimeTo !== '' 
      && this.timesheets.TimeFrom !== undefined && this.timesheets.TimeTo !== undefined)
    {
      if(this.timesheets.TimeFrom.length > 0 && this.timesheets.TimeTo.length > 0)
      {
        this.timeFromHr = this.timesheets.TimeFrom.toString().slice(0,2);
        this.timeFromMn = this.timesheets.TimeFrom.toString().slice(3,5);
        this.timeToHr = this.timesheets.TimeTo.toString().slice(0,2);
        this.timeToMn = this.timesheets.TimeTo.toString().slice(3,5);
        this.timesheets.Duration = ((parseInt(this.timeToHr) - parseInt(this.timeFromHr)) * 60) + (parseInt(this.timeToMn) - parseInt(this.timeFromMn))
        
      }
    }
  }

  calcrecDuration() {
    if (this.Recurrence.StartTime !== null && this.Recurrence.EndTime !== null 
    &&  this.Recurrence.StartTime !== '' && this.Recurrence.EndTime !== '' 
    && this.Recurrence.StartTime !== undefined && this.Recurrence.EndTime !== undefined) {
      if (this.Recurrence.StartTime.length > 0 && this.Recurrence.EndTime.length > 0) {
        this.timeFromrecHr = this.Recurrence.StartTime.toString().slice(0, 2);
        this.timeFromrecMn = this.Recurrence.StartTime.toString().slice(3, 5);
        this.timeTorecHr = this.Recurrence.EndTime.toString().slice(0, 2);
        this.timeTorecMn = this.Recurrence.EndTime.toString().slice(3, 5);
        this.Recurrence.Duration = ((parseInt(this.timeTorecHr) - parseInt(this.timeFromrecHr)) * 60) + (parseInt(this.timeTorecMn) - parseInt(this.timeFromrecMn))
      }
    }
  }
 
  ValidateOccurences(control: FormControl) {
    if (control.value === null || control.value === '' || control.value === undefined) {
      return null;
    }
    else {
      return (parseInt(control.value) <= this.recvalue ) ? null : {
        ValidateOccurences: true
      }
    }
  }

  ValidateEndBy(control: FormControl) {
    if(this.Recurrence.StartDate === null || this.Recurrence.StartDate === undefined ||
      control.value === null || control.value === '' || control.value === undefined){
      return null;
    }
    else
    {
      return (control.value >= this.Recurrence.StartDate) ? null : {
        ValidateEndBy: true
      }
    }
  }

  checkTimeOption(event) {
    if(event.target.id === 'timeFrom' || event.target.id === 'timeTo'){
      this.durationChecked = false;
      this.radioFrom = 'radioFrom';
    }
    else if(event.target.id === 'duration') {
      this.radioFrom = 'radioDuration';
      this.durationChecked = true;
    } 
  }

  checkEndOption(event) {
    if (event.target.id === 'NumOccurences') {
      this.endAfterChecked = true;
      this.endByChecked = false;
      this.Recurrence.EndBy = null;
    }
    else if (event.target.id === 'EndBy') {
      this.endAfterChecked = false;
      this.endByChecked = true;      
    }
  }

  searchCategory(event) {
    //this.categories = this.categories.filter(v => v.Name.toLowerCase().indexOf(event.query) > -1)
    this.tempcategories = [];
    this.capturingService.getCapturing(this.languageId).subscribe(capturing => {
      if(this.timesheetId == 0){
        for (let category of capturing.CategoryList) {
          if(category.IS_ACTIVE==true)
          { 
              this.tempcategories.push(category)
          }
        }
      }
      else if (this.timesheetId !== 0)
      {
        for (let category of capturing.CategoryList) {
            if(category.IS_ACTIVE==true)
            { 
                this.tempcategories.push(category)
            }
            if(category.IS_ACTIVE==false && (category.Id == this.selectedCategory.Id))
            {
              this.tempcategories.push(category)
            }
        }
      }

      this.categories = this.tempcategories.filter(v => v.Name.toLowerCase().indexOf(event.query.toLowerCase()) > -1)
    });
  }


  save(){
    this.msgs = [];  
    if(this.timesheets.TimeFrom !== null && this.timesheets.TimeFrom !== undefined &&
    this.timesheets.TimeFrom !== '' && !this.checkTime(this.timesheets.TimeFrom))  
    {      
        this.msgs.push({severity:'error',detail:'From Time should be in HH:MM format'});
    }
    else if(this.timesheets.TimeTo !== null && this.timesheets.TimeTo !== undefined &&
    this.timesheets.TimeTo !== '' && !this.checkTime(this.timesheets.TimeTo)) 
    {      
        this.msgs.push({severity:'error',detail:'To Time should be in HH:MM format'});
    }
    else if(this.selectedCategory.Id === 0 || this.selectedCategory.Id === undefined) {
      //validate category
      this.userform.controls['category'].setErrors({'incorrect': true});
    }
    else if(this.selectedSegments.length === 0 && !this.userform.controls['noSegment'].value) 
    {
      this.msgs.push({severity:'error',detail:'Please select atleast one segment'});
    }
    else if(this.timesheets.GPN !== null && this.timesheets.GPN !== '' && this.timesheets.GPN !== undefined){
      //validate GPN
      this.GPNOverview.SearchGPN = this.timesheets.GPN; 
      this.overviewService.getSearchGPNData(this.GPNOverview)
        .subscribe(overview => { this.gpnDetails = overview 
        
          if(this.gpnDetails.length === null || this.gpnDetails.length === 0) 
          {
            this.msgs.push({severity:'error',detail:'GPN is invalid'});
            this.disabled = false;
            this.recurrenceDisabled = false;
            this.copyNewDisplay = false;
            return;
          }
          else {
            this.SelectedGPNName = this.gpnDetails[0].BusinessName;
            this.timesheets.OU = this.gpnDetails[0].OuCode;
            this.SelectedGPNOuDesc = this.gpnDetails[0].OuDesc;
          }

          if (this.userform.valid) {
            //save or update timesheet
            this.timesheets.CategoryId = this.selectedCategory.Id;
            this.timesheets.Segments = this.selectedSegments;      
            this.timesheets.IsRecurrenceDisabled = this.recurrenceDisabled;      
            this.timesheets.TimesheetDate = new Date(this.datepipe.transform(this.timesheets.TimesheetDate,'yyyy-MM-dd')) 
            this.capturingService.saveTimesheet(this.timesheets).subscribe(
              suc => {
                  if(suc === 'Entry saved successfully') {
                    this.msgs.push({severity:'success',detail:'Entry saved successfully'});
                    this.copyNewDisplay = true;
                    this.saveDisplay = false;
                    this.isDataSaved=true;
                    this.disabled = true;
                    this.recurrenceDisabled = true;
                  }
                  else if(suc === 'Entry Updated successfully') {
                    this.msgs.push({severity:'success',detail:'Entry updated successfully'});
                    this.copyNewDisplay = true;
                    this.saveDisplay = false;
                    this.isDataSaved=true;
                    this.disabled = true;
                    this.recurrenceDisabled = true;
                  }
                  else if(suc === 'This entry was edited in the meantime') {
                    this.msgs.push({severity:'error',detail:'This entry was edited in the meantime'});
                    this.disabled = true;
                    this.recurrenceDisabled = true;
                    this.copyNewDisplay = false;
                    this.saveDisplay = false;
                  }
                  else if(suc=="Timesheet does not Exist")
                  {
                    this.msgs.push({severity:'error',detail:'Timesheet does not Exist'}); 
                    this.copyNewDisplay = false;
                    this.saveDisplay = false;
                    this.disabled = false; 
                    this.recurrenceDisabled = false;                   
                  }
                  console.log(suc);
              },
              err => {
                  this.msgs.push({severity:'error',detail:err}); 
                  this.disabled = false;           
                  this.copyNewDisplay = false;
                  this.saveDisplay = true;
                  this.recurrenceDisabled = false;
                  console.log(err);
              }
            );
          }
          else {
              this.msgs.push({severity:'error',detail:'Please fill the mandatory fields'});
              this.disabled = false;
              this.saveDisplay = true;
              this.copyNewDisplay = false;
              this.recurrenceDisabled = false;
          }
        });
    }
    else {
        this.msgs.push({severity:'error',detail:'Please fill GPN'});       
    }
  }

  newEntry() 
  {
    this.msgs = [];
    this.timesheets.GPN = sessionStorage.getItem('GPN');
    this.SelectedGPNName = sessionStorage.getItem('UserName');
    this.timesheets.OU = sessionStorage.getItem('ouCode');
    this.SelectedGPNOuDesc = sessionStorage.getItem('ouDesc');
    //this.timesheets.CategoryId = 0;
    this.selectedCategory.Id = 0;
    this.selectedCategory.Name = null;
    this.selectedCategory.Description = null;
    this.userform.patchValue({category:this.selectedCategory})
    this.timesheets.TimesheetDate =   new Date();
    this.timesheets.NoOfCases = 1;
    this.timesheets.Id = 0;    
    this.timesheets.TimeFrom = null;
    this.timesheets.TimeTo = null;
    this.timesheets.Duration = null;
    this.timesheets.Title = null; 
    this.clearSegments();
    this.disabled = false;
    this.recurrenceDisabled = false;
    this.saveDisplay = true;
    this.copyNewDisplay = false;
    this.userform.markAsPristine();
    this.userform.markAsUntouched();
    this.userform.updateValueAndValidity();    
  }

  copyAndNew() 
  {
    this.msgs = [];
    this.timesheets.Id = 0;
    this.disabled = false;
    this.recurrenceDisabled = false;
    this.saveDisplay = true;
  }

  
  additionalInfo() 
  {
    var myWindow = window.open("/infobox", "", "width=600,height=460");
  }
  
 
  selectAllSegments(event) {
      this.userform.controls['segment'].enable();
      for (let segment of this.segments) 
      {
        var alreadyChecked:boolean = false;
        for(let selectedSegment of this.selectedSegments) 
        {
          {
            if(selectedSegment ===  segment.Id) 
            {
              alreadyChecked = true;
              break;              
            }
          }
        }
        if(event.target.checked && !alreadyChecked)
        {
          segment.checked = true;
          this.selectedSegments.push(segment.Id);
        }
        else if(!event.target.checked && alreadyChecked)
        {
          segment.checked = false;
          this.selectedSegments.splice(this.selectedSegments.indexOf(segment.Id), 1);
        }
      }
      if(event.target.checked) 
      {
        this.userform.patchValue({segment:true});
      }
      else if(!event.target.checked) 
      {
        this.userform.patchValue({segment:false});
      }
      this.userform.patchValue({noSegment:false});
  }

  unSelectAllSegments(event) 
  {
    if(event.target.checked)
    {
      for (let segment of this.segments) 
      {
        var alreadyChecked:boolean = false;
        for(let selectedSegment of this.selectedSegments)
        {
          {
            if(selectedSegment ===  segment.Id) 
            {
              alreadyChecked = true;
              break;              
            }
          }
        }
        if(alreadyChecked)
        {
          segment.checked = false;
          this.selectedSegments.splice(this.selectedSegments.indexOf(segment.Id), 1);
        }
      }
      this.userform.patchValue({segment:false});
      this.userform.controls['segment'].disable();
      this.userform.patchValue({allSegments:false});
    }
    else if(!event.target.checked)
    {
      this.userform.controls['segment'].enable();
    }
  }

  clearSegments()
  {
    for (let segment of this.segments) 
    {
      var alreadyChecked:boolean = false;
      for(let selectedSegment of this.selectedSegments){
        {
          if(selectedSegment ===  segment.Id) {
            alreadyChecked = true;
            break;              
          }
        }
      }
      if(alreadyChecked){
        this.selectedSegments.splice(this.selectedSegments.indexOf(segment.Id), 1);
        segment.checked = false;
      }
    }

    this.userform.patchValue({allSegments:false});
    this.userform.patchValue({noSegment:false});
    this.userform.patchValue({segment:false});
    this.userform.controls['segment'].enable();
  }


  segmentChange(event,id: any){

    var alreadyexists:boolean = false;
    for (let selectedSegment of this.selectedSegments) {
        if(selectedSegment == id){          
          alreadyexists = true;
        }
      }

    if(event.target.checked && !alreadyexists){
      this.selectedSegments.push(id);
    }

    if(!event.target.checked && alreadyexists){
      this.selectedSegments.splice(this.selectedSegments.indexOf(id), 1);
    }
  }

  cancel()
  {
    this.router.navigate(['overview/'], { queryParams: { saveFlag: this.isDataSaved, cancelFlag: 'true'}} );
  }

  searchGPN(){
    this.overviewService.getSearchGPNData(this.GPNOverview)
        .subscribe(overview => { this.overview.GPNSearchList = overview }
        );
    console.log(this.overview);
  }

  searchGPNReset(){
    this.GPNOverview.SearchLastName = null;
    this.GPNOverview.SearchFirstName = null;
    this.GPNOverview.SearchGPN = null;
    this.GPNOverview.SearchOUCode = null;
    this.GPNOverview.SearchUserID = null;
    this.GPNOverview.SearchTNumber = null;
    this.overview.GPNSearchList = null;
  }
  searchGpnOk(){
    this.timesheets.GPN =this.SelectedGPNValue;
    this.SelectedGPNName= this.SelGPNName;
    this.timesheets.OU = this.SelGPNOU;
    this.SelectedGPNOuDesc = this.SelGPNOuDesc;
    this.displayGPN = false;
  }

  showGPNDialog() {
    if(this.SelectedGPNValue != this.timesheets.GPN)
    {
      this.searchGPNReset();
    }
    this.displayGPN = true;
  }
  getGPNValue(GPN,Name,OuCode,OuDesc)
  {
      this.SelectedGPNValue= GPN;
      this.SelGPNName= Name;
      this.SelGPNOU = OuCode;
      this.SelGPNOuDesc = OuDesc;
  }
  RecurrenceOk() {
    if(this.Recurrence.EndBy == null && this.Recurrence.NumOccurences === null)
    {
      this.recMsgs = [];
      this.recMsgs.push({ severity: 'error', detail: 'Please select End after or End by' });
    }
    else if(this.Recurrence.RecurrenceType == 10 && (this.daily1 == null || this.daily1 == 0 || this.daily1 == undefined))
    {
      this.recMsgs = [];
      this.recMsgs.push({ severity: 'error', detail: 'The recurrence pattern is not valid.' });
    }
    else if(this.Recurrence.RecurrenceType == 20 && (this.weekly1 == null || this.weekly1 == 0 || this.weekly1 == undefined))
    {
      this.recMsgs = [];
      this.recMsgs.push({ severity: 'error', detail: 'The recurrence pattern is not valid.' });
    }
    else if(this.Recurrence.RecurrenceType == 30 && (this.monthly1 == null || this.monthly1 == 0 || this.monthly1 == undefined
            ||this.monthly2 == null || this.monthly2 == 0 || this.monthly2 == undefined))
    {
      this.recMsgs = [];
      this.recMsgs.push({ severity: 'error', detail: 'The recurrence pattern is not valid.' });
    }
    else if(this.Recurrence.RecurrenceType == 31 && (this.monthly5 == null || this.monthly5 == 0 || this.monthly5 == undefined))
    {
      this.recMsgs = [];
      this.recMsgs.push({ severity: 'error', detail: 'The recurrence pattern is not valid.' });
    }
    else if (this.recform.valid) 
    {       
      this.recMsgs = [];
      if (this.Recurrence.RecurrenceType == 10) {
        this.Recurrence.Int1 = this.daily1;
      }
      else if (this.Recurrence.RecurrenceType == 20) {
        this.Recurrence.Int1 = this.weekly1;
        this.Recurrence.String1 = this.day;
      }
      else if (this.Recurrence.RecurrenceType == 30) {
        this.Recurrence.Int1 = this.monthly1;
        this.Recurrence.Int2 = this.monthly2;
      }
      else if (this.Recurrence.RecurrenceType == 31) {
        this.Recurrence.Int1 = this.monthly3;
        this.Recurrence.Int2 = this.monthly4;
        this.Recurrence.Int3 = this.monthly5;
      }
      this.timesheets.TimeFrom = this.Recurrence.StartTime === null ? '' : this.Recurrence.StartTime;
      this.timesheets.TimeTo = this.Recurrence.EndTime;
      this.timesheets.Duration = this.Recurrence.Duration;
      this.timesheets.TimesheetRecurrence = this.Recurrence;
      this.displayRecurrence = false;
    }
    else {
      this.recMsgs = [];
      this.recMsgs.push({ severity: 'error', detail: 'Please fill the mandatory fields' });
      this.disabled = false;
      this.recurrenceDisabled = false;
      this.copyNewDisplay = false;
    }
  }
  OpenRecurrenceWindow() {
    this.displayRecurrence = true; 
    this.initializeRecurrence();    
  }
  initializeRecurrence()
  {
    this.Recurrence.StartTime = this.timesheets.TimeFrom;
    this.Recurrence.EndTime = this.timesheets.TimeTo;
    this.Recurrence.Duration = this.timesheets.Duration;
    if(this.timesheets.TimesheetRecurrence) 
    {
      this.Recurrence.RecurrenceType = this.timesheets.TimesheetRecurrence.RecurrenceType;    
      this.Recurrence.EndBy = this.timesheets.TimesheetRecurrence.EndBy  === null ? null : new Date(this.datepipe.transform(this.timesheets.TimesheetRecurrence.EndBy, 'yyyy-MM-dd')) ;
      this.Recurrence.StartDate = new Date(this.datepipe.transform(this.timesheets.TimesheetDate, 'yyyy-MM-dd'));
    
      if(this.Recurrence.RecurrenceType === 10)
      {
        this.isDailyChecked = true;
        this.showDaily = true;
        this.showWeekly = false;
        this.showMonthly = false;        
      }
      else if(this.Recurrence.RecurrenceType === 20 || this.Recurrence.RecurrenceType === 21)
      {
        this.isWeeklyChecked = true;
        this.showDaily = false;
        this.showWeekly = true;
        this.showMonthly = false;
      }
      else if(this.Recurrence.RecurrenceType === 30 || this.Recurrence.RecurrenceType === 31)
      {
        this.isMonthlyChecked = true;
        this.showDaily = false;
        this.showWeekly = false;
        this.showMonthly = true;
      }      
 
      if(this.Recurrence.NumOccurences)
      {
        this.endAfterChecked = true;
        this.endByChecked = false;
      }
      else if(this.Recurrence.EndBy)
      {
        this.endByChecked = true;
        this.endAfterChecked = false;
      }
    }  
  }
 
  show1() {
    this.showDaily = true;
    this.showWeekly = false;
    this.showMonthly = false;
    this.recvalue = 365;
    this.Recurrence.RecurrenceType = 10;
  }
  show2() {
    this.showWeekly = true;
    this.showDaily = false;
    this.showMonthly = false;
    //this.Recurrence.RecurrenceType = 20;
      this.day = 'Saturday';
    this.recvalue = 52;
  }
  show3() {
    this.showMonthly = true;
    this.showDaily = false;
    this.showWeekly = false;
    this.recvalue = 12;
      this.Recurrence.RecurrenceType = 30;
  }

}