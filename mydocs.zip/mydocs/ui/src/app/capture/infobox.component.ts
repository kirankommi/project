import { Component } from "@angular/core";
import { CapturingService } from "./capture.service";

@Component({
    selector : 'pm-capture',
    templateUrl :'infobox.component.html',
    
   // styleUrls: ['./capture.component.css']
    })

export class InfoboxComponent 
{ 

    statictext: any;
    constructor(
        private capturingService:CapturingService,
        ) {}

    ngOnInit() {
    this.capturingService.getAdditionaltext().subscribe(
        response=>this.statictext=response
       );
    }
}