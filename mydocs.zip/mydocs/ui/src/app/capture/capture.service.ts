import {HttpModule, Http,Response,RequestOptions} from '@angular/http';
import {Injectable} from '@angular/core';
import { capturing,CategoryList,Timesheets, EntityList } from './capture.modal'
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../environments/environment';

@Injectable()
export class CapturingService {
    //hostURL : string = "http://nzur467991dww.ubsprod.msad.ubs.net/CMRAPI/api/";
   // hostURL :string ="http://localhost:58349/api/";
    
   hostURL :string =environment.baseUrl;
   [x: string]: any;

    constructor(private http: Http) {}
    
    getCapturing(languageId : any) : Observable<capturing> {        
        return this.http.get(this.hostURL + 'Capturing/' + languageId)
        .map((res:Response)=> res.json() as capturing)
        .catch(this.handleError)
    }

    saveTimesheet(timesheet:Timesheets) {           
       return this.http.post(this.hostURL + 'Capturing/Save', timesheet)
       .map(res =>  res.json());     	    
    }

    getTimesheet(id : number) : Observable<Timesheets>  {        
        return this.http.get(this.hostURL + 'Capturing/Get/'+id)
        .map((res:Response)=> res.json() as Timesheets)
        .catch(this.handleError)
    }

    getAdditionaltext() {           
        let languageId=sessionStorage.getItem('LanguageId');
        return this.http.get(this.hostURL + 'infotext/GetTextInfoCapture/'+ languageId)
        .map(res =>  res.json());     	    
    }

    private handleError(error: Response) {
        return Observable.throw(error.statusText);
    }
 }