﻿import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { routing } from './app.routing';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/user/navbar.component';
import { OverviewComponent } from './overview/overview.component';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { OverviewService } from './overview/overview.service';
import { HttpModule } from '@angular/http';
import { DialogModule, ConfirmDialogModule, ConfirmationService, GrowlModule, FileUploadModule, TabViewModule } from 'primeng/primeng';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CaptureComponent } from "./capture/capture.component";
import { ReportComponent } from "./reports/reports.component";
import { ButtonModule } from "primeng/components/button/button";
import { DataTableModule } from "primeng/components/datatable/datatable";
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { ModalModule } from 'ngx-bootstrap/modal';
import { FormGroup, FormBuilder } from "@angular/forms";

import { PaginatorModule } from "primeng/components/paginator/paginator";
import { PanelModule } from "primeng/components/panel/panel";
import { CheckboxModule } from "primeng/components/checkbox/checkbox";
import { DatePipe } from '@angular/common'; 
import { CalendarModule } from 'primeng/components/calendar/calendar';
import { CapturingService } from './capture/capture.service';
import { CapacityPlanningComponent } from './capacity/capacity.component';
import { NavbarService } from './navbar/user/navbar.service';
import { AutoCompleteModule } from "primeng/components/autocomplete/autocomplete";
import { AlertModule } from 'ngx-bootstrap/alert';  
import { RadioButtonModule} from 'primeng/components/radiobutton/radiobutton';
import { MessagesModule } from 'primeng/components/messages/messages';
import { MessageModule } from 'primeng/components/message/message';
import { CapacityAdminComponent } from './Admin/capacityAdmin/capacityAdmin.component';
import { InfoTextComponent } from './Admin/infotext/infotext.component';
import { EditorModule } from 'primeng/components/editor/editor';
import { TabMenuModule } from 'primeng/components/tabmenu/tabmenu';
import { InfoTextService } from './Admin/infotext/infotext.service';
import { CapacityAdminService } from './Admin/capacityAdmin/capacityAdmin.service';
import { SegmentComponent } from './Admin/segment/segment.component';
import { SegmentService } from './Admin/segment/segment.service';
import { OrderListModule } from 'primeng/components/orderlist/orderlist';
import { MenuModule} from 'primeng/components/menu/menu';
import { MenuItem } from 'primeng/components/common/menuitem';
import { AdminNavbarComponent } from './navbar/adminNavbar/adminNavbar.component';
import { AdminNavbarService } from './navbar/adminNavbar/adminNavbar.service';
import { CapacityAdminPlanningService } from './capacity/capacityPlanning.service'
import {CategoryComponent} from './Admin/Category/category.component';
import {Category2Component} from './Admin/Category/category2.component';
import {Category2EditComponent} from './Admin/Category/category2edit.component';
import {PCategoryEditComponent} from './Admin/Category/Pcategoryedit.component';
import {CategoryService} from './Admin/Category/category.service';
import { ProgressBarModule } from 'primeng/components/progressbar/progressbar';
import { ProgressbarModule } from 'ngx-bootstrap/progressbar';
import { OrganizationComponent } from'./Admin/organization/organization.component'
import { OrganizationService } from './Admin/organization/organization.service';
import { OuMappingComponent } from './Admin/ou-mapping/ou-mapping.component';
import { OuMappingService } from './Admin/ou-mapping/ou-mapping.service';
import { CidConfirmComponent } from './cidconfirm/cidconfirm.component';
import { CidconfirmService } from './cidconfirm/cidconfirm.service';
import { InfoboxComponent } from './capture/infobox.component';
import { CidconfirmAdminComponent } from './Admin/cidconfirmAdmin/cidconfirmAdmin.component';
import { CidconfirmAdminService } from './Admin/cidconfirmAdmin/cidconfirmAdmin.service';
import { DashboardComponent } from './Admin/dashboard/dashboard.component';

@NgModule({
  declarations: [
    AppComponent,
      NavbarComponent,
      OverviewComponent,
    CaptureComponent,
      ReportComponent,
      CapacityPlanningComponent,
      CapacityAdminComponent,
      InfoTextComponent,
      SegmentComponent,
      AdminNavbarComponent,
      CategoryComponent,
      Category2Component,
      Category2EditComponent,
      PCategoryEditComponent,
      CapacityPlanningComponent,
      OrganizationComponent,
      OuMappingComponent,
      CidConfirmComponent,
      InfoboxComponent,
      CidconfirmAdminComponent,
      DashboardComponent	
 
  ],
  imports: [
      BrowserModule,TabViewModule, BsDropdownModule.forRoot() ,routing, HttpModule, DialogModule,FormsModule, ButtonModule,DataTableModule,TooltipModule,ModalModule,
       GrowlModule, BsDatepickerModule.forRoot(), BsDropdownModule,FileUploadModule,BrowserAnimationsModule,PaginatorModule,PanelModule, CheckboxModule,CalendarModule,ConfirmDialogModule,
      AutoCompleteModule,ReactiveFormsModule,EditorModule,TabMenuModule, RadioButtonModule, AlertModule.forRoot(), MessagesModule,MessageModule,OrderListModule,MenuModule,ProgressBarModule,ProgressbarModule.forRoot()
      
  ],
  providers: [OverviewService,
     CapturingService,
     DatePipe,
     InfoTextService,
     CapacityAdminService,
     NavbarService,
     SegmentService,
     AdminNavbarService,
     CapacityAdminPlanningService,
     CategoryService,
	OrganizationService, 
     OuMappingService,
     CidconfirmService,
     CidconfirmAdminService	],
  bootstrap: [AppComponent]
})
export class AppModule { }
