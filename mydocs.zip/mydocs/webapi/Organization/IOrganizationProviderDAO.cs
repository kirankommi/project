﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UBS.CMR.DataAccess.Model;

namespace UBS.CMR.DataAccess.DataProvider.Organization
{
    public interface IOrganizationProviderDAO
    {
        IEnumerable<DataModel.Organization> GetOrganizations();
        bool IsOrgExists(DataModel.Organization organization);
        IEnumerable<DataModel.Organization> AddOrganization(DataModel.Organization organization);
        IEnumerable<DataModel.Organization> UpdateOrganization(DataModel.Organization organization);

        IEnumerable<OuMapping> GetOuMappings();

        IEnumerable<OuMapping> SearchOuMapping(int? org, string ou);

        IEnumerable<OuMapping> AddOuMapping(OuMapping ouMapping);
        string IsOuExists(string ou);
        IEnumerable<OuMapping> DeleteOuMapping(int? ouMapId);
    }
}
