﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity.Validation;
using UBS.CMR.DataAccess.DataModel;
using UBS.CMR.DataAccess.Model;

namespace UBS.CMR.DataAccess.DataProvider.Organization
{
    public class OrganizationProviderDAO : IOrganizationProviderDAO
    {
        public CMRDbContext context = new CMRDbContext();
        string errorMessage = string.Empty;
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public IEnumerable<DataModel.Organization> GetOrganizations()
        {
            log.Info("OrganizationProviderDAO, GetOrganizations");
            try
            {
                return context.Organization;
            }
            catch (DbEntityValidationException dbEx)
            {
                log.Error("OrganizationProviderDAO, GetOrganizations", dbEx);
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        errorMessage += string.Format("Property: {0} Error: {1}",
                        validationError.PropertyName, validationError.ErrorMessage) + Environment.NewLine;
                    }
                }
                throw new Exception(errorMessage, dbEx);
            }
        }

        public bool IsOrgExists(DataModel.Organization organization)
        {
            log.Info("OrganizationProviderDAO, IsOrgExists");
            try
            {
                var existingOrganization = context.Organization.Where(x => x.Organization_Name == organization.Organization_Name).FirstOrDefault();
                if (existingOrganization != null)
                    return true;
                else
                    return false;
            }
            catch (DbEntityValidationException dbEx)
            {
                log.Error("OrganizationProviderDAO, IsOrgExists", dbEx);
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        errorMessage += string.Format("Property: {0} Error: {1}",
                        validationError.PropertyName, validationError.ErrorMessage) + Environment.NewLine;
                    }
                }
                throw new Exception(errorMessage, dbEx);
            }
        }

        public IEnumerable<DataModel.Organization> AddOrganization(DataModel.Organization organization)
        {
            log.Info("OrganizationProviderDAO, AddOrganization");
            try
            {
                organization.CREATED_DATE = DateTime.Now;
                organization.LAST_UPDATED_DATE = DateTime.Now;      
                context.Organization.Add(organization);
                context.SaveChanges();
                return context.Organization;
                //return "Organization Added successfully";
            }
            catch (DbEntityValidationException dbEx)
            {
                log.Error("OrganizationProviderDAO, AddOrganization", dbEx);
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        errorMessage += string.Format("Property: {0} Error: {1}",
                        validationError.PropertyName, validationError.ErrorMessage) + Environment.NewLine;
                    }
                }
                throw new Exception(errorMessage, dbEx);
            }
        }

        public IEnumerable<DataModel.Organization> UpdateOrganization(DataModel.Organization organization)
        {
            log.Info("OrganizationProviderDAO, UpdateOrganization");
            try
            {
                var existingOrganization = context.Organization.Where(x => x.Id == organization.Id).FirstOrDefault();
                if (existingOrganization != null)
                {
                    organization.LAST_UPDATED_DATE = DateTime.Now;
                    organization.CREATED_BY = existingOrganization.CREATED_BY;
                    organization.CREATED_DATE = existingOrganization.CREATED_DATE;
                    context.Entry(existingOrganization).CurrentValues.SetValues(organization);
                    context.SaveChanges();
                }
                    
                return context.Organization;
            }
            catch (DbEntityValidationException dbEx)
            {
                log.Error("OrganizationProviderDAO, UpdateOrganization", dbEx);
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        errorMessage += string.Format("Property: {0} Error: {1}",
                        validationError.PropertyName, validationError.ErrorMessage) + Environment.NewLine;
                    }
                }
                throw new Exception(errorMessage, dbEx);
            }
        }

        public IEnumerable<OuMapping> GetOuMappings()
        {
            log.Info("OrganizationProviderDAO, GetOuMappings");
            try
            {
                List<OuMapping> retList = new List<OuMapping>();
                var oumappings = (from org in context.Organization
                                  join orgmap in context.Organization_OU_mapping
                                  on org.Id equals orgmap.Organization_Id
                                  join oudef in context.OU_DEFINITION
                                  on orgmap.OU_Id equals oudef.OU_ID.ToString()
                                  select new
                                  {
                                      Id = orgmap.Id,
                                      Organization_Id = orgmap.Organization_Id,
                                      Organization_Name = org.Organization_Name,
                                      OU_CODE = oudef.OU_CODE,
                                      CREATED_DATE = orgmap.CREATED_DATE,
                                      CREATED_BY = orgmap.CREATED_BY,
                                      LAST_UPDATED_DATE = orgmap.LAST_UPDATED_DATE,
                                      LAST_UPDATED_BY = orgmap.LAST_UPDATED_BY,
                                  });

                foreach (var oumapping in oumappings)
                {
                    OuMapping objOuMapping = new OuMapping();
                    objOuMapping.Id = oumapping.Id;
                    objOuMapping.Organization_Id = oumapping.Organization_Id;
                    objOuMapping.Organization_Name = oumapping.Organization_Name;
                    objOuMapping.OU_CODE = oumapping.OU_CODE;
                    objOuMapping.CREATED_DATE = oumapping.CREATED_DATE;
                    objOuMapping.CREATED_BY = oumapping.CREATED_BY;
                    objOuMapping.LAST_UPDATED_DATE = string.Format("{0:dd.MM.yyyy HH:mm}", oumapping.LAST_UPDATED_DATE);
                    objOuMapping.LAST_UPDATED_BY = oumapping.LAST_UPDATED_BY;
                    retList.Add(objOuMapping);
                }

                return retList;
            }
            catch (Exception ex)
            {
                log.Error("OrganizationProviderDAO, GetOuMappings", ex);
                throw new Exception(errorMessage, ex.InnerException);
            }
        }

        public IEnumerable<OuMapping> SearchOuMapping(int? org, string ou)
        {
            log.Info("OrganizationProviderDAO, Search");
            try
            {
                List<OuMapping> retList = new List<OuMapping>();
                var oumappings = (from organization in context.Organization
                                  join orgmap in context.Organization_OU_mapping
                                  on organization.Id equals orgmap.Organization_Id
                                  join oudef in context.OU_DEFINITION
                                  on orgmap.OU_Id equals oudef.OU_ID.ToString()
                                  where (((org == null || org == 0) ? true : orgmap.Organization_Id == org) && ((ou == "null") ? true : oudef.OU_CODE.ToLower() == ou.ToLower()))
                                  select new
                                  {
                                      Id = orgmap.Id,
                                      Organization_Id = orgmap.Organization_Id,
                                      Organization_Name = organization.Organization_Name,
                                      OU_CODE = oudef.OU_CODE,
                                      CREATED_DATE = orgmap.CREATED_DATE,
                                      CREATED_BY = orgmap.CREATED_BY,
                                      LAST_UPDATED_DATE = orgmap.LAST_UPDATED_DATE,
                                      LAST_UPDATED_BY = orgmap.LAST_UPDATED_BY,
                                  });

                foreach (var oumapping in oumappings)
                {
                    OuMapping objOuMapping = new OuMapping();
                    objOuMapping.Id = oumapping.Id;
                    objOuMapping.Organization_Id = oumapping.Organization_Id;
                    objOuMapping.Organization_Name = oumapping.Organization_Name;
                    objOuMapping.OU_CODE = oumapping.OU_CODE;
                    objOuMapping.CREATED_DATE = oumapping.CREATED_DATE;
                    objOuMapping.CREATED_BY = oumapping.CREATED_BY;
                    objOuMapping.LAST_UPDATED_DATE = string.Format("{0:dd.MM.yyyy HH:mm}", oumapping.LAST_UPDATED_DATE);
                    objOuMapping.LAST_UPDATED_BY = oumapping.LAST_UPDATED_BY;
                    retList.Add(objOuMapping);
                }

                return retList;

            }
            catch (DbEntityValidationException dbEx)
            {
                log.Error("OrganizationProviderDAO, GetOrganizations", dbEx);
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        errorMessage += string.Format("Property: {0} Error: {1}",
                        validationError.PropertyName, validationError.ErrorMessage) + Environment.NewLine;
                    }
                }
                throw new Exception(errorMessage, dbEx);
            }
        }

        public IEnumerable<OuMapping> AddOuMapping(OuMapping ouMapping)
        {
            log.Info("OrganizationProviderDAO, AddOuMapping");
            try
            {
                var existingou = context.OU_DEFINITION.Where(x => x.OU_CODE == ouMapping.OU_CODE).FirstOrDefault();

                if(existingou != null)
                {
                    var oumap = new Organization_OU_mapping
                    {
                        OU_Id = existingou.OU_ID.ToString(),
                        Organization_Id = ouMapping.Organization_Id,
                        CREATED_BY = ouMapping.CREATED_BY,
                        CREATED_DATE = ouMapping.CREATED_DATE,
                        LAST_UPDATED_BY = ouMapping.LAST_UPDATED_BY,
                        LAST_UPDATED_DATE = DateTime.Now
                    };

                    context.Organization_OU_mapping.Add(oumap);
                    context.SaveChanges();
                }

                List<OuMapping> retList = new List<OuMapping>();
                var oumappings = (from org in context.Organization
                                  join orgmap in context.Organization_OU_mapping
                                  on org.Id equals orgmap.Organization_Id
                                  join oudef in context.OU_DEFINITION
                                  on orgmap.OU_Id equals oudef.OU_ID.ToString()
                                  select new
                                  {
                                      Id = orgmap.Id,
                                      Organization_Id = orgmap.Organization_Id,
                                      Organization_Name = org.Organization_Name,
                                      OU_CODE = oudef.OU_CODE,
                                      CREATED_DATE = orgmap.CREATED_DATE,
                                      CREATED_BY = orgmap.CREATED_BY,
                                      LAST_UPDATED_DATE = orgmap.LAST_UPDATED_DATE,
                                      LAST_UPDATED_BY = orgmap.LAST_UPDATED_BY,
                                  });

                foreach (var oumapping in oumappings)
                {
                    OuMapping objOuMapping = new OuMapping();
                    objOuMapping.Id = oumapping.Id;
                    objOuMapping.Organization_Id = oumapping.Organization_Id;
                    objOuMapping.Organization_Name = oumapping.Organization_Name;
                    objOuMapping.OU_CODE = oumapping.OU_CODE;
                    objOuMapping.CREATED_DATE = oumapping.CREATED_DATE;
                    objOuMapping.CREATED_BY = oumapping.CREATED_BY;
                    objOuMapping.LAST_UPDATED_DATE = string.Format("{0:dd.MM.yyyy HH:mm}", oumapping.LAST_UPDATED_DATE);
                    objOuMapping.LAST_UPDATED_BY = oumapping.LAST_UPDATED_BY;
                    retList.Add(objOuMapping);
                }

                return retList;
            }
            catch (DbEntityValidationException dbEx)
            {
                log.Error("OrganizationProviderDAO, AddOuMapping", dbEx);
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        errorMessage += string.Format("Property: {0} Error: {1}",
                        validationError.PropertyName, validationError.ErrorMessage) + Environment.NewLine;
                    }
                }
                throw new Exception(errorMessage, dbEx);
            }
        }

        public string IsOuExists(string ou)
        {
            log.Info("OrganizationProviderDAO, IsOuExists");
            try
            {
                
                var existingouindef = context.OU_DEFINITION.Where(x => x.OU_CODE == ou).FirstOrDefault();
                if (existingouindef != null)
                {
                    var existingouinmap = context.Organization_OU_mapping.Where(x => x.OU_Id == existingouindef.OU_ID.ToString()).FirstOrDefault();
                    if (existingouinmap != null)
                        return "OU is already mapped to organization";
                    else
                        return "Valid OU";
                }                    
                else
                    return "Please enter valid OU";                
            }
            catch (DbEntityValidationException dbEx)
            {
                log.Error("OrganizationProviderDAO, IsOuExists", dbEx);
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        errorMessage += string.Format("Property: {0} Error: {1}",
                        validationError.PropertyName, validationError.ErrorMessage) + Environment.NewLine;
                    }
                }
                throw new Exception(errorMessage, dbEx);
            }
        }

        public IEnumerable<OuMapping> DeleteOuMapping(int? ouMapId)
        {
            log.Info("OrganizationProviderDAO, DeleteOuMapping");
            try
            {
                var existingOuMap = context.Organization_OU_mapping.Where(x => x.Id == ouMapId).FirstOrDefault();
                if (existingOuMap != null)
                {
                    context.Organization_OU_mapping.Remove(existingOuMap);
                    context.SaveChanges();
                }

                List<OuMapping> retList = new List<OuMapping>();
                var oumappings = (from org in context.Organization
                                  join orgmap in context.Organization_OU_mapping
                                  on org.Id equals orgmap.Organization_Id
                                  join oudef in context.OU_DEFINITION
                                  on orgmap.OU_Id equals oudef.OU_ID.ToString()
                                  select new
                                  {
                                      Id = orgmap.Id,
                                      Organization_Id = orgmap.Organization_Id,
                                      Organization_Name = org.Organization_Name,
                                      OU_CODE = oudef.OU_CODE,
                                      CREATED_DATE = orgmap.CREATED_DATE,
                                      CREATED_BY = orgmap.CREATED_BY,
                                      LAST_UPDATED_DATE = orgmap.LAST_UPDATED_DATE,
                                      LAST_UPDATED_BY = orgmap.LAST_UPDATED_BY,
                                  });

                foreach (var oumapping in oumappings)
                {
                    OuMapping objOuMapping = new OuMapping();
                    objOuMapping.Id = oumapping.Id;
                    objOuMapping.Organization_Id = oumapping.Organization_Id;
                    objOuMapping.Organization_Name = oumapping.Organization_Name;
                    objOuMapping.OU_CODE = oumapping.OU_CODE;
                    objOuMapping.CREATED_DATE = oumapping.CREATED_DATE;
                    objOuMapping.CREATED_BY = oumapping.CREATED_BY;
                    objOuMapping.LAST_UPDATED_DATE = string.Format("{0:dd.MM.yyyy HH:mm}", oumapping.LAST_UPDATED_DATE);
                    objOuMapping.LAST_UPDATED_BY = oumapping.LAST_UPDATED_BY;
                    retList.Add(objOuMapping);
                }

                return retList;
            }
            catch (DbEntityValidationException dbEx)
            {
                log.Error("OrganizationProviderDAO, DeleteOuMapping", dbEx);
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        errorMessage += string.Format("Property: {0} Error: {1}",
                        validationError.PropertyName, validationError.ErrorMessage) + Environment.NewLine;
                    }
                }
                throw new Exception(errorMessage, dbEx);
            }
        }

      
    }
}
