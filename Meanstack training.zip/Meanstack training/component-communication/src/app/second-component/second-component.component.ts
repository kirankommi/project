import { Component, OnInit } from '@angular/core';
import {CommonService} from '../common.service'

@Component({
  selector: 'app-second-component',
  templateUrl: './second-component.component.html',
  styleUrls: ['./second-component.component.css']
})
export class SecondComponentComponent implements OnInit {
  msg:string;
  constructor(private commonService: CommonService) { }

  ngOnInit() {
    this.commonService.currentMessage.subscribe(msg=>this.msg = msg)
  }

}
