import { Injectable } from "@angular/core";
import { BehaviorSubject } from 'rxjs';

@Injectable()
export class CommonService{
    private msgSource = new BehaviorSubject("old message");
    currentMessage = this.msgSource.asObservable();

    changeMessage(msg:string){
        this.msgSource.next(msg);
    }
}