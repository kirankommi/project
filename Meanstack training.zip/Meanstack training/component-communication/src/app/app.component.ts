import { Component, ViewChild } from '@angular/core';
import { ChildComponent } from './child/child.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  name:string="Ram Kumar";
  @ViewChild(ChildComponent) ChildRef;
  ParentAge:number;
  title = 'component-communication';
  

  ngOnInit(){
    this.ParentAge = 70;
  }

  ngAfterViewInit(){
    this.ParentAge = this.ChildRef.childAge;
  }
}
