import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FirsComponentComponent } from './firs-component.component';

describe('FirsComponentComponent', () => {
  let component: FirsComponentComponent;
  let fixture: ComponentFixture<FirsComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FirsComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FirsComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
