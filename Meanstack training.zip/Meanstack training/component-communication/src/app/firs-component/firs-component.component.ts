import { Component, OnInit } from '@angular/core';
import {CommonService} from '../common.service'

@Component({
  selector: 'app-firs-component',
  templateUrl: './firs-component.component.html',
  styleUrls: ['./firs-component.component.css']
})
export class FirsComponentComponent implements OnInit {
msg:string;
  constructor(private commonService: CommonService) { }

  ngOnInit() {
    this.commonService.currentMessage.subscribe(msg=>this.msg = msg)
  }

}
