import { NgModule } from '@angular/core';
import { Routes, RouterModule, PreloadAllModules } from '@angular/router';

const routes: Routes = [
  {path:"", redirectTo:"/first", pathMatch:"full"},
  {path:"first", loadChildren:"./submodule1/submodule1.module#Submodule1Module"},
  {path:"second",loadChildren:"./submodule2/submodule2.module#Submodule2Module"}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],

  //imports: [RouterModule.forRoot(routes,{preloadingStrategy:PreloadAllModules})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
