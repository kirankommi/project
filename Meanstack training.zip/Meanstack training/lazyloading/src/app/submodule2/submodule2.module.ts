import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Comp2Component } from './comp2/comp2.component';

@NgModule({
  declarations: [Comp2Component],
  imports: [
    CommonModule
  ]
})
export class Submodule2Module { }
