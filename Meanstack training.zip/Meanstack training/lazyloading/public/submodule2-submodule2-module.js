(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["submodule2-submodule2-module"],{

/***/ "./src/app/submodule2/comp2/comp2.component.css":
/*!******************************************************!*\
  !*** ./src/app/submodule2/comp2/comp2.component.css ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3N1Ym1vZHVsZTIvY29tcDIvY29tcDIuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/submodule2/comp2/comp2.component.html":
/*!*******************************************************!*\
  !*** ./src/app/submodule2/comp2/comp2.component.html ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<p>\n  comp2 works!\n</p>\n"

/***/ }),

/***/ "./src/app/submodule2/comp2/comp2.component.ts":
/*!*****************************************************!*\
  !*** ./src/app/submodule2/comp2/comp2.component.ts ***!
  \*****************************************************/
/*! exports provided: Comp2Component */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Comp2Component", function() { return Comp2Component; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var Comp2Component = /** @class */ (function () {
    function Comp2Component() {
    }
    Comp2Component.prototype.ngOnInit = function () {
    };
    Comp2Component = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-comp2',
            template: __webpack_require__(/*! ./comp2.component.html */ "./src/app/submodule2/comp2/comp2.component.html"),
            styles: [__webpack_require__(/*! ./comp2.component.css */ "./src/app/submodule2/comp2/comp2.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], Comp2Component);
    return Comp2Component;
}());



/***/ }),

/***/ "./src/app/submodule2/submodule2.module.ts":
/*!*************************************************!*\
  !*** ./src/app/submodule2/submodule2.module.ts ***!
  \*************************************************/
/*! exports provided: Submodule2Module */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Submodule2Module", function() { return Submodule2Module; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _comp2_comp2_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./comp2/comp2.component */ "./src/app/submodule2/comp2/comp2.component.ts");




var Submodule2Module = /** @class */ (function () {
    function Submodule2Module() {
    }
    Submodule2Module = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_comp2_comp2_component__WEBPACK_IMPORTED_MODULE_3__["Comp2Component"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"]
            ]
        })
    ], Submodule2Module);
    return Submodule2Module;
}());



/***/ })

}]);
//# sourceMappingURL=submodule2-submodule2-module.js.map