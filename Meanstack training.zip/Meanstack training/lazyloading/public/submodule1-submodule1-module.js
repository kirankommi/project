(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["submodule1-submodule1-module"],{

/***/ "./src/app/submodule1/comp1/comp1.component.css":
/*!******************************************************!*\
  !*** ./src/app/submodule1/comp1/comp1.component.css ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3N1Ym1vZHVsZTEvY29tcDEvY29tcDEuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/submodule1/comp1/comp1.component.html":
/*!*******************************************************!*\
  !*** ./src/app/submodule1/comp1/comp1.component.html ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<p>\n  comp1 works!\n</p>\n"

/***/ }),

/***/ "./src/app/submodule1/comp1/comp1.component.ts":
/*!*****************************************************!*\
  !*** ./src/app/submodule1/comp1/comp1.component.ts ***!
  \*****************************************************/
/*! exports provided: Comp1Component */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Comp1Component", function() { return Comp1Component; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var Comp1Component = /** @class */ (function () {
    function Comp1Component() {
    }
    Comp1Component.prototype.ngOnInit = function () {
    };
    Comp1Component = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-comp1',
            template: __webpack_require__(/*! ./comp1.component.html */ "./src/app/submodule1/comp1/comp1.component.html"),
            styles: [__webpack_require__(/*! ./comp1.component.css */ "./src/app/submodule1/comp1/comp1.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], Comp1Component);
    return Comp1Component;
}());



/***/ }),

/***/ "./src/app/submodule1/submodule1.module.ts":
/*!*************************************************!*\
  !*** ./src/app/submodule1/submodule1.module.ts ***!
  \*************************************************/
/*! exports provided: Submodule1Module */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Submodule1Module", function() { return Submodule1Module; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _comp1_comp1_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./comp1/comp1.component */ "./src/app/submodule1/comp1/comp1.component.ts");




var Submodule1Module = /** @class */ (function () {
    function Submodule1Module() {
    }
    Submodule1Module = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_comp1_comp1_component__WEBPACK_IMPORTED_MODULE_3__["Comp1Component"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"]
            ]
        })
    ], Submodule1Module);
    return Submodule1Module;
}());



/***/ })

}]);
//# sourceMappingURL=submodule1-submodule1-module.js.map