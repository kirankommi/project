var id=100;
var name="Raj";
var dis1=function(){
    console.log("dis1 function");
}
exports.id = id;
exports.name = name;
exports.dis1 = dis1;