var express = require("express");
var bodyParser = require('body-parser');
var app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));
app.get("/",function(req,res){
    console.log("get method");
    res.send("Welcome to Express Get method");
})
app.get("/checkUser",function(req,res){
    var name = req.query["user"];
    var pass = req.query["pass"];
    if(name === "Raj" && pass === "Deep"){
        res.write("successfully login");
    }
    else {
        res.write("Failure try once again");
    }
    res.end("");
})
app.get("/jsonData", function(req,res){
    var empInfo = {"id":100,"name":"Raj",salary:120000};
    res.json(empInfo);
})
app.post("/postCheckUser",function(req,res){
    console.log("post method called..");
    var name = req.body.user;
    var pass = req.body.pass
    res.send("Post method called username: " + name + " Password: " + pass);
})


app.listen(9090,function(){
    console.log("express server is running on port number 9090");
})