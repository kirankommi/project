var aobj = require("./a.js");
console.log(aobj.id);
console.log(aobj.name);
aobj.dis1();