var express = require("express");
var bodyParser = require('body-parser');
var app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));

//Db module
var mongoose = require("mongoose");
var uri = "mongodb://localhost:27017/meandb";
mongoose.connect(uri,{useNewUrlParser:true});
var schema =  mongoose.Schema;
var userSchema = new schema({
    name:{type:String,required:true},
    age:{type:Number,required:true}});
db = mongoose.connection;

app.get("/empJson",function(req,res){
   console.log("Database connected...");
   var empRef = db.model("emps", userSchema);
   empRef.find({},function(err,empInfo){
       if(err){
           console.log("Error Generated "+ err)
       }
       else{
           console.log(empInfo);
           res.json(empInfo);

       }
       db.close();
   })
})


app.listen(9090,function(){
    console.log("express server is running on port number 9090");
})