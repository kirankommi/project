var EmpModel = require("../model/emp.model.js")
exports.getEmpTest = function(req,res){
    console.log("simple test msg");
    res.send("Welcome to Test code..");
}
exports.getEmpJson= function(req,res){
    var emp = {"Id":100,"Name":"Raju","Salary":12000};
        res.json(emp);
}

exports.getEmpInfoDb = function(req,res){
    EmpModel.find({},function(err,empRec){
        if(err){
            res.send(err);
        }
        else{
            res.json(empRec);
        }
    });
}

//Add employee details in DB
exports.storeEmpInfo = function(req,res){
    let emp = new EmpModel({
        Name:req.body.name,
        age:req.body.age
    })
    emp.save(function(err,result){
        if(err){
            console.log("Error generated"+err);
        }
        else{
            res.send("Record stored successfully..."+ result);
        }
    })
}

//update employee details in DB
exports.updateEmpInfo = function(req,res){
    var empName = req.body.name;
    var empAge = req.body.age;
    EmpModel.updateOne({name:empName},{$set:{age:empAge}},function(err,result){
        if(!err){
            res.send("Record updated successfully..."+ result);
        }
    });
}

//Delete Employee details in DB
exports.deleteEmpInfo = function(req,res){
    var empName = req.body.name;
    EmpModel.deleteOne({name:empName},function(err,result){
        if(!err){
            res.send("Record deleted successfully.."+result);
        }
    });
}