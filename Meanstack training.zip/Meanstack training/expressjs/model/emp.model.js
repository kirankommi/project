var mongoose = require("mongoose");
var Schema = mongoose.Schema;
var EmpSchema = new Schema({
    name:{type:String},
    age:{type:Number}
});

var EmpModel = mongoose.model("emps",EmpSchema);
module.exports = EmpModel;