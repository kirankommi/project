//All module loaded...
var express = require("express");
var bodyParser = require("body-parser");
var mongoose = require("mongoose");
var url = "mongodb://localhost:27017/meandb";
var app = express();
var cors = require("cors");
app.use(cors({
    origin:"http://localhost:4200"
}));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));

mongoose.connect(url,{useNewUrlParser:true});
mongoose.connect;
const port = 9999;

let emp = require("./router/emp.router.js");
app.use("/emp",emp);
app.listen(port,function(){
    console.log(`The server is running on port number as ${port}`);
})