import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { employee } from "./employee";
import {Observable,of} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  emp:employee[];
  constructor(private httpClient:HttpClient) { 
    this.emp = [
      new employee(100,"Ajay",20000)
    ]
  }

  displayInfo():string{
    return "welcome to custome service";
  }

  displayEmployees():employee[]{
    return this.emp;
  }

  getEmployeeInfo(): Observable<employee[]> {
    return of(this.emp);
  }
}
