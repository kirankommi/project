import { TestBed,async,inject } from '@angular/core/testing';
import { CustomerService } from './customer.service';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';
import { employee } from './employee';
import { Observable, of } from 'rxjs';


class EmployeeServiceFake {
  emp:employee[];
  getEmployeeInfo():Observable<employee[]> {
    let e1 = new employee(1000,"Raj",120000);
    this.emp = [e1];
    return of(this.emp);
  }
}
describe('CustomerService', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule
      ],
      declarations: [
        AppComponent
      ],
      //providers :[CustomerService]
      providers :[{provide:EmployeeServiceFake, useClass:EmployeeServiceFake}]
    }).compileComponents();
  }));


  //check actual service
  //it('should be created', inject([CustomerService],
  //   (service: CustomerService ) => {
  //     let employees = service.displayEmployees();
  //     let name = employees[0].name;
  //    expect(name).toEqual('Ajay')
  //}));

  //mock sevice
  it('employee service get method - mock method', inject([EmployeeServiceFake],
    (service: EmployeeServiceFake ) => {
      let employees = service.getEmployeeInfo().subscribe(emp=>{
      let id = emp[0].id
      let name = emp[0].name;
      expect(id).toEqual(1000);
      expect(name).toEqual("Raj");
      })
 }));

});
