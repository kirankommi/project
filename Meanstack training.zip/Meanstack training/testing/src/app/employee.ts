export class employee{
    constructor(public id:number, 
        public name:string, 
        public salary: number){};
}