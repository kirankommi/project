import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-reactivelogin',
  templateUrl: './reactivelogin.component.html',
  styleUrls: ['./reactivelogin.component.css']
})
export class ReactiveloginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

    userLogin = new FormGroup({
      userName: new FormControl(),
      pass: new FormControl()
    });

    Verify(){
      console.log(this.userLogin.value.userName);
      console.log(this.userLogin.value.pass)
    }
}
