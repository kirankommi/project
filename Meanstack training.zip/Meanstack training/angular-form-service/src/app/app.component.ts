import { Component } from '@angular/core';
import { EmployeeService } from './employeeService';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  name = 'kiran';
  config:string;
  constructor(public es:EmployeeService){

  }

  fun():void{
    console.log(this.es.display()
    .subscribe((data: Response) => this.config));
  }
}
