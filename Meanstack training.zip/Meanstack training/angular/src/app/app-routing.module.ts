import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {GetEmpInfoComponent} from './get-emp-info/get-emp-info.component';
import { CreateEmpInfoComponent } from './create-emp-info/create-emp-info.component'

const routes: Routes = [
  { path: 'GetEmpInfo', component: GetEmpInfoComponent },
  { path: 'AddEmp', component: CreateEmpInfoComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
