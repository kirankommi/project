import { Component, OnInit } from '@angular/core';
import { EmployeeService } from  '../employee.service';
@Component({
  selector: 'app-get-emp-info',
  templateUrl: './get-emp-info.component.html',
  styleUrls: ['./get-emp-info.component.css']
})
export class GetEmpInfoComponent implements OnInit {

  constructor(public employeeService: EmployeeService) { }

  ngOnInit() {
    console.log("ngOnInit");
  }

  ngOnChanges(){
    console.log("ngOnChanges");
  }

  ngDoCheck(){
    console.log("ngDoCheck");
  }

  ngAfterContentInit(){
    console.log("ngAfterContentInit");
  }

  ngAfterContentChecked(){
    console.log("ngAfterContentChecked");
  }

  ngAfterViewInit(){
    console.log("ngAfterViewInit");
  }

  ngAfterViewChecked(){
    console.log("ngAfterViewChecked");
  }

  ngOnDestroy(){
    console.log("ngOnDestroy");
  }

  getempinfo(){
    this.employeeService.getEmpInfo();
  }
}
