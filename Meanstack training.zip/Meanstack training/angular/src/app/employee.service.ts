import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import { Observer, Observable } from 'rxjs';

@Injectable()
export class EmployeeService {
    url = "http://localhost:9999/emp/";
    constructor(private httpClient:HttpClient){

    }
    getEmpInfo(){
        console.log("Employee Service method");
        this.httpClient.get(this.url+"empJson").subscribe(
            data=>console.log("Rec"+data));
    }

    storeEmpInfoDb(userInfo):Observable<string>{
        return this.httpClient.post(this.url + "empDbStore",userInfo,
        {responseType:"text"});
    }
}