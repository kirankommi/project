import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-create-emp-info',
  templateUrl: './create-emp-info.component.html',
  styleUrls: ['./create-emp-info.component.css']
})
export class CreateEmpInfoComponent implements OnInit {
    msg:string;
  constructor(private empSer:EmployeeService) { }

  ngOnInit() {
  }

  createUser(userInfo){
    console.log(userInfo);
    this.empSer.storeEmpInfoDb(userInfo).subscribe(result=> this.msg = result);
  }
}
