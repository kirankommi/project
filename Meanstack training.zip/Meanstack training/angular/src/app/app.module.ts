import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http'
import { AppRoutingModule } from './app-routing.module';
import { FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { GetEmpInfoComponent } from './get-emp-info/get-emp-info.component';
import { EmployeeService } from  './employee.service';
import { CreateEmpInfoComponent } from './create-emp-info/create-emp-info.component';

@NgModule({
  declarations: [
    AppComponent,
    GetEmpInfoComponent,
    CreateEmpInfoComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [EmployeeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
